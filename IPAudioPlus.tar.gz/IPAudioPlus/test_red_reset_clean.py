import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(5)

print("[*] Clearing all open menus...")
for _ in range(4):
    send_key(1)
    time.sleep(0.3)

time.sleep(1.0)

print("[*] Opening Plugin Browser...")
send_key(399)
time.sleep(1.5)

print("[*] Navigating to IP AudioPlus...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] Pressing PAUSE (119) to activate Timeshift & vDelay counter...")
send_key(119) # KEY_PAUSE
time.sleep(3.2)

print("[*] Pressing RED key (398) to trigger clean silent Reset...")
send_key(398) # KEY_RED
time.sleep(1.0)

print("[*] Capturing screenshot to verify clean exit without confirmation message...")
take_osd_screenshot("red_reset_silent_state.png")
print("[+] Finished successfully.")
