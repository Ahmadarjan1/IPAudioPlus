import os
import sys
import time
import urllib.request
import paramiko

HOST = "192.168.100.132"
USER = "root"
PASS = "root"

def get_ssh(retries=3):
    for i in range(retries):
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(HOST, username=USER, password=PASS, timeout=12, banner_timeout=12, auth_timeout=12)
            return client
        except Exception as e:
            if i == retries - 1:
                raise e
            time.sleep(1.5)

def run_cmd(cmd):
    client = get_ssh()
    stdin, stdout, stderr = client.exec_command(cmd)
    out = stdout.read().decode('utf-8', errors='ignore')
    err = stderr.read().decode('utf-8', errors='ignore')
    client.close()
    return out, err

def restart_enigma2():
    print("[*] Restarting Enigma2 GUI...")
    run_cmd("killall -9 enigma2")
    time.sleep(3)
    print("[+] Enigma2 restarted.")

def take_osd_screenshot(local_output_path):
    print("[*] Grabbing OSD screenshot...")
    run_cmd("grab -o -p /tmp/osd_shot.png")
    client = get_ssh()
    sftp = client.open_sftp()
    sftp.get("/tmp/osd_shot.png", local_output_path)
    sftp.close()
    client.close()
    print(f"[+] Screenshot saved to {local_output_path}")

def upload_folder(local_dir, remote_dir):
    print(f"[*] Uploading {local_dir} -> {remote_dir}...")
    client = get_ssh()
    sftp = client.open_sftp()
    
    # Ensure remote dir exists
    try:
        sftp.stat(remote_dir)
    except IOError:
        run_cmd(f"mkdir -p {remote_dir}")
        
    for root, dirs, files in os.walk(local_dir):
        rel_root = os.path.relpath(root, local_dir).replace('\\', '/')
        cur_remote = remote_dir if rel_root == '.' else f"{remote_dir}/{rel_root}"
        
        for d in dirs:
            target_sub = f"{cur_remote}/{d}"
            try:
                sftp.stat(target_sub)
            except IOError:
                run_cmd(f"mkdir -p {target_sub}")
                
        for f in files:
            if f.endswith('.pyc') or f.endswith('.git'):
                continue
            local_f = os.path.join(root, f)
            remote_f = f"{cur_remote}/{f}"
            sftp.put(local_f, remote_f)
            
    sftp.close()
    client.close()
    print("[+] Upload complete.")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        action = sys.argv[1]
        if action == "restart":
            restart_enigma2()
        elif action == "shot":
            path = sys.argv[2] if len(sys.argv) > 2 else "osd_shot.png"
            take_osd_screenshot(path)
        elif action == "cmd":
            cmd = " ".join(sys.argv[2:])
            o, e = run_cmd(cmd)
            print(o)
            if e:
                print("ERR:", e, file=sys.stderr)
