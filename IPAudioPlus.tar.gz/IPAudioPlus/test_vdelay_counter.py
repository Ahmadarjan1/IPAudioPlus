import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(5)

print("[*] Clearing all open menus...")
send_key(1)
time.sleep(0.5)
send_key(1)
time.sleep(0.5)

print("[*] Opening Plugin Browser...")
send_key(399)
time.sleep(1.5)

print("[*] Opening IP AudioPlus...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] Pressing PAUSE (119) to pause timeshift and start counting vDelay...")
send_key(119) # KEY_PAUSE
time.sleep(3.2)

print("[*] Capturing screenshot during vDelay counting...")
take_osd_screenshot("vdelay_counting_state.png")

time.sleep(2.8)

print("[*] Pressing PAUSE (119) again to resume timeshift playback...")
send_key(119) # KEY_PAUSE second press
time.sleep(1.0)

print("[*] Capturing screenshot of resumed timeshift playback with final vDelay...")
take_osd_screenshot("vdelay_resumed_state.png")
print("[+] Finished successfully.")
