import os
from PIL import Image, ImageDraw, ImageFont

ASSETS_DIR = "images"
os.makedirs(ASSETS_DIR, exist_ok=True)

# 1. Header Banner (692 x 84)
def create_header():
    w, h = 692, 84
    img = Image.new("RGBA", (w, h), (0, 122, 196, 255))
    draw = ImageDraw.Draw(img)
    
    mic_x, mic_y = 52, 42
    draw.arc([mic_x - 22, mic_y - 22, mic_x + 22, mic_y + 22], start=45, end=135, fill=(255, 255, 255, 180), width=3)
    draw.arc([mic_x - 27, mic_y - 27, mic_x + 27, mic_y + 27], start=45, end=135, fill=(255, 255, 255, 130), width=2)
    draw.rounded_rectangle([mic_x - 7, mic_y - 18, mic_x + 7, mic_y + 4], radius=6, fill=(255, 255, 255, 255))
    draw.arc([mic_x - 12, mic_y - 8, mic_x + 12, mic_y + 10], start=0, end=180, fill=(255, 255, 255, 255), width=3)
    draw.line([mic_x, mic_y + 10, mic_x, mic_y + 18], fill=(255, 255, 255, 255), width=3)
    draw.line([mic_x - 9, mic_y + 18, mic_x + 9, mic_y + 18], fill=(255, 255, 255, 255), width=3)
    draw.line([mic_x - 5, mic_y - 10, mic_x + 5, mic_y - 10], fill=(0, 122, 196, 255), width=2)
    draw.line([mic_x - 5, mic_y - 4, mic_x + 5, mic_y - 4], fill=(0, 122, 196, 255), width=2)
    draw.line([mic_x - 5, mic_y + 1, mic_x + 5, mic_y + 1], fill=(0, 122, 196, 255), width=2)

    try:
        font_bold = ImageFont.truetype("arialbd.ttf", 46)
        font_plus = ImageFont.truetype("arialbd.ttf", 32)
        font_ver = ImageFont.truetype("arialbd.ttf", 26)
    except Exception:
        font_bold = ImageFont.load_default()
        font_plus = font_bold
        font_ver = font_bold
        
    draw.text((96, 15), "IP AUDIO", fill=(255, 255, 255, 255), font=font_bold)
    draw.text((328, 12), "+", fill=(255, 255, 255, 255), font=font_plus)
    draw.text((w - 75, 28), "5.0", fill=(255, 255, 255, 255), font=font_ver)
    img.save(os.path.join(ASSETS_DIR, "header_banner.png"), "PNG")

# 2. Status Banner (Top-Left 1088 x 56)
def create_status_banner():
    w, h = 1088, 56
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([0, 0, w - 1, h - 1], radius=8, fill=(35, 43, 62, 235), outline=(65, 80, 110, 255), width=2)
    img.save(os.path.join(ASSETS_DIR, "status_bg.png"), "PNG")

# 3. Section Header Bars
def create_section_header():
    # Normal Header (574 x 56)
    img = Image.new("RGBA", (574, 56), (43, 55, 78, 255)) # Dark slate blue #2b374e
    img.save(os.path.join(ASSETS_DIR, "section_header_bg.png"), "PNG")

    # Full Width Expanded Server Header (1234 x 56)
    img_exp = Image.new("RGBA", (1234, 56), (43, 55, 78, 255))
    img_exp.save(os.path.join(ASSETS_DIR, "server_expanded_hdr.png"), "PNG")

# 4. Row Backgrounds
def create_row_bg():
    w, h = 574, 52
    img = Image.new("RGBA", (w, h), (10, 14, 22, 255))
    img.save(os.path.join(ASSETS_DIR, "row_dark_bg.png"), "PNG")

    # Server list items (660 x 52)
    img_srv_sel = Image.new("RGBA", (660, 52), (0, 128, 200, 255)) # Solid Blue
    img_srv_sel.save(os.path.join(ASSETS_DIR, "server_selected_bg.png"), "PNG")

    img_srv_dark = Image.new("RGBA", (660, 52), (10, 14, 22, 255)) # Dark black
    img_srv_dark.save(os.path.join(ASSETS_DIR, "server_row_dark.png"), "PNG")

    img_srv_slate = Image.new("RGBA", (660, 52), (28, 35, 50, 255)) # Dark slate alternating
    img_srv_slate.save(os.path.join(ASSETS_DIR, "server_row_slate.png"), "PNG")

# 5. Selected Channel Bar (574 x 52)
def create_selected_bar():
    w, h = 574, 52
    img = Image.new("RGBA", (w, h), (0, 128, 200, 255))
    img.save(os.path.join(ASSETS_DIR, "channel_selected_bg.png"), "PNG")

# 6. Red Delay Icon (44 x 44)
def create_delay_icon():
    size = 44
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.ellipse([2, 2, size - 3, size - 3], outline=(225, 29, 72, 255), width=3)
    draw.line([13, 12, 13, size - 13], fill=(225, 29, 72, 255), width=3)
    draw.polygon([(17, 13), (24, 22), (17, 31)], fill=(225, 29, 72, 255))
    draw.polygon([(24, 13), (31, 22), (24, 31)], fill=(225, 29, 72, 255))
    img.save(os.path.join(ASSETS_DIR, "icon_delay.png"), "PNG")

# 7. Bottom Icons
def create_toolbar_icons():
    img_set = Image.new("RGBA", (38, 38), (0, 0, 0, 0))
    draw_s = ImageDraw.Draw(img_set)
    draw_s.rectangle([2, 2, 35, 35], outline=(56, 189, 248, 255), width=2)
    draw_s.line([7, 10, 30, 10], fill=(255, 255, 255, 255), width=2)
    draw_s.line([7, 19, 30, 19], fill=(255, 255, 255, 255), width=2)
    draw_s.line([7, 28, 30, 28], fill=(255, 255, 255, 255), width=2)
    draw_s.rectangle([11, 7, 15, 13], fill=(56, 189, 248, 255))
    draw_s.rectangle([21, 16, 25, 22], fill=(56, 189, 248, 255))
    draw_s.rectangle([13, 25, 17, 31], fill=(56, 189, 248, 255))
    img_set.save(os.path.join(ASSETS_DIR, "icon_settings.png"), "PNG")

    img_exit = Image.new("RGBA", (38, 38), (0, 0, 0, 0))
    draw_e = ImageDraw.Draw(img_exit)
    draw_e.line([30, 4, 6, 4], fill=(56, 189, 248, 255), width=2)
    draw_e.line([6, 4, 6, 34], fill=(56, 189, 248, 255), width=2)
    draw_e.line([6, 34, 30, 34], fill=(56, 189, 248, 255), width=2)
    draw_e.line([14, 19, 30, 19], fill=(255, 255, 255, 255), width=3)
    draw_e.polygon([(24, 12), (32, 19), (24, 26)], fill=(255, 255, 255, 255))
    img_exit.save(os.path.join(ASSETS_DIR, "icon_exit.png"), "PNG")

    for name, col in [("bar_green", (34, 197, 94, 255)),
                      ("bar_red", (239, 68, 68, 255)),
                      ("bar_yellow", (234, 179, 8, 255)),
                      ("bar_blue", (14, 165, 233, 255))]:
        b = Image.new("RGBA", (4, 24), col)
        b.save(os.path.join(ASSETS_DIR, f"{name}.png"), "PNG")

    p_icon = Image.new("RGBA", (100, 40), (0, 122, 196, 255))
    d_p = ImageDraw.Draw(p_icon)
    try:
        f = ImageFont.truetype("arialbd.ttf", 16)
    except Exception:
        f = ImageFont.load_default()
    d_p.text((6, 10), "IP AUDIO+", fill=(255, 255, 255, 255), font=f)
    p_icon.save(os.path.join(ASSETS_DIR, "plugin.png"), "PNG")
    p_icon.save(os.path.join(os.path.dirname(ASSETS_DIR), "plugin.png"), "PNG")


# 8. Server and Audio Header Icons (36 x 36)
def create_header_icons():
    scale = 8
    size = 36 * scale
    
    # icon_server.png
    img_srv = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw_srv = ImageDraw.Draw(img_srv)
    w = int(28 * scale)
    h = int(7 * scale)
    x = int(4 * scale)
    gap = int(2.5 * scale)
    r = int(2 * scale)
    y_list = [int(4.5 * scale), int(4.5 * scale + h + gap), int(4.5 * scale + 2*(h + gap))]
    
    for idx, y in enumerate(y_list):
        draw_srv.rounded_rectangle([x, y, x + w, y + h], radius=r,
                                   fill=(20, 30, 48, 255), outline=(56, 189, 248, 255), width=int(1.8 * scale))
        draw_srv.line([x + int(4 * scale), y + h // 2, x + int(17 * scale), y + h // 2],
                      fill=(226, 232, 240, 220), width=int(1.2 * scale))
        led1_color = (34, 197, 94, 255) if idx < 2 else (56, 189, 248, 255)
        draw_srv.ellipse([x + int(19.5 * scale), y + int(2.3 * scale), x + int(22.3 * scale), y + int(5.1 * scale)],
                         fill=led1_color)
        draw_srv.ellipse([x + int(23.5 * scale), y + int(2.3 * scale), x + int(26.3 * scale), y + int(5.1 * scale)],
                         fill=(56, 189, 248, 255))
                         
    img_srv.resize((36, 36), Image.Resampling.LANCZOS).save(os.path.join(ASSETS_DIR, 'icon_server.png'), 'PNG')
    
    # icon_audio.png
    img_aud = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw_aud = ImageDraw.Draw(img_aud)
    body_x0 = int(4 * scale)
    body_x1 = int(10 * scale)
    body_y0 = int(12.5 * scale)
    body_y1 = int(23.5 * scale)
    cone_x = int(18 * scale)
    cone_top_y = int(6.5 * scale)
    cone_bot_y = int(29.5 * scale)
    poly = [
        (body_x0, body_y0),
        (body_x1, body_y0),
        (cone_x, cone_top_y),
        (cone_x, cone_bot_y),
        (body_x1, body_y1),
        (body_x0, body_y1)
    ]
    draw_aud.polygon(poly, fill=(255, 255, 255, 255))
    draw_aud.line([body_x1, body_y0, body_x1, body_y1], fill=(56, 189, 248, 255), width=int(1.5 * scale))
    draw_aud.arc([int(14.5 * scale), int(11.5 * scale), int(22.5 * scale), int(24.5 * scale)],
                 start=-55, end=55, fill=(56, 189, 248, 255), width=int(2.4 * scale))
    draw_aud.arc([int(18 * scale), int(6.5 * scale), int(29.5 * scale), int(29.5 * scale)],
                 start=-55, end=55, fill=(56, 189, 248, 255), width=int(2.4 * scale))
    draw_aud.arc([int(21.5 * scale), int(1.5 * scale), int(36.5 * scale), int(34.5 * scale)],
                 start=-50, end=50, fill=(56, 189, 248, 220), width=int(2.2 * scale))
                 
    img_aud.resize((36, 36), Image.Resampling.LANCZOS).save(os.path.join(ASSETS_DIR, 'icon_audio.png'), 'PNG')

    # icon_delay_hdr.png
    img_dl = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw_dl = ImageDraw.Draw(img_dl)
    center_x = size // 2
    center_y = size // 2
    radius = int(14 * scale)
    draw_dl.ellipse([center_x - radius, center_y - radius, center_x + radius, center_y + radius],
                    outline=(56, 189, 248, 255), width=int(2.2 * scale))
    draw_dl.ellipse([center_x - radius + int(2.2*scale), center_y - radius + int(2.2*scale),
                     center_x + radius - int(2.2*scale), center_y + radius - int(2.2*scale)],
                    fill=(20, 30, 48, 230))
    tick_len = int(2.8 * scale)
    draw_dl.line([center_x, center_y - radius + int(3*scale), center_x, center_y - radius + int(3*scale) + tick_len],
                 fill=(226, 232, 240, 240), width=int(1.8 * scale))
    draw_dl.line([center_x, center_y + radius - int(3*scale) - tick_len, center_x, center_y + radius - int(3*scale)],
                 fill=(148, 163, 184, 200), width=int(1.5 * scale))
    draw_dl.line([center_x + radius - int(3*scale) - tick_len, center_y, center_x + radius - int(3*scale), center_y],
                 fill=(148, 163, 184, 200), width=int(1.5 * scale))
    draw_dl.line([center_x - radius + int(3*scale), center_y, center_x - radius + int(3*scale) + tick_len, center_y],
                 fill=(148, 163, 184, 200), width=int(1.5 * scale))
    pin_r = int(2.2 * scale)
    draw_dl.line([center_x, center_y, center_x - int(5.5 * scale), center_y - int(5.5 * scale)],
                 fill=(255, 255, 255, 255), width=int(2.4 * scale))
    draw_dl.line([center_x, center_y, center_x, center_y - int(8.5 * scale)],
                 fill=(56, 189, 248, 255), width=int(2.0 * scale))
    draw_dl.ellipse([center_x - pin_r, center_y - pin_r, center_x + pin_r, center_y + pin_r],
                    fill=(255, 255, 255, 255))
    draw_dl.line([center_x - int(2.5 * scale), center_y - radius - int(1.5 * scale),
                  center_x + int(2.5 * scale), center_y - radius - int(1.5 * scale)],
                 fill=(226, 232, 240, 255), width=int(1.6 * scale))
    draw_dl.line([center_x, center_y - radius, center_x, center_y - radius - int(1.5 * scale)],
                 fill=(226, 232, 240, 255), width=int(1.6 * scale))
    arrow_tip_x = center_x - radius + int(1.5 * scale)
    arrow_tip_y = center_y - radius + int(3.5 * scale)
    draw_dl.polygon([
        (arrow_tip_x - int(3 * scale), arrow_tip_y),
        (arrow_tip_x + int(1.5 * scale), arrow_tip_y - int(3.5 * scale)),
        (arrow_tip_x + int(1.5 * scale), arrow_tip_y + int(3.5 * scale))
    ], fill=(56, 189, 248, 255))
    img_dl.resize((36, 36), Image.Resampling.LANCZOS).save(os.path.join(ASSETS_DIR, 'icon_delay_hdr.png'), 'PNG')


# 9. Channel Cards and Logos (Sat Air Design)
def create_channel_card_assets():
    scale = 4
    # 1. channel_card_normal.png (566 x 56)
    w, h = 566 * scale, 56 * scale
    img_n = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    d_n = ImageDraw.Draw(img_n)
    d_n.rounded_rectangle([scale, scale, w - scale, h - scale], radius=int(9 * scale),
                          fill=(20, 27, 40, 255), outline=(42, 57, 82, 255), width=int(1.8 * scale))
    img_n.resize((566, 56), Image.Resampling.LANCZOS).save(os.path.join(ASSETS_DIR, 'channel_card_normal.png'), 'PNG')

    # 2. channel_card_selected.png (566 x 56)
    img_s = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    d_s = ImageDraw.Draw(img_s)
    d_s.rounded_rectangle([scale, scale, w - scale, h - scale], radius=int(9 * scale),
                          fill=(12, 44, 76, 255), outline=(56, 189, 248, 255), width=int(2.2 * scale))
    img_s.resize((566, 56), Image.Resampling.LANCZOS).save(os.path.join(ASSETS_DIR, 'channel_card_selected.png'), 'PNG')

    # 3. default_channel_logo.png (56 x 40)
    lw, lh = 56 * scale, 40 * scale
    img_l = Image.new('RGBA', (lw, lh), (0, 0, 0, 0))
    d_l = ImageDraw.Draw(img_l)
    d_l.rounded_rectangle([scale, scale, lw - scale, lh - scale], radius=int(6 * scale),
                          fill=(14, 20, 32, 255), outline=(48, 65, 94, 255), width=int(1.5 * scale))
    cx, cy = lw // 2, lh // 2
    d_l.ellipse([cx - int(4*scale), cy - int(4*scale), cx + int(4*scale), cy + int(4*scale)], fill=(56, 189, 248, 255))
    d_l.arc([cx - int(9*scale), cy - int(9*scale), cx + int(9*scale), cy + int(9*scale)],
            start=-60, end=60, fill=(56, 189, 248, 220), width=int(2*scale))
    d_l.arc([cx - int(15*scale), cy - int(15*scale), cx + int(15*scale), cy + int(15*scale)],
            start=-55, end=55, fill=(56, 189, 248, 160), width=int(2*scale))
    img_l.resize((56, 40), Image.Resampling.LANCZOS).save(os.path.join(ASSETS_DIR, 'default_channel_logo.png'), 'PNG')

    # 4. chevron_icon.png (20 x 20)
    cw = 20 * scale
    img_ch = Image.new('RGBA', (cw, cw), (0, 0, 0, 0))
    d_ch = ImageDraw.Draw(img_ch)
    d_ch.line([(int(6*scale), int(4*scale)), (int(13*scale), int(10*scale)), (int(6*scale), int(16*scale))],
              fill=(148, 163, 184, 255), width=int(2*scale))
    img_ch.resize((20, 20), Image.Resampling.LANCZOS).save(os.path.join(ASSETS_DIR, 'chevron_icon.png'), 'PNG')

if __name__ == "__main__":
    create_channel_card_assets()
    create_header_icons()
    create_header()
    create_status_banner()
    create_section_header()
    create_row_bg()
    create_selected_bar()
    create_delay_icon()
    create_toolbar_icons()
    print("[+] All assets updated successfully.")
