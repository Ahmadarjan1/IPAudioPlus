import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(5)

print("[*] Clearing all menus back to live TV...")
for _ in range(4):
    send_key(1)
    time.sleep(0.3)

time.sleep(1.0)

print("[*] Opening Plugin Browser...")
send_key(399)
time.sleep(1.5)

print("[*] Navigating to IP AudioPlus...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] 1st Press on PLAY (207) -> Start channel playback, pause audio buffer & start counting aDelay...")
send_key(207) # KEY_PLAY
time.sleep(2.6)

print("[*] Capturing screenshot while aDelay is counting...")
take_osd_screenshot("adelay_counting_state.png")

time.sleep(2.0)

print("[*] 2nd Press on PLAY (207) -> Resume audio stream with calculated delay...")
send_key(207) # KEY_PLAY
time.sleep(1.0)

print("[*] Capturing screenshot of resumed audio playback with final aDelay...")
take_osd_screenshot("adelay_resumed_state.png")
print("[+] Finished successfully.")
