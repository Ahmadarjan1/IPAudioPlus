# -*- coding: utf-8 -*-
"""
IPAudioPlus Auto-Update Engine
Checks for new versions on GitHub via raw JSON and performs clean in-place updates.
Supports both .tar.gz archives and .ipk packages.
"""

import os
import re
import sys
import json
import shutil
import urllib.request
import tarfile
import zipfile

CURRENT_VERSION = "1.0"
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
EXTENSIONS_DIR = os.path.dirname(PLUGIN_DIR)

DEFAULT_GITHUB_UPDATE_URL = "https://raw.githubusercontent.com/Ahmadarjan1/IPAudioPlus/main/version.json"

def parse_version(ver_str):
    """Parses version string like '1.2.3' or 'v1.2' into a tuple of ints for comparison."""
    if not ver_str:
        return (0,)
    clean = str(ver_str).lower().replace("v", "").strip()
    digits = re.findall(r"\d+", clean)
    return tuple(int(d) for d in digits) if digits else (0,)

def is_newer_version(remote_ver, local_ver=CURRENT_VERSION):
    """Returns True if remote_ver is strictly greater than local_ver."""
    try:
        return parse_version(remote_ver) > parse_version(local_ver)
    except Exception:
        return str(remote_ver).strip() != str(local_ver).strip()

def check_for_updates(update_url=None, timeout=6):
    """
    Queries GitHub update.json.
    Returns (has_update, update_data, error)
    """
    url = update_url or DEFAULT_GITHUB_UPDATE_URL
    if not url or "http" not in url:
        return False, None, "رابط التحديث غير صالح (Invalid update URL)"

    try:
        headers = {
            "User-Agent": "IPAudioPlus-Updater/1.0 (Enigma2; Linux)",
            "Cache-Control": "no-cache"
        }
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content = resp.read().decode("utf-8")
            data = json.loads(content)

        if not isinstance(data, dict):
            return False, None, "تنسيق ملف التحديث غير صالح (Invalid JSON format)"

        remote_ver = str(data.get("version", "")).strip()
        if not remote_ver:
            return False, None, "ملف التحديث لا يحتوي على رقم الإصدار (Missing version field)"

        has_update = is_newer_version(remote_ver, CURRENT_VERSION)
        update_info = {
            "current_version": CURRENT_VERSION,
            "remote_version": remote_ver,
            "has_update": has_update,
            "name": data.get("name", "IPAudioPlus"),
            "date": data.get("date", ""),
            "description": data.get("description", ""),
            "changelog": data.get("changelog", []),
            "download_url": data.get("download_url", ""),
            "ipk_url": data.get("ipk_url", "")
        }
        return has_update, update_info, None

    except urllib.error.URLError as ue:
        return False, None, f"تعذر الاتصال بـ GitHub: {ue.reason}"
    except Exception as e:
        return False, None, f"خطأ أثناء فحص التحديث: {e}"

def download_and_install_update(download_url, progress_cb=None):
    """
    Downloads update package from download_url and installs it.
    Supports .tar.gz, .tgz, .zip, and .ipk.
    Returns (success, message)
    """
    if not download_url:
        return False, "رابط التحميل فارغ (Empty download URL)"

    try:
        if progress_cb:
            progress_cb("جاري تنزيل ملفات التحديث من GitHub...")

        # Determine archive type and destination
        lower_url = download_url.lower()
        if lower_url.endswith(".ipk"):
            tmp_file = "/tmp/ipaudio_update.ipk"
        elif lower_url.endswith(".zip"):
            tmp_file = "/tmp/ipaudio_update.zip"
        else:
            tmp_file = "/tmp/ipaudio_update.tar.gz"

        # Download with progress
        headers = {"User-Agent": "IPAudioPlus-Updater/1.0 (Enigma2; Linux)"}
        req = urllib.request.Request(download_url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as response, open(tmp_file, "wb") as out_file:
            shutil.copyfileobj(response, out_file)

        if not os.path.exists(tmp_file) or os.path.getsize(tmp_file) == 0:
            return False, "فشل تنزيل ملف التحديث (الملف فارغ)"

        if progress_cb:
            progress_cb("جاري تثبيت التحديث وتحديث الملفات...")

        # Install based on type
        if tmp_file.endswith(".ipk"):
            ret = os.system(f"opkg install --force-reinstall --force-overwrite {tmp_file} >/dev/null 2>&1")
            try:
                os.remove(tmp_file)
            except Exception:
                pass
            if ret != 0:
                return False, "فشل تثبيت حزمة IPK عبر opkg"
            return True, "تم تثبيت حزمة IPK بنجاح!"

        elif tmp_file.endswith(".tar.gz"):
            with tarfile.open(tmp_file, "r:gz") as tar:
                names = tar.getnames()
                # Check if archive already contains 'IPAudioPlus' as top folder
                has_top_folder = any(n.startswith("IPAudioPlus") for n in names)
                target_dest = EXTENSIONS_DIR if has_top_folder else PLUGIN_DIR
                tar.extractall(target_dest)

        elif tmp_file.endswith(".zip"):
            with zipfile.ZipFile(tmp_file, "r") as z:
                names = z.namelist()
                has_top_folder = any(n.startswith("IPAudioPlus") for n in names)
                target_dest = EXTENSIONS_DIR if has_top_folder else PLUGIN_DIR
                z.extractall(target_dest)

        # Cleanup tmp archive
        try:
            os.remove(tmp_file)
        except Exception:
            pass

        # Recompile python files cleanly
        if progress_cb:
            progress_cb("جاري تحسين وترجمة كود البايثون (py_compile)...")

        os.system(f"python3 -m py_compile {PLUGIN_DIR}/*.py >/dev/null 2>&1")

        return True, "تم تثبيت التحديث بنجاح! يرجى إعادة تشغيل واجهة Enigma2 لتطبيق التغييرات."

    except Exception as e:
        return False, f"حدث خطأ أثناء تثبيت التحديث: {e}"

def restart_gui():
    """Restarts Enigma2 GUI."""
    os.system("init 4 && sleep 2 && init 3 &")
