import os
from PIL import Image, ImageDraw

ASSETS_DIR = "images"

def create_adelay_icon():
    w, h = 44, 44
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Outer circle in vibrant cyan / blue or purple
    draw.ellipse([4, 4, w - 5, h - 5], outline=(0, 160, 230, 255), width=3)
    # Speaker / audio wave or clock hands with audio waves
    center_x, center_y = w // 2, h // 2
    # Clock hands
    draw.line([center_x, center_y, center_x, 12], fill=(255, 255, 255, 255), width=2)
    draw.line([center_x, center_y, center_x + 8, center_y], fill=(0, 200, 255, 255), width=2)
    draw.ellipse([center_x - 3, center_y - 3, center_x + 3, center_y + 3], fill=(255, 255, 255, 255))
    
    # Audio waves on right
    draw.arc([center_x + 8, center_y - 12, center_x + 18, center_y + 12], start=-60, end=60, fill=(0, 220, 255, 220), width=2)
    
    img.save(os.path.join(ASSETS_DIR, "icon_adelay.png"), "PNG")
    print("[+] icon_adelay.png created.")

if __name__ == "__main__":
    create_adelay_icon()
