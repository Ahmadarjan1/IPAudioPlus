import sys
sys.path.append('/usr/lib/enigma2/python')
import Components.Timeshift as TS
from Screens.InfoBar import InfoBar

print("TS dir:", dir(TS))
for name in dir(TS):
    cls = getattr(TS, name)
    if isinstance(cls, type):
        print(f"Class {name}:", [m for m in dir(cls) if not m.startswith("__")])
