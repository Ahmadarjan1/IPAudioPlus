import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(5)

print("[*] Clearing to main screen...")
send_key(1)
time.sleep(0.5)
send_key(1)
time.sleep(0.5)

print("[*] Opening Plugin Browser (Green)...")
send_key(399)
time.sleep(1.5)

print("[*] Navigating to IP AudioPlus (Down, Down, OK)...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] Capturing Main Screen with dynamically loaded Orange channels...")
take_osd_screenshot("main_screen_orange_loaded.png")

print("[*] Opening Server List Popup (UP key)...")
send_key(103) # UP
time.sleep(0.5)

print("[*] Capturing Server List Popup...")
take_osd_screenshot("server_popup_orange_loaded.png")

print("[+] Done.")
