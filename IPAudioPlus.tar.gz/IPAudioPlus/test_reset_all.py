import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(5)

print("[*] Clearing to main screen...")
send_key(1)
time.sleep(0.5)
send_key(1)
time.sleep(0.5)

print("[*] Opening Plugin Browser (Green)...")
send_key(399)
time.sleep(1.5)

print("[*] Opening IP AudioPlus...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] Pressing OK on channel 1 to start playback...")
send_key(352) # OK
time.sleep(1.0)
take_osd_screenshot("audioplus_playing_state.png")

print("[*] Pressing Yellow button (code 400) for Reset all...")
send_key(400) # Yellow (Reset all)
time.sleep(1.0)

print("[*] Capturing screenshot of Reset all state...")
take_osd_screenshot("audioplus_reset_all_state.png")
print("[+] Done.")
