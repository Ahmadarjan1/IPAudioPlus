import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(5)

print("[*] Clearing to main screen...")
send_key(1)
time.sleep(0.5)
send_key(1)
time.sleep(0.5)

print("[*] Opening Plugin Browser (Green)...")
send_key(399)
time.sleep(1.5)

print("[*] Navigating to IP AudioPlus (Down, Down, OK)...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] Pressing MENU (139) to open Config Screen...")
send_key(139) # MENU
time.sleep(1.5)

print("[*] Capturing Config Screen (Top option: Show in Main Menu)...")
take_osd_screenshot("config_screen_top.png")

print("[*] Navigating down to Sink engine...")
# 3 items, sep, 1 item, sep, 1 item, 3 switches -> Sink engine is around item 10
for _ in range(7):
    send_key(108)
    time.sleep(0.3)

time.sleep(0.5)
print("[*] Capturing Config Screen (Sink engine)...")
take_osd_screenshot("config_screen_sink.png")

print("[*] Navigating down to Volume and changing to +20%...")
send_key(108) # Volume
time.sleep(0.3)
send_key(106) # Right -> +20%
time.sleep(0.5)

print("[*] Capturing Config Screen (Volume +20%)...")
take_osd_screenshot("config_screen_volume.png")

print("[+] Done.")
