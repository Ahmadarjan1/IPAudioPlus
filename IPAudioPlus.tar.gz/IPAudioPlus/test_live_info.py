import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(6)

print("[*] Clearing menus...")
for _ in range(3):
    send_key(1)
    time.sleep(0.3)

time.sleep(1.0)

print("[*] Opening Plugin Browser...")
send_key(399) # GREEN
time.sleep(1.5)

print("[*] Navigating to IP AudioPlus...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] Pressing BLUE (401) to open Live Info...")
send_key(401) # KEY_BLUE
time.sleep(1.5)

print("[*] Capturing Live Info screenshot...")
take_osd_screenshot("live_info_opened.png")

print("[*] Navigating Down in Live Info...")
send_key(108) # Down
time.sleep(0.8)

print("[*] Capturing navigated Live Info screenshot...")
take_osd_screenshot("live_info_navigated.png")

print("[*] Pressing OK (352) to play selected match audio...")
send_key(352) # OK
time.sleep(1.5)

print("[*] Capturing screenshot after playing match audio...")
take_osd_screenshot("live_info_played.png")

print("[+] Done.")
