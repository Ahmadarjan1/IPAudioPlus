import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(5)

print("[*] Clearing all open menus...")
for _ in range(4):
    send_key(1)
    time.sleep(0.3)

time.sleep(1.0)

print("[*] Opening Plugin Browser...")
send_key(399)
time.sleep(1.5)

print("[*] Navigating to IP AudioPlus...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] Pressing MENU (139) to open IPAudioPlusConfigScreen...")
send_key(139) # KEY_MENU
time.sleep(1.5)

print("[*] Capturing screenshot of Config Screen...")
take_osd_screenshot("config_screen_opened.png")

print("[*] Navigating down in Config Screen...")
for _ in range(7):
    send_key(108) # Down
    time.sleep(0.3)

print("[*] Pressing Right (106) to change Volume...")
send_key(106) # Right
time.sleep(0.5)

print("[*] Capturing screenshot with modified option...")
take_osd_screenshot("config_screen_modified.png")

print("[*] Pressing Green (399) to Save settings...")
send_key(399) # KEY_GREEN (Save)
time.sleep(1.5)

print("[*] Capturing screenshot after Save...")
take_osd_screenshot("config_screen_saved_return.png")
print("[+] Finished successfully.")
