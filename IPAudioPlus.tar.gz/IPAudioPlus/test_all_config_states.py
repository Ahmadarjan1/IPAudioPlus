import time
from send_key import send_key
from manage_stb import take_osd_screenshot

print("[*] Navigating to Volume...")
send_key(108) # Move down to Volume
time.sleep(0.3)
send_key(106) # Change to +20%
time.sleep(0.4)
take_osd_screenshot("config_volume_20.png")

send_key(106) # Change to +50%
time.sleep(0.4)
take_osd_screenshot("config_volume_50.png")

print("[*] Moving to Sink engine...")
send_key(103) # Move up to Sink engine
time.sleep(0.3)
send_key(106) # gst-play
time.sleep(0.3)
send_key(106) # ffmpeg
time.sleep(0.4)
take_osd_screenshot("config_sink_ffmpeg.png")

print("[+] All config states captured.")
