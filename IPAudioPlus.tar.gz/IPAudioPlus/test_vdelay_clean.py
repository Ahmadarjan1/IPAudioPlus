import time
from send_key import send_key
from manage_stb import take_osd_screenshot

print("[*] Clearing all menus back to live TV...")
for _ in range(4):
    send_key(1)
    time.sleep(0.3)

time.sleep(1.0)

print("[*] Opening Plugin Browser...")
send_key(399)
time.sleep(1.5)

print("[*] Navigating to IP AudioPlus...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] 1st Press on PAUSE (119) -> Pause timeshift and start counting vDelay...")
send_key(119) # KEY_PAUSE
time.sleep(3.2)

print("[*] Capturing screenshot while vDelay is counting...")
take_osd_screenshot("vdelay_counting_live.png")

time.sleep(2.8)

print("[*] 2nd Press on PAUSE (119) -> Resume timeshift playback at delayed offset...")
send_key(119) # KEY_PAUSE
time.sleep(1.0)

print("[*] Capturing screenshot of resumed timeshift playback with final vDelay...")
take_osd_screenshot("vdelay_resumed_live.png")
print("[+] Finished successfully.")
