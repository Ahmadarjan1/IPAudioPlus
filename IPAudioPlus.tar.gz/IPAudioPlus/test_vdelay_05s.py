import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(5)

print("[*] Clearing all menus back to live TV...")
for _ in range(4):
    send_key(1)
    time.sleep(0.3)

time.sleep(1.0)

print("[*] Opening Plugin Browser...")
send_key(399)
time.sleep(1.5)

print("[*] Navigating to IP AudioPlus...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] 1st Press on PAUSE (119) -> Start counting vDelay in 0.5s increments...")
send_key(119) # KEY_PAUSE
time.sleep(2.6)

print("[*] Capturing screenshot while vDelay is counting with 0.5s precision...")
take_osd_screenshot("vdelay_05s_counting.png")

time.sleep(2.0)

print("[*] 2nd Press on PAUSE (119) -> Resume timeshift with exact 0.5s precision delay...")
send_key(119) # KEY_PAUSE
time.sleep(1.0)

print("[*] Capturing screenshot of resumed timeshift with final 0.5s precision delay...")
take_osd_screenshot("vdelay_05s_resumed.png")
print("[+] Finished successfully.")
