import os
from ssh_helper import upload_file, run_cmd

KEYMAP_AUDIOPLUS = """<keymap>
    <map context="AudioPlusActions">
        <key id="KEY_EXIT" mapto="cancel" flags="m" />
        <key id="KEY_ESC" mapto="cancel" flags="m" />
        <key id="KEY_OK" mapto="ok" flags="m" />
        <key id="KEY_ENTER" mapto="ok" flags="m" />
        <key id="KEY_UP" mapto="up" flags="mr" />
        <key id="KEY_DOWN" mapto="down" flags="mr" />
        <key id="KEY_LEFT" mapto="left" flags="mr" />
        <key id="KEY_RIGHT" mapto="right" flags="mr" />
        <key id="KEY_RED" mapto="red" flags="m" />
        <key id="KEY_GREEN" mapto="green" flags="m" />
        <key id="KEY_YELLOW" mapto="yellow" flags="m" />
        <key id="KEY_BLUE" mapto="blue" flags="m" />
        <key id="KEY_MENU" mapto="menu" flags="m" />
        <key id="KEY_STOP" mapto="stop" flags="m" />
        <key id="KEY_PLAY" mapto="play" flags="m" />
        <key id="KEY_PAUSE" mapto="pause" flags="m" />
        <key id="KEY_PREVIOUS" mapto="audioDelayMinus" flags="mr" />
        <key id="KEY_NEXT" mapto="audioDelayPlus" flags="mr" />
        <key id="KEY_REWIND" mapto="tsDelayMinus" flags="mr" />
        <key id="KEY_FASTFORWARD" mapto="tsDelayPlus" flags="mr" />
    </map>
</keymap>
"""

INIT_AUDIOPLUS = """# -*- coding: utf-8 -*-
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import os
"""

with open("audioplus_keymap_exact.xml", "w", encoding="utf-8") as f:
    f.write(KEYMAP_AUDIOPLUS)

with open("audioplus_init_exact.py", "w", encoding="utf-8") as f:
    f.write(INIT_AUDIOPLUS)

print("[*] Uploading exact original plugin.py...")
upload_file("AudioPlus_plugin_old.py", "/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/plugin.py")

print("[*] Uploading exact keymap.xml...")
upload_file("audioplus_keymap_exact.xml", "/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/keymap.xml")

print("[*] Uploading exact __init__.py...")
upload_file("audioplus_init_exact.py", "/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/__init__.py")

# Clean foreign images from AudioPlus/images
clean_cmd = """
cd /usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images
rm -f bar_blue.png bar_green.png bar_red.png bar_yellow.png
rm -f channel_selected_bg.png header_banner.png icon_delay.png icon_exit.png icon_settings.png
rm -f row_dark_bg.png section_header_bg.png server_expanded_hdr.png server_row_dark.png server_row_slate.png server_selected_bg.png status_bg.png
rm -f /usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/*.pyc
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/__pycache__
"""
print("[*] Cleaning foreign images from AudioPlus...")
run_cmd(clean_cmd)

print("[+] AudioPlus completely restored to 100% original state.")
