import urllib.request
import time
import sys

HOST = "192.168.100.132"

def send_key(code):
    url = f"http://{HOST}/web/remotecontrol?command={code}"
    try:
        with urllib.request.urlopen(url, timeout=3) as resp:
            return resp.read().decode('utf-8')
    except Exception as e:
        print(f"Error sending key {code}: {e}")
        return None

if __name__ == "__main__":
    # Key codes:
    # 139 = Menu
    # 352 = OK
    # 1 = Exit
    # 103 = Up
    # 108 = Down
    # 398 = Red
    # 399 = Green
    # 400 = Yellow
    # 401 = Blue
    if len(sys.argv) > 1:
        for k in sys.argv[1:]:
            print(f"Sending key: {k}")
            send_key(k)
            time.sleep(0.4)
