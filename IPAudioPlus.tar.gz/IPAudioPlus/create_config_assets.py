import os
from PIL import Image, ImageDraw, ImageFont

ASSETS_DIR = "images"
os.makedirs(ASSETS_DIR, exist_ok=True)

# 1. Header Banner for Config (692 x 84)
def create_config_header():
    w, h = 692, 84
    img = Image.new("RGBA", (w, h), (0, 122, 196, 255))
    draw = ImageDraw.Draw(img)
    
    # Mic Icon
    mic_x, mic_y = 52, 42
    draw.arc([mic_x - 22, mic_y - 22, mic_x + 22, mic_y + 22], start=45, end=135, fill=(255, 255, 255, 180), width=3)
    draw.arc([mic_x - 27, mic_y - 27, mic_x + 27, mic_y + 27], start=45, end=135, fill=(255, 255, 255, 130), width=2)
    draw.rounded_rectangle([mic_x - 7, mic_y - 18, mic_x + 7, mic_y + 4], radius=6, fill=(255, 255, 255, 255))
    draw.arc([mic_x - 12, mic_y - 8, mic_x + 12, mic_y + 10], start=0, end=180, fill=(255, 255, 255, 255), width=3)
    draw.line([mic_x, mic_y + 10, mic_x, mic_y + 18], fill=(255, 255, 255, 255), width=3)
    draw.line([mic_x - 9, mic_y + 18, mic_x + 9, mic_y + 18], fill=(255, 255, 255, 255), width=3)
    draw.line([mic_x - 5, mic_y - 10, mic_x + 5, mic_y - 10], fill=(0, 122, 196, 255), width=2)
    draw.line([mic_x - 5, mic_y - 4, mic_x + 5, mic_y - 4], fill=(0, 122, 196, 255), width=2)
    draw.line([mic_x - 5, mic_y + 1, mic_x + 5, mic_y + 1], fill=(0, 122, 196, 255), width=2)

    try:
        font_bold = ImageFont.truetype("arialbd.ttf", 46)
        font_plus = ImageFont.truetype("arialbd.ttf", 32)
        font_cfg = ImageFont.truetype("arialbd.ttf", 30)
    except Exception:
        font_bold = ImageFont.load_default()
        font_plus = font_bold
        font_cfg = font_bold
        
    draw.text((96, 15), "IP AUDIO", fill=(255, 255, 255, 255), font=font_bold)
    draw.text((328, 12), "+", fill=(255, 255, 255, 255), font=font_plus)
    
    # "Config" on right
    draw.text((w - 118, 24), "Config", fill=(255, 255, 255, 255), font=font_cfg)
    img.save(os.path.join(ASSETS_DIR, "header_config_banner.png"), "PNG")
    print("[+] Config header banner created.")

# 2. Toggle Switches (46 x 20)
def create_switches():
    w, h = 48, 20
    # ON Switch (Left blue #0080c8 with white slider thumb, right grey)
    img_on = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d_on = ImageDraw.Draw(img_on)
    d_on.rounded_rectangle([0, 0, w - 1, h - 1], radius=10, fill=(35, 45, 60, 255), outline=(50, 65, 85, 255), width=1)
    # Blue fill on left half
    d_on.rounded_rectangle([0, 0, w//2 + 4, h - 1], radius=10, fill=(0, 128, 200, 255))
    # White slider thumb
    d_on.rounded_rectangle([14, 2, 28, h - 3], radius=6, fill=(255, 255, 255, 255))
    img_on.save(os.path.join(ASSETS_DIR, "switch_on.png"), "PNG")

    # OFF Switch (Grey pill with white circle thumb)
    img_off = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d_off = ImageDraw.Draw(img_off)
    d_off.rounded_rectangle([0, 0, w - 1, h - 1], radius=10, fill=(35, 45, 60, 255), outline=(50, 65, 85, 255), width=1)
    # White slider thumb on right or left
    d_off.ellipse([28, 3, 44, h - 4], fill=(255, 255, 255, 255))
    img_off.save(os.path.join(ASSETS_DIR, "switch_off.png"), "PNG")
    print("[+] Switches created.")

# 3. Dotted Separator Line (574 x 2)
def create_dotted_line():
    w, h = 574, 4
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    dot_len = 4
    gap_len = 4
    x = 0
    while x < w:
        d.line([x, 2, min(x + dot_len, w), 2], fill=(0, 102, 160, 255), width=2)
        x += dot_len + gap_len
    img.save(os.path.join(ASSETS_DIR, "dotted_line.png"), "PNG")
    print("[+] Dotted line created.")

# 4. Config Selected Row Bar (574 x 46)
def create_config_sel_bar():
    w, h = 574, 46
    img = Image.new("RGBA", (w, h), (0, 128, 200, 255))
    img.save(os.path.join(ASSETS_DIR, "config_selected_bg.png"), "PNG")

if __name__ == "__main__":
    create_config_header()
    create_switches()
    create_dotted_line()
    create_config_sel_bar()
    print("[+] Config assets generated successfully.")
