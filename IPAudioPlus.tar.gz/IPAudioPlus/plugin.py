import io

import urllib.request

# -*- coding: utf-8 -*-

# IP AudioPlus Plugin for Enigma2

# Pixel-perfect UI implementation matching reference design with Dynamic Server List Popup & Config Screen



import os

import signal

import json

import time

import subprocess

import fcntl

import re

import threading

from concurrent.futures import ThreadPoolExecutor

from datetime import datetime



from enigma import (

    eListboxPythonMultiContent,

    gFont,

    eTimer,

    eSize,

    addFont,

    RT_HALIGN_LEFT,

    RT_HALIGN_RIGHT,

    RT_HALIGN_CENTER,

    RT_VALIGN_CENTER,

    loadPNG,

    ePoint

)

from Components.ActionMap import ActionMap
try:
    from keymapparser import readKeymap as loadKeymap
except Exception:
    try:
        from Components.ActionMap import loadKeymap
    except Exception:
        def loadKeymap(filename):
            pass

from Components.Label import Label

from Components.Pixmap import Pixmap

from Components.MenuList import MenuList

from Components.MultiContent import (

    MultiContentEntryText,

    MultiContentEntryPixmapAlphaBlend,

    MultiContentEntryRectangle

)

from Components.config import (

    config,

    configfile,

    ConfigSubsection,

    ConfigText,

    ConfigSelection,

    ConfigYesNo

)

from Screens.Screen import Screen

from Screens.MessageBox import MessageBox

from Screens.VirtualKeyBoard import VirtualKeyBoard

from Plugins.Plugin import PluginDescriptor



try:

    from .auto_sync_engine import AutoSyncEngine

except Exception:

    try:

        from auto_sync_engine import AutoSyncEngine

    except Exception:

        AutoSyncEngine = None



PLUGIN_PATH = os.path.dirname(__file__)

IMG_PATH = os.path.join(PLUGIN_PATH, "images")



def set_pix(widget, filename):

    try:

        p = os.path.join(IMG_PATH, filename)

        if os.path.exists(p) and hasattr(widget, "instance") and widget.instance:

            widget.instance.setPixmap(loadPNG(p))

    except Exception:

        pass

FONT_PATH = os.path.join(PLUGIN_PATH, "fonts")



# # Register Bold Font (Dubai Bold / Cairo)

try:

    dubai_f = os.path.join(FONT_PATH, "dubai-bold.ttf")

    if os.path.exists(dubai_f):

        addFont(dubai_f, "Bold", 100, True)

        addFont(dubai_f, "Regular", 100, True)

        addFont(dubai_f, "IPAudioBold", 100, True)

    

    # Register full Arabic Unicode font for Developer Info & About dialog

    tahoma_f = os.path.join(FONT_PATH, "tahomabd.ttf")

    if os.path.exists(tahoma_f):

        addFont(tahoma_f, "DeveloperFont", 100, True)

        print("[IPAudioPlus] DeveloperFont registered with tahomabd.ttf")

    elif os.path.exists("/usr/share/fonts/nmsbd.ttf"):

        addFont("/usr/share/fonts/nmsbd.ttf", "DeveloperFont", 100, True)

        print("[IPAudioPlus] DeveloperFont registered with nmsbd.ttf")

except Exception as e:

    print(f"[IPAudioPlus] Error registering font: {e}")



# Load plugin keymap

keymap_path = os.path.join(PLUGIN_PATH, "keymap.xml")

if os.path.exists(keymap_path):
    try:
        loadKeymap(keymap_path)
    except Exception as e:
        print("[IPAudioPlus] Error loading keymap:", e)



# DVB Mute ioctl

AUDIO_SET_MUTE = 0x00006f06



# Config setup

config.plugins.IPAudioPlus = ConfigSubsection()

config.plugins.IPAudioPlus.playlist_path = ConfigText(default="default", fixed_size=False)

config.plugins.IPAudioPlus.last_server = ConfigText(default="1", fixed_size=False)

config.plugins.IPAudioPlus.vdelay = ConfigText(default="0", fixed_size=False)



# Config Settings

config.plugins.IPAudioPlus.show_main_menu = ConfigSelection(default="ON", choices=[("ON", "ON"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.show_plugin_list = ConfigSelection(default="ON", choices=[("ON", "ON"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.show_extension_list = ConfigSelection(default="ON", choices=[("ON", "ON"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.web_interface = ConfigSelection(default="ON", choices=[("ON", "ON"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.web_port = ConfigSelection(default="8089", choices=[("8089", "8089"), ("8088", "8088"), ("8090", "8090"), ("8091", "8091")])

config.plugins.IPAudioPlus.timeout = ConfigSelection(default="10 sec.", choices=[("5 sec.", "5 sec."), ("10 sec.", "10 sec."), ("15 sec.", "15 sec."), ("20 sec.", "20 sec.")])

config.plugins.IPAudioPlus.port = ConfigSelection(default="8001", choices=[("8001", "8001"), ("8002", "8002"), ("8080", "8080")])

config.plugins.IPAudioPlus.descramble_http = ConfigSelection(default="ON", choices=[("ON", "ON"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.auth_http = ConfigSelection(default="OFF", choices=[("ON", "ON"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.ecm_http = ConfigSelection(default="OFF", choices=[("ON", "ON"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.sink_engine = ConfigSelection(default="gst-launch", choices=[("gst-launch", "gst-launch"), ("gst-play", "gst-play"), ("ffmpeg", "ffmpeg"), ("eXteplayer3", "eXteplayer3"), ("alsa", "alsa")])

config.plugins.IPAudioPlus.volume = ConfigSelection(default="normal", choices=[("normal", "normal"), ("+20%", "+20%"), ("+50%", "+50%"), ("+100%", "+100%"), ("-20%", "-20%")])

config.plugins.IPAudioPlus.user_list_path = ConfigSelection(default="default", choices=[("default", "default"), ("/etc/enigma2/", "/etc/enigma2/"), ("/media/hdd/", "/media/hdd/")])

config.plugins.IPAudioPlus.check_update = ConfigSelection(default="ON", choices=[("ON", "ON"), ("OFF", "OFF")])
config.plugins.IPAudioPlus.update_url = ConfigText(default="https://raw.githubusercontent.com/Ahmadarjan1/IPAudioPlus/main/version.json", fixed_size=False)

config.plugins.IPAudioPlus.elastic_buffer = ConfigSelection(default="ON", choices=[("ON", "ON"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.anti_spoiler = ConfigSelection(default="ON", choices=[("ON", "ON"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.anti_spoiler_margin = ConfigSelection(default="250 ms", choices=[("150 ms", "150 ms"), ("250 ms", "250 ms"), ("350 ms", "350 ms"), ("500 ms", "500 ms")])

config.plugins.IPAudioPlus.silent_corrector = ConfigSelection(default="10 min", choices=[("5 min", "5 min"), ("10 min", "10 min"), ("15 min", "15 min"), ("OFF", "OFF")])

config.plugins.IPAudioPlus.time_stretch = ConfigSelection(default="OFF", choices=[("OFF", "OFF (1.0x Exact Speed)"), ("Auto", "Auto (1.0x)"), ("0.998x", "0.998x"), ("0.999x", "0.999x"), ("1.001x", "1.001x")])

config.plugins.IPAudioPlus.timeshift_storage = ConfigSelection(

    default="Auto-Detect",

    choices=[

        ("Auto-Detect", "Auto-Detect (Recommended)"),

        ("Internal Flash", "Internal Flash (/media/root) - Not Recommended"),

        ("Custom Path", "Custom Path...")

    ]

)

config.plugins.IPAudioPlus.timeshift_custom_path = ConfigText(default="/media/hdd/timeshift/", fixed_size=False)





def get_effective_timeshift_path():

    """

    Evaluates the chosen Timeshift Storage mount point.

    Auto-Detect checks mounted disks (/media/hdd, /media/usb, /media/usb1, /media/mmc)

    and chooses the best external storage with write access and free space.

    """

    mode = config.plugins.IPAudioPlus.timeshift_storage.value

    if "Auto-Detect" in mode:

        candidates = ["/media/hdd", "/media/usb", "/media/usb1", "/media/mmc", "/media/net"]

        for cand in candidates:

            if os.path.exists(cand):

                try:

                    ts_dir = os.path.join(cand, "timeshift")

                    os.makedirs(ts_dir, exist_ok=True)

                    test_file = os.path.join(ts_dir, ".ts_test")

                    with open(test_file, "w") as f:

                        f.write("ok")

                    os.remove(test_file)

                    return ts_dir

                except Exception:

                    continue

        if os.path.exists("/media/hdd"):

            return "/media/hdd/timeshift"

        return "/tmp/timeshift"

    elif "Internal Flash" in mode:

        ts_dir = "/media/root/timeshift"

        try:

            os.makedirs(ts_dir, exist_ok=True)

        except Exception:

            pass

        return ts_dir

    else:

        custom = config.plugins.IPAudioPlus.timeshift_custom_path.value

        try:

            os.makedirs(custom, exist_ok=True)

        except Exception:

            pass

        return custom





def apply_timeshift_storage():

    """Applies target timeshift storage path into Enigma2 usage configurations."""

    target_path = get_effective_timeshift_path()

    try:

        from Components.config import config

        if hasattr(config, "usage") and hasattr(config.usage, "timeshift_path"):

            config.usage.timeshift_path.value = target_path

            config.usage.timeshift_path.save()

        if hasattr(config, "timeshift"):

            if hasattr(config.timeshift, "path"):

                config.timeshift.path.value = target_path

                config.timeshift.path.save()

            if hasattr(config.timeshift, "timeshift_path"):

                config.timeshift.timeshift_path.value = target_path

                config.timeshift.timeshift_path.save()

    except Exception:

        pass

    return target_path





class CumulativeDriftPredictor:

    """

    خوارزمية تصحيح الانزياح التراكمي بمرور الوقت (Time-Cumulative Drift Engine):

    Tracks drift measurements over the full 90 minutes and learns the clock skew rate.

    Proactively anticipates and counteracts oscillator drift before it becomes perceptible.

    """

    def __init__(self):

        self.history = []

        self.cumulative_correction_ms = 0.0

        self.start_time = time.time()

        self.estimated_skew_ppm = 0.0



    def record_measurement(self, drift_ms):

        now = time.time()

        elapsed = now - self.start_time

        self.history.append((elapsed, drift_ms))

        if len(self.history) > 10:

            self.history.pop(0)



        if len(self.history) >= 2:

            t_first, d_first = self.history[0]

            t_last, d_last = self.history[-1]

            dt = t_last - t_first

            if dt >= 60.0:

                skew = (d_last - d_first) / dt

                self.estimated_skew_ppm = skew * 1000.0



    def predict_drift_in(self, future_seconds):

        skew_ms_per_sec = self.estimated_skew_ppm / 1000.0

        return skew_ms_per_sec * future_seconds





# ==========================================

# Listbox Components

# ==========================================

class AudioChannelList(MenuList):

    def __init__(self, list_items, enableWrapAround=True):

        MenuList.__init__(self, list_items, enableWrapAround, eListboxPythonMultiContent)

        self.l.setFont(0, gFont("Bold", 22))

        self.l.setFont(1, gFont("Bold", 16))

        self.l.setItemHeight(60)





class ServerList(MenuList):

    def __init__(self, list_items, enableWrapAround=True):

        MenuList.__init__(self, list_items, enableWrapAround, eListboxPythonMultiContent)

        self.l.setFont(0, gFont("Bold", 24))

        self.l.setFont(1, gFont("Bold", 15))

        self.l.setItemHeight(60)





class ConfigMenuList(MenuList):

    def __init__(self, list_items, enableWrapAround=True):

        MenuList.__init__(self, list_items, enableWrapAround, eListboxPythonMultiContent)

        self.l.setFont(0, gFont("Bold", 23))

        self.l.setFont(1, gFont("Regular", 21))

        self.l.setItemHeight(42)





class LiveInfoList(MenuList):

    def __init__(self, list_items, enableWrapAround=True):

        MenuList.__init__(self, list_items, enableWrapAround, eListboxPythonMultiContent)

        self.l.setFont(0, gFont("Bold", 20))  # TV & Commentator info

        self.l.setFont(1, gFont("Bold", 23))  # Team names

        self.l.setFont(2, gFont("Bold", 17))  # League & Status badge & Action prompt

        self.l.setFont(3, gFont("Bold", 30))  # Live Score / FT score

        self.l.setItemHeight(246)





TEAM_LOGOS_DIR = os.path.join(PLUGIN_PATH, "logos", "teams")

_team_logo_cache = {}



def get_team_logo_pix(team_id, team_name="", logo_url=""):

    """

    Returns an ePtr<gPixmap> for the team crest.

    Caches logos permanently in logos/teams/{team_id}.png as 64x64 RGBA PNGs.

    If not yet downloaded, returns default_crest.png while fetching asynchronously.

    """

    key = str(team_id).strip() if team_id else re.sub(r'[^a-zA-Z0-9_]', '', (team_name or "default").lower())

    if not key:

        key = "default"



    if key in _team_logo_cache:

        return _team_logo_cache[key]



    default_p = os.path.join(TEAM_LOGOS_DIR, "default_crest.png")

    dest = os.path.join(TEAM_LOGOS_DIR, f"{key}.png")



    if os.path.exists(dest) and os.path.getsize(dest) > 100:

        try:

            pix = loadPNG(dest)

            _team_logo_cache[key] = pix

            return pix

        except Exception:

            pass



    # Download in background if URL is provided

    if logo_url:

        def _download_worker():

            try:

                os.makedirs(TEAM_LOGOS_DIR, exist_ok=True)

                req = urllib.request.Request(logo_url)

                with urllib.request.urlopen(req, timeout=4) as resp:

                    data = resp.read()

                from PIL import Image

                im = Image.open(io.BytesIO(data)).convert("RGBA")

                im_resized = im.resize((64, 64), Image.Resampling.LANCZOS)

                im_resized.save(dest, format="PNG")

            except Exception:

                pass



        threading.Thread(target=_download_worker, daemon=True).start()



    # Fallback to default crest

    if os.path.exists(default_p):

        try:

            pix = loadPNG(default_p)

            _team_logo_cache[key] = pix

            return pix

        except Exception:

            pass



    return None





ARABIC_TEAMS = {

    # Premier League

    "Arsenal": "أرسنال", "Aston Villa": "أستون فيلا", "Bournemouth": "بورنموث",

    "Brentford": "برينتفورد", "Brighton": "برايتون", "Chelsea": "تشيلسي",

    "Crystal Palace": "كريستال بالاس", "Everton": "إيفرتون", "Fulham": "فولهام",

    "Ipswich Town": "إيبسويتش تاون", "Leicester City": "ليستر سيتي", "Liverpool": "ليفربول",

    "Man City": "مانشستر سيتي", "Manchester City": "مانشستر سيتي", "Man United": "مانشستر يونايتد",

    "Manchester United": "مانشستر يونايتد", "Newcastle": "نيوكاسل", "Nottingham Forest": "نوتينغهام فورست",

    "Southampton": "ساوثهامبتون", "Tottenham": "توتنهام", "West Ham": "وست هام",

    "Wolves": "وولفرهامبتون", "Wolverhampton": "وولفرهامبتون",

    

    # La Liga

    "Real Madrid": "ريال مدريد", "Barcelona": "برشلونة", "Atletico Madrid": "أتلتيكو مدريد",

    "Athletic Club": "أتلتيك بلباو", "Athletic Bilbao": "أتلتيك بلباو", "Real Sociedad": "ريال سوسيداد",

    "Real Betis": "ريال بيتيس", "Villarreal": "فياريال", "Sevilla": "إشبيلية", "Valencia": "فالنسيا",

    "Girona": "جيرونا", "Celta Vigo": "سيلتا فيغو", "Osasuna": "أوساسونا", "Mallorca": "مايوركا",

    "Getafe": "خيتافي", "Rayo Vallecano": "رايو فاليكانو", "Las Palmas": "لاس بالماس",

    "Alaves": "ديبورتيفو ألافيس", "Leganes": "ليغانيس", "Valladolid": "بلد الوليد",

    "Espanyol": "إسبانيول", "Elche": "إلتشي", "Racing Santander": "راسينغ سانتاندير",

    

    # Serie A

    "Inter Milan": "إنتر ميلان", "Inter": "إنتر ميلان", "AC Milan": "ميلان", "Milan": "ميلان",

    "Juventus": "يوفنتوس", "Napoli": "نابولي", "Roma": "روما", "Lazio": "لاتسيو",

    "Atalanta": "أتالانتا", "Fiorentina": "فيورنتينا", "Bologna": "بولونيا", "Torino": "تورينو",

    "Monza": "مونزا", "Genoa": "جنوى", "Udinese": "أودينيزي", "Cagliari": "كالياري",

    "Parma": "بارما", "Como": "كومو", "Empoli": "إمبولي", "Lecce": "ليتشي",

    "Venezia": "فينيسيا", "Verona": "هيلاس فيرونا",

    

    # Bundesliga

    "Bayern Munich": "بايرن ميونخ", "Borussia Dortmund": "دورتموند", "Dortmund": "دورتموند",

    "Bayer Leverkusen": "باير ليفركوزن", "Leverkusen": "باير ليفركوزن", "RB Leipzig": "لايبزيغ",

    "Leipzig": "لايبزيغ", "Eintracht Frankfurt": "آينتراخت فرانكفورت", "Frankfurt": "فرانكفورت",

    "VfB Stuttgart": "شتوتغارت", "Stuttgart": "شتوتغارت", "Borussia Monchengladbach": "مونشنغلادباخ",

    "Wolfsburg": "فولفسبورغ", "Freiburg": "فرايبورغ", "Hoffenheim": "هوفنهايم",

    "Werder Bremen": "فيردر بريمن", "Union Berlin": "يونيون برلين", "Augsburg": "أوغسبورغ",

    "Heidenheim": "هايدنهايم", "Mainz": "ماينتس", "St. Pauli": "سانت باولي",

    "Holstein Kiel": "هولشتاين كيل",

    

    # Ligue 1

    "Paris Saint-Germain": "باريس سان جيرمان", "PSG": "باريس سان جيرمان", "Marseille": "مارسيليا",

    "Monaco": "موناكو", "Lyon": "ليون", "Lille": "ليل", "Nice": "نيس", "Lens": "لانس",

    "Rennes": "رين", "Reims": "ريمس", "Brest": "بريست", "Strasbourg": "ستراسبورغ",

    "Toulouse": "تولوز", "Nantes": "نانت", "Auxerre": "أوكسير", "Angers": "أنجيه",

    "Le Havre": "لوهافر", "Saint-Etienne": "سانت إيتيان", "Montpellier": "مونبلييه",

    "Lorient": "لوريان",

    

    # Saudi SPL

    "Al Hilal": "الهلال", "Al Nassr": "النصر", "Al Ittihad": "الاتحاد", "Al Ahli": "الأهلي",

    "Al Shabab": "الشباب", "Al Ettifaq": "الاتفاق", "Al Taawoun": "التعاون", "Al Fateh": "الفتح",

    "Al Wehda": "الوحدة", "Al Raed": "الرائد", "Al Khaleej": "الخليج", "Damac": "ضمك",

    "Al Fayha": "الفيحاء", "Al Riyadh": "الرياض", "Al Akhdoud": "الأخدود", "Al Orobah": "العروبة",

    "Al Qadsiah": "القادسية", "Al Kholood": "الخلود", "Al-Faisaly": "الفيصلي", "Al Hazem": "الحزم",

}



def translate_team_name(name):

    if not name:

        return ""

    clean = name.strip()

    if clean in ARABIC_TEAMS:

        return ARABIC_TEAMS[clean]

    for en, ar in ARABIC_TEAMS.items():

        if en.lower() == clean.lower() or en.lower() in clean.lower():

            return ar

    return clean





def build_live_info_entry(item, is_selected=False):

    match_title = item.get("match_title") or item.get("match", "Match")

    res = [(match_title, is_selected)]



    # 1. Background Card with Rounded Corners (780 x 240)

    bg_img = "live_card_selected.png" if is_selected else "live_card_normal.png"

    p = os.path.join(IMG_PATH, bg_img)

    if os.path.exists(p):

        res.append(

            MultiContentEntryPixmapAlphaBlend(

                pos=(0, 0),

                size=(780, 240),

                png=loadPNG(p)

            )

        )



    # 2. League Badge (Top Left)

    league_name = item.get("league", "مباراة اليوم")

    res.append(

        MultiContentEntryText(

            pos=(28, 10),

            size=(440, 26),

            font=2,

            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,

            text=f"🏆  {league_name}",

            color=0x0038bdf8 if is_selected else 0x0094a3b8,

            color_sel=0x0038bdf8

        )

    )



    # 3. Match Status Badge (Top Right)

    status_state = item.get("status_state", "pre")

    status_detail = item.get("status_detail", "").strip()

    time_str = item.get("time", "")



    if status_state == "in":

        if "ht" in status_detail.lower() or "half" in status_detail.lower():

            st_text = "● مباشر (استراحة)"

        elif status_detail:

            st_text = f"● مباشر ({status_detail})"

        else:

            st_text = "● مباشر LIVE"

        st_color = 0x00ef4444  # Vivid Red

    elif status_state == "post":

        st_text = "نهاية المباراة FT"

        st_color = 0x0094a3b8  # Dim Slate

    else:

        st_text = f"⏰  {time_str}"

        st_color = 0x0010b981  # Emerald Green



    res.append(

        MultiContentEntryText(

            pos=(470, 10),

            size=(282, 26),

            font=2,

            flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,

            text=st_text,

            color=st_color,

            color_sel=st_color

        )

    )



    # 4. Standard Arabic Broadcast Layout (Home on Right, Away on Left)

    home_name = translate_team_name(item.get("home_name", ""))

    away_name = translate_team_name(item.get("away_name", ""))

    h_score = item.get("home_score", "")

    a_score = item.get("away_score", "")



    is_live_or_ft = status_state in ("in", "post") and (h_score != "" and a_score != "")

    score_or_vs = f"{h_score}   -   {a_score}" if is_live_or_ft else "VS"



    # Home Crest (Right side)

    h_pix = get_team_logo_pix(item.get("home_id"), item.get("home_name", ""), item.get("home_logo", ""))

    if h_pix:

        res.append(

            MultiContentEntryPixmapAlphaBlend(

                pos=(688, 44),

                size=(64, 64),

                png=h_pix

            )

        )



    # Home Name (Right side next to home crest)

    res.append(

        MultiContentEntryText(

            pos=(462, 44),

            size=(220, 64),

            font=1,

            flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,

            text=home_name,

            color=0x00ffffff,

            color_sel=0x00ffffff

        )

    )



    # Center Score or VS

    res.append(

        MultiContentEntryText(

            pos=(320, 44),

            size=(140, 64),

            font=3 if is_live_or_ft else 1,

            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,

            text=score_or_vs,

            color=0x0038bdf8 if is_live_or_ft else 0x00fbbf24,

            color_sel=0x0038bdf8 if is_live_or_ft else 0x00fbbf24

        )

    )



    # Away Name (Left side next to away crest)

    res.append(

        MultiContentEntryText(

            pos=(98, 44),

            size=(220, 64),

            font=1,

            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,

            text=away_name,

            color=0x00ffffff,

            color_sel=0x00ffffff

        )

    )



    # Away Crest (Left side)

    a_pix = get_team_logo_pix(item.get("away_id"), item.get("away_name", ""), item.get("away_logo", ""))

    if a_pix:

        res.append(

            MultiContentEntryPixmapAlphaBlend(

                pos=(28, 44),

                size=(64, 64),

                png=a_pix

            )

        )



    # 5. Sleek Subtle Divider

    res.append(

        MultiContentEntryRectangle(

            pos=(28, 114),

            size=(724, 1),

            backgroundColor=0x001e293b,

            backgroundColorSelected=0x00334155

        )

    )



    # 6. Broadcast Row 1: Commentator (Left) & Audio Channel (Right)

    commentator = item.get("comment", "عصام الشوالي")

    audio_ch = item.get("audio", "beIN Sports 1")



    # Commentator

    res.append(

        MultiContentEntryText(

            pos=(28, 122),

            size=(400, 26),

            font=0,

            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,

            text=f"🎙️  المعلق:  {commentator}",

            color=0x0038bdf8 if is_selected else 0x0060a5fa,

            color_sel=0x0038bdf8

        )

    )



    # Audio Channel (Right-aligned, clean icon + name)

    res.append(

        MultiContentEntryText(

            pos=(430, 122),

            size=(322, 26),

            font=0,

            flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,

            text=f"🔊  {audio_ch}",

            color=0x0034d399 if is_selected else 0x0010b981,

            color_sel=0x0034d399

        )

    )



    # 7. Broadcast Row 2: Satellite Carriers

    tv_channel = item.get("channel", "beIN Sports HD")

    tv_clean = tv_channel.replace("القناة الناقلة:", "").strip()

    res.append(

        MultiContentEntryText(

            pos=(28, 154),

            size=(724, 26),

            font=0,

            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,

            text=f"📺  {tv_clean}",

            color=0x00e2e8f0 if is_selected else 0x00cbd5e1,

            color_sel=0x00ffffff

        )

    )



    # 8. Bottom Row: Interactive Prompt or Time

    bottom_text = "▶  اضغط OK للاستماع المباشر للصوتية المختارة ومطابقتها" if is_selected else f"⏰  توقيت المباراة:  {time_str}"

    bottom_color = 0x004ade80 if is_selected else 0x0064748b



    res.append(

        MultiContentEntryText(

            pos=(28, 186),

            size=(724, 26),

            font=2,

            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,

            text=bottom_text,

            color=bottom_color,

            color_sel=0x004ade80

        )

    )



    return res





class LiveInfoManager:

    _instance = None



    @classmethod

    def get_instance(cls):

        if cls._instance is None:

            cls._instance = LiveInfoManager()

        return cls._instance



    def __init__(self):

        self.matches = []

        self.on_update = None

        self.is_fetching = False

        self.load_default_matches()

        self.fetch_matches_async()



    def load_default_matches(self):

        # Fallback fixtures

        self.matches = [

            {

                "match_title": "Crystal Palace vs Man City",

                "league": "الدوري الإنجليزي (Premier League)",

                "home_id": "384",

                "away_id": "382",

                "home_name": "Crystal Palace",

                "away_name": "Man. City",

                "home_score": "",

                "away_score": "",

                "status_state": "pre",

                "status_detail": "",

                "time": "19:00 GMT",

                "channel": "beIN Sports 1 HD / Canal+ (19.2°E)",

                "audio": "beIN Sports 1",

                "comment": "عصام الشوالي",

            },

            {

                "match_title": "Racing Santander vs Elche",

                "league": "الدوري الإسباني (LaLiga)",

                "home_id": "87",

                "away_id": "85",

                "home_name": "R. Santander",

                "away_name": "Elche",

                "home_score": "",

                "away_score": "",

                "status_state": "pre",

                "status_detail": "",

                "time": "17:00 GMT",

                "channel": "beIN Sports 2 HD / Movistar LaLiga (19.2°E)",

                "audio": "beIN Sports 2",

                "comment": "حسن العيدروس",

            },

            {

                "match_title": "AC Milan vs Venezia",

                "league": "الدوري الإيطالي (Serie A)",

                "home_id": "103",

                "away_id": "119",

                "home_name": "AC Milan",

                "away_name": "Venezia",

                "home_score": "",

                "away_score": "",

                "status_state": "pre",

                "status_detail": "",

                "time": "18:45 GMT",

                "channel": "beIN Sports 3 HD / Sky Sport Calcio (13.0°E)",

                "audio": "beIN Sports 3",

                "comment": "علي محمد علي",

            },

            {

                "match_title": "Bayern Munich vs VfB Stuttgart",

                "league": "الدوري الألماني (Bundesliga)",

                "home_id": "132",

                "away_id": "134",

                "home_name": "Bayern Munich",

                "away_name": "VfB Stuttgart",

                "home_score": "",

                "away_score": "",

                "status_state": "pre",

                "status_detail": "",

                "time": "18:30 GMT",

                "channel": "beIN Sports 4 HD / Sky Sport Bundesliga (19.2°E)",

                "audio": "beIN Sports 4",

                "comment": "أحمد البلوشي",

            },

            {

                "match_title": "Lille vs Paris Saint-Germain",

                "league": "الدوري الفرنسي (Ligue 1)",

                "home_id": "164",

                "away_id": "160",

                "home_name": "Lille",

                "away_name": "PSG",

                "home_score": "",

                "away_score": "",

                "status_state": "pre",

                "status_detail": "",

                "time": "18:45 GMT",

                "channel": "beIN Sports 5 HD / Canal+ Foot (19.2°E)",

                "audio": "beIN Sports 5",

                "comment": "جواد بدة",

            },

            {

                "match_title": "Al Hilal vs Al Nassr",

                "league": "دوري روشن السعودي (SPL)",

                "home_id": "11904",

                "away_id": "7488",

                "home_name": "الهلال",

                "away_name": "النصر",

                "home_score": "",

                "away_score": "",

                "status_state": "pre",

                "status_detail": "",

                "time": "21:00 KSA",

                "channel": "SSC 1 HD (26.0°E) / beIN Sports 8 HD",

                "audio": "SSC 1 HD",

                "comment": "فارس عوض",

            },

        ]



    def fetch_matches_async(self, callback=None):

        if callback:

            self.on_update = callback

        if self.is_fetching:

            return

        t = threading.Thread(target=self._fetch_worker, daemon=True)

        t.start()



    def _fetch_worker(self):

        self.is_fetching = True

        try:

            # 1. Check local EPG override if user placed a customized EPG file

            local_epg_paths = [

                "/etc/enigma2/beinsports_epg.json",

                "/etc/enigma2/ipaudioplus_epg.json",

                os.path.join(PLUGIN_PATH, "beinsports_epg.json"),

            ]

            for path in local_epg_paths:

                if os.path.exists(path):

                    try:

                        with open(path, "r", encoding="utf-8") as f:

                            data = json.load(f)

                        if isinstance(data, list) and data:

                            self.matches = data

                            if self.on_update:

                                self.on_update()

                            return

                    except Exception:

                        pass



            # 2. Dynamic Daily Match Feeds by Today's Date (ESPN Public Scoreboard)

            now_dt = datetime.now()

            today_yyyymmdd = now_dt.strftime("%Y%m%d")



            channel_configs = [

                ("eng.1", "الدوري الإنجليزي (Premier League)", "beIN Sports 1", "Canal+ / SS-2 (19.2°E / 16.0°E)", "عصام الشوالي (Issam Chaouali)"),

                ("esp.1", "الدوري الإسباني (LaLiga)", "beIN Sports 2", "Movistar LaLiga (19.2°E)", "حسن العيدروس (Hassan Al-Aidarous)"),

                ("ita.1", "الدوري الإيطالي (Serie A)", "beIN Sports 3", "Sky Sport Calcio (13.0°E) / SS-3", "علي محمد علي (Ali Mohammed Ali)"),

                ("ger.1", "الدوري الألماني (Bundesliga)", "beIN Sports 4", "Sky Sport Bundesliga (19.2°E)", "أحمد البلوشي (Ahmed Al-Balouchi)"),

                ("fra.1", "الدوري الفرنسي (Ligue 1)", "beIN Sports 5", "Canal+ Foot / Prime (19.2°E / 5.0°W)", "جواد بدة (Jaouad Bedda)"),

                ("uefa.champions", "دوري أبطال أوروبا (UCL)", "beIN Sports 1", "Canal+ Foot / Movistar LdC (19.2°E)", "خليل البلوشي (Khalil Al-Baloushi)"),

                ("uefa.europa", "الدوري الأوروبي (UEL)", "beIN Sports 2", "DAZN 1 / Canal+ Sport (19.2°E)", "عامر الخوذيري (Amer Khoudhairi)"),

                ("uefa.europa.conf", "دوري المؤتمر الأوروبي (UECL)", "beIN Sports 3", "Sky Sport Austria (19.2°E)", "محمد بركات (Mohamed Barakat)"),

                ("ksa.1", "دوري روشن السعودي (SPL)", "beIN Sports 8", "SSC 1 HD (26.0°E) / Canal+ 360", "فارس عوض (Fares Awad)"),

                ("afc.champions", "دوري أبطال آسيا (AFC)", "beIN Sports AFC", "Abu Dhabi Asia / SSC (26.0°E)", "عامر عبد الله (Amer Abdullah)"),

                ("caf.champions", "دوري أبطال أفريقيا (CAF)", "beIN Sports 6", "beIN Sports 6 HD (7.0°W)", "عصام الشوالي (Issam Chaouali)"),

                ("eng.fa", "كأس الاتحاد الإنجليزي (FA Cup)", "beIN Sports 1", "BBC One / ITV (28.2°E)", "خليل البلوشي (Khalil Al-Baloushi)"),

                ("esp.copa_del_rey", "كأس ملك إسبانيا (Copa del Rey)", "beIN Sports 3", "TVE La 1 (19.2°E)", "أحمد البلوشي (Ahmed Al-Balouchi)"),

                ("uefa.nations", "دوري الأمم الأوروبية (Nations League)", "beIN Sports 1", "L'Equipe / DAZN (19.2°E)", "عصام الشوالي (Issam Chaouali)"),

            ]



            events_by_league = {}



            def fetch_single_league(cfg):

                code = cfg[0]

                url = f"https://site.api.espn.com/apis/site/v2/sports/soccer/{code}/scoreboard?dates={today_yyyymmdd}"

                try:

                    req = urllib.request.Request(url)

                    with urllib.request.urlopen(req, timeout=4) as resp:

                        data = json.loads(resp.read().decode("utf-8"))

                        return code, data.get("events", [])

                except Exception:

                    return code, []



            with ThreadPoolExecutor(max_workers=6) as ex:

                results = ex.map(fetch_single_league, channel_configs)

                for code, evs in results:

                    events_by_league[code] = evs



            live_results = []

            logos_to_cache = []



            # Top Arabic Commentators by League

            LEAGUE_COMMENTATORS = {

                "eng.1": ["عصام الشوالي", "خليل البلوشي", "حفيظ دراجي", "علي محمد علي", "حسن العيدروس", "أحمد البلوشي", "عامر الخوذيري", "جواد بدة"],

                "esp.1": ["حسن العيدروس", "حفيظ دراجي", "علي محمد علي", "عامر الخوذيري", "أحمد البلوشي", "نوفل باشي", "خالد الحدي", "محمد بركات"],

                "ita.1": ["علي محمد علي", "محمد بركات", "أحمد البلوشي", "مصطفى علوان", "عامر الخوذيري", "خالد الحدي"],

                "ger.1": ["أحمد البلوشي", "مضر اليوسف", "أحمد فؤاد", "منتصر الأزهري", "محمد بركات"],

                "fra.1": ["جواد بدة", "نوفل باشي", "عامر الخوذيري", "حفيظ دراجي", "أحمد فؤاد"],

                "ksa.1": ["فهد العتيبي", "فارس عوض", "عيسى الحربين", "عبد الله الحربي", "مشاري القرني", "جعفر الصليح", "حماد العنزي", "راشد الدوسري"],

                "uefa.champions": ["عصام الشوالي", "خليل البلوشي", "حفيظ دراجي", "علي محمد علي", "حسن العيدروس", "أحمد البلوشي"],

                "uefa.europa": ["عامر الخوذيري", "محمد بركات", "جواد بدة", "خالد الحدي", "أحمد البلوشي"],

                "uefa.europa.conf": ["محمد بركات", "أحمد البلوشي", "خالد الحدي", "منتصر الأزهري"],

                "afc.champions": ["عامر عبد الله", "فهد العتيبي", "خليل البلوشي", "أحمد البلوشي"],

                "caf.champions": ["عصام الشوالي", "حفيظ دراجي", "جواد بدة", "علي محمد علي"],

                "eng.fa": ["خليل البلوشي", "عصام الشوالي", "حفيظ دراجي", "علي محمد علي"],

                "esp.copa_del_rey": ["أحمد البلوشي", "حسن العيدروس", "خالد الحدي", "محمد بركات"],

                "uefa.nations": ["عصام الشوالي", "حفيظ دراجي", "خليل البلوشي", "علي محمد علي"],

            }



            # Distinct Audio Channels by League

            LEAGUE_AUDIO_CHANNELS = {

                "eng.1": ["beIN Sports 1", "beIN Sports 2", "beIN Sports 3", "beIN Sports Xtra 1", "beIN Sports Xtra 2"],

                "esp.1": ["beIN Sports 3", "beIN Sports 1", "beIN Sports 2", "beIN Sports 4"],

                "ita.1": ["beIN Sports 4", "beIN Sports 2", "beIN Sports 5"],

                "ger.1": ["beIN Sports 5", "beIN Sports 4", "beIN Sports 6"],

                "fra.1": ["beIN Sports 6", "beIN Sports 5", "beIN Sports 2"],

                "ksa.1": ["SSC 1 HD", "SSC 2 HD", "SSC 3 HD", "SSC 5 HD", "beIN Sports 8"],

                "uefa.champions": ["beIN Sports 1", "beIN Sports 2", "beIN Sports 3", "beIN Sports 4"],

                "uefa.europa": ["beIN Sports 2", "beIN Sports 3", "beIN Sports 4"],

                "uefa.europa.conf": ["beIN Sports 3", "beIN Sports 5", "beIN Sports 6"],

                "afc.champions": ["beIN Sports AFC", "beIN Sports AFC 2", "SSC Extra 1"],

                "caf.champions": ["beIN Sports 6", "beIN Sports 7", "beIN Sports 8"],

                "eng.fa": ["beIN Sports 1", "beIN Sports 2", "beIN Sports 3"],

                "esp.copa_del_rey": ["beIN Sports 3", "beIN Sports 4", "beIN Sports 5"],

                "uefa.nations": ["beIN Sports 1", "beIN Sports 2", "beIN Sports 3"],

            }



            league_match_counts = {}



            for code, league_ar, default_audio, default_carrier, default_comm in channel_configs:

                ev_list = events_by_league.get(code, [])

                for ev in ev_list:

                    comps = ev.get("competitions", [{}])[0]

                    competitors = comps.get("competitors", [])

                    if len(competitors) < 2:

                        continue



                    home = competitors[0]

                    away = competitors[1]

                    if home.get("homeAway") == "away":

                        home, away = away, home



                    home_team = home.get("team", {})

                    away_team = away.get("team", {})



                    h_name = home_team.get("shortDisplayName") or home_team.get("displayName") or "Home"

                    a_name = away_team.get("shortDisplayName") or away_team.get("displayName") or "Away"

                    h_id = str(home_team.get("id", ""))

                    a_id = str(away_team.get("id", ""))

                    h_logo = home_team.get("logo", "")

                    a_logo = away_team.get("logo", "")



                    if h_id and h_logo:

                        logos_to_cache.append((h_id, h_name, h_logo))

                    if a_id and a_logo:

                        logos_to_cache.append((a_id, a_name, a_logo))



                    status = ev.get("status", {}).get("type", {})

                    status_state = status.get("state", "pre")

                    status_detail = status.get("detail", "")



                    raw_date = ev.get("date", "")

                    time_str = "Live"

                    if raw_date:

                        try:

                            clean_date = raw_date.replace("Z", "+00:00")

                            if "+" in clean_date:

                                dt = datetime.fromisoformat(clean_date)

                            else:

                                dt = datetime.strptime(clean_date[:19], "%Y-%m-%dT%H:%M:%S")

                            ksa_h = (dt.hour + 3) % 24

                            time_str = f"{ksa_h:02d}:{dt.minute:02d} بتوقيت مكة"

                        except Exception:

                            time_str = raw_date[:16].replace("T", " ")



                    h_score = str(home.get("score", ""))

                    a_score = str(away.get("score", ""))



                    # Assign distinct commentator & audio channel per match

                    m_idx = league_match_counts.get(code, 0)

                    league_match_counts[code] = m_idx + 1



                    comm_roster = LEAGUE_COMMENTATORS.get(code, [default_comm])

                    audio_roster = LEAGUE_AUDIO_CHANNELS.get(code, [default_audio])



                    assigned_comm = comm_roster[m_idx % len(comm_roster)]

                    assigned_audio = audio_roster[m_idx % len(audio_roster)]



                    # Extract broadcast networks

                    broadcasts = comps.get("broadcasts", [])

                    tv_names = []

                    for b in broadcasts:

                        tv_names.extend(b.get("names", []))



                    clean_audio = assigned_audio if "HD" in assigned_audio else f"{assigned_audio} HD"

                    if tv_names:

                        carrier_display = f"{clean_audio} / {' - '.join(tv_names[:2])} / {default_carrier}"

                    else:

                        carrier_display = f"{clean_audio} / {default_carrier}"



                    live_results.append({

                        "match_title": f"{h_name} vs {a_name}",

                        "league": league_ar,

                        "home_id": h_id,

                        "away_id": a_id,

                        "home_name": h_name,

                        "away_name": a_name,

                        "home_logo": h_logo,

                        "away_logo": a_logo,

                        "home_score": h_score,

                        "away_score": a_score,

                        "status_state": status_state,

                        "status_detail": status_detail,

                        "time": time_str,

                        "channel": carrier_display,

                        "audio": assigned_audio,

                        "comment": assigned_comm,

                        "raw_date": raw_date,

                    })



            if len(live_results) >= 1:

                # Sort: Live first, then upcoming by kickoff time, then finished

                def sort_key(m):

                    st = m.get("status_state")

                    if st == "in":

                        return (0, m.get("raw_date", ""))

                    elif st == "pre":

                        return (1, m.get("raw_date", ""))

                    else:

                        return (2, m.get("raw_date", ""))



                live_results.sort(key=sort_key)

                self.matches = live_results



            # Notify UI

            if self.on_update:

                try:

                    self.on_update()

                except Exception:

                    pass



            # Pre-cache missing logos in background

            if logos_to_cache:

                def _dl_task(item):

                    tid, nm, url = item

                    get_team_logo_pix(tid, nm, url)



                with ThreadPoolExecutor(max_workers=6) as ex:

                    list(ex.map(_dl_task, logos_to_cache))



                if self.on_update:

                    try:

                        self.on_update()

                    except Exception:

                        pass

        finally:

            self.is_fetching = False





LOGOS_DIRS = [

    os.path.join(os.path.dirname(__file__), "logos"),

    "/usr/lib/enigma2/python/Plugins/Extensions/IPAudioPlus/logos",

    "/etc/enigma2/ipaudioplus_logos"

]

_channel_logo_cache = {}



def get_channel_logo(name, ch_id=""):

    cache_key = f"{name}_{ch_id}"

    if cache_key in _channel_logo_cache:

        return _channel_logo_cache[cache_key]



    clean_name = name.strip().lower()

    variants = [

        f"{name}.png",

        f"{name.strip()}.png",

        f"{clean_name}.png",

        f"{clean_name.replace(' ', '_')}.png",

        f"{clean_name.replace(' ', '')}.png",

        f"{clean_name.replace('-', '_')}.png",

        f"{clean_name.replace('-', '')}.png",

    ]

    if ch_id:

        variants.extend([f"{ch_id}.png", f"id_{ch_id}.png"])



    found_path = None

    for l_dir in LOGOS_DIRS:

        if os.path.isdir(l_dir):

            for v in variants:

                p = os.path.join(l_dir, v)

                if os.path.exists(p):

                    found_path = p

                    break

            if found_path:

                break



    if not found_path:

        default_p = os.path.join(IMG_PATH, "default_channel_logo.png")

        if os.path.exists(default_p):

            found_path = default_p



    if found_path:

        try:

            pix = loadPNG(found_path)

            _channel_logo_cache[cache_key] = pix

            return pix

        except Exception:

            pass



    _channel_logo_cache[cache_key] = None

    return None



DEFAULT_SERVERS = [

    {

        "name": "Anis",

        "badge": "Anis",

        "channels": [

            {

                "name": "Anis Max 1",

                "id": "1",

                "url": "http://radio.anisfm.vip/live/mx/1?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis Max 2",

                "id": "2",

                "url": "http://radio.anisfm.vip/live/mx/2?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis Max 3",

                "id": "3",

                "url": "http://radio.anisfm.vip/live/mx/3?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis Max 4",

                "id": "4",

                "url": "http://radio.anisfm.vip/live/mx/4?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis Max 5",

                "id": "5",

                "url": "http://radio.anisfm.vip/live/mx/5?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis Max 6",

                "id": "6",

                "url": "http://radio.anisfm.vip/live/mx/6?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis PN 1",

                "id": "7",

                "url": "http://radio.anisfm.vip/live/pn/1?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis PN 2",

                "id": "8",

                "url": "http://radio.anisfm.vip/live/pn/2?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis PN 3",

                "id": "9",

                "url": "http://radio.anisfm.vip/live/pn/3?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis PN 4",

                "id": "10",

                "url": "http://radio.anisfm.vip/live/pn/4?token=6ZQ7WCPU#"

            },

            {

                "name": "Aswat alweb",

                "id": "11",

                "url": "https://live.aswatalweb.com/listen/live/radio.mp3"

            },

            {

                "name": "Anis PN 5",

                "id": "12",

                "url": "http://radio.anisfm.vip/live/pn/5?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis PN 6",

                "id": "13",

                "url": "http://radio.anisfm.vip/live/pn/6?token=6ZQ7WCPU#"

            },

            {

                "name": "Anis PN 7",

                "id": "14",

                "url": "http://radio.anisfm.vip/live/pn/7?token=6ZQ7WCPU#"

            }

        ]

    },

    {

        "name": "AHMED YAHYA",

        "badge": "YAHYA",

        "channels": [

            {

                "name": "AHMED YAHYA 0",

                "id": "1",

                "url": "http://ahmadyahia.ddns.net"

            },

            {

                "name": "AHMED YAHYA 1",

                "id": "2",

                "url": "http://yahia1.audix.ggff.net/live1"

            },

            {

                "name": "AHMED YAHYA 2",

                "id": "3",

                "url": "http://yahia2.audix.ggff.net/live2"

            }

        ]

    },

    {

        "name": "MEGA ANIS",

        "badge": "MEGA",

        "channels": [

            {

                "name": "MEGA ANIS ON SPORT",

                "id": "1",

                "url": "http://audio.megashare.store/onsport"

            },

            {

                "name": "MEGA ANIS LIVE",

                "id": "2",

                "url": "http://audio.megashare.store/live"

            },

            {

                "name": "MEGA ANIS LOW",

                "id": "3",

                "url": "http://audio.megashare.store/low"

            },

            {

                "name": "MEGA ANIS 1",

                "id": "4",

                "url": "http://audio.megashare.store/live1"

            },

            {

                "name": "MEGA ANIS 2",

                "id": "5",

                "url": "http://audio.megashare.store/live2"

            },

            {

                "name": "MEGA ANIS 3",

                "id": "6",

                "url": "http://audio.megashare.store/live3"

            },

            {

                "name": "MEGA ANIS 4",

                "id": "7",

                "url": "http://audio.megashare.store/live4"

            },

            {

                "name": "MEGA ANIS 5",

                "id": "8",

                "url": "http://audio.megashare.store/live5"

            },

            {

                "name": "MEGA ANIS 6",

                "id": "9",

                "url": "http://audio.megashare.store/live6"

            },

            {

                "name": "MEGA ANIS 7",

                "id": "10",

                "url": "http://audio.megashare.store/live7"

            },

            {

                "name": "MEGA ANIS 8",

                "id": "11",

                "url": "http://audio.megashare.store/live8"

            }

        ]

    },

    {

        "name": "BeiN",

        "badge": "BeiN",

        "channels": [

            {

                "name": "BeiN 1",

                "id": "1",

                "url": "http://62.138.18.147:11000/play/live/bb1.ts?uid=ipaudio&delay=-1"

            },

            {

                "name": "BeiN 2",

                "id": "2",

                "url": "http://62.138.18.147:11000/play/live/bb2.ts?uid=ipaudio&delay=-1"

            },

            {

                "name": "BeiN 3",

                "id": "3",

                "url": "http://62.138.18.147:11000/play/live/bb3.ts?uid=ipaudio&delay=-1"

            },

            {

                "name": "BeiN 4",

                "id": "4",

                "url": "http://62.138.18.147:11000/play/live/bb4.ts?uid=ipaudio&delay=-1"

            },

            {

                "name": "BeiN 5",

                "id": "5",

                "url": "http://62.138.18.147:11000/play/live/bb5.ts?uid=ipaudio&delay=-1"

            },

            {

                "name": "BeiN 6",

                "id": "6",

                "url": "http://62.138.18.147:11000/play/live/bb6.ts?uid=ipaudio&delay=-1"

            }

        ]

    },

    {

        "name": "Fox",

        "badge": "Fox",

        "channels": [

            {

                "name": "Fox Sports 1",

                "id": "1",

                "url": "http://foxfm.xyz/1"

            },

            {

                "name": "Fox Sports 2",

                "id": "2",

                "url": "http://foxfm.xyz/2"

            },

            {

                "name": "Fox Sports 3",

                "id": "3",

                "url": "http://foxfm.xyz/3"

            },

            {

                "name": "Fox Sports 4",

                "id": "4",

                "url": "http://foxfm.xyz/4"

            },

            {

                "name": "Fox Sports 5",

                "id": "5",

                "url": "http://foxfm.xyz/5"

            },

            {

                "name": "Fox Sports 6",

                "id": "6",

                "url": "http://foxfm.xyz/6"

            },

            {

                "name": "Fox Sports 7",

                "id": "7",

                "url": "http://foxfm.xyz/7"

            },

            {

                "name": "Fox Sports 8",

                "id": "8",

                "url": "http://foxfm.xyz/8"

            },

            {

                "name": "FoX FM Live 1",

                "id": "9",

                "url": "http://foxfm.xyz:8080/live1"

            },

            {

                "name": "FoX FM Live 2",

                "id": "10",

                "url": "http://foxfm.xyz:8080/live2"

            },

            {

                "name": "FoX FM Live 3",

                "id": "11",

                "url": "http://foxfm.xyz:8080/live3"

            },

            {

                "name": "FoX FM Live 4",

                "id": "12",

                "url": "http://foxfm.xyz:8080/live4"

            },

            {

                "name": "FoX FM 1",

                "id": "13",

                "url": "http://foxfm.xyz/1"

            },

            {

                "name": "FoX FM 2",

                "id": "14",

                "url": "http://foxfm.xyz/2"

            },

            {

                "name": "FoX FM 3",

                "id": "15",

                "url": "http://foxfm.xyz/3"

            },

            {

                "name": "FoX FM 4",

                "id": "16",

                "url": "http://foxfm.xyz/4"

            },

            {

                "name": "FoX FM 5",

                "id": "17",

                "url": "http://foxfm.xyz/5"

            },

            {

                "name": "FoX FM 6",

                "id": "18",

                "url": "http://foxfm.xyz/6"

            },

            {

                "name": "FoX FM 7",

                "id": "19",

                "url": "http://foxfm.xyz/7"

            },

            {

                "name": "FoX FM 8",

                "id": "20",

                "url": "http://foxfm.xyz/8"

            },

            {

                "name": "FoX FM 9",

                "id": "21",

                "url": "http://foxfm.xyz/9"

            },

            {

                "name": "FoX FM Xtra 1",

                "id": "22",

                "url": "http://foxfm.xyz:8080/xtra1"

            },

            {

                "name": "FoX FM Xtra 2",

                "id": "23",

                "url": "http://foxfm.xyz:8080/xtra2"

            },

            {

                "name": "FoX FM Xtra 3",

                "id": "24",

                "url": "http://foxfm.xyz:8080/xtra3"

            },

            {

                "name": "FoX FM EN 1",

                "id": "25",

                "url": "http://foxfm.xyz:8080/en1"

            },

            {

                "name": "FoX FM EN 2",

                "id": "26",

                "url": "http://foxfm.xyz:8080/en2"

            },

            {

                "name": "FoX FM FR 1",

                "id": "27",

                "url": "http://foxfm.xyz:8080/fr1"

            },

            {

                "name": "FoX FM FR 2",

                "id": "28",

                "url": "http://foxfm.xyz:8080/fr2"

            },

            {

                "name": "FoX FM StarzPlay 1",

                "id": "29",

                "url": "http://foxfm.xyz:8080/starzplay1"

            },

            {

                "name": "FoX FM StarzPlay 2",

                "id": "30",

                "url": "http://foxfm.xyz:8080/starzplay2"

            },

            {

                "name": "FoX FM Shasha 1",

                "id": "31",

                "url": "http://foxfm.xyz:8080/shasha1"

            },

            {

                "name": "FoX FM Shasha 2",

                "id": "32",

                "url": "http://foxfm.xyz:8080/shasha2"

            },

            {

                "name": "FoX FM Thmanyah 1",

                "id": "33",

                "url": "http://foxfm.xyz:8080/thmanyah1"

            },

            {

                "name": "FoX FM Thmanyah 2",

                "id": "34",

                "url": "http://foxfm.xyz:8080/thmanyah2"

            },

            {

                "name": "FoX FM Thmanyah 3",

                "id": "35",

                "url": "http://foxfm.xyz:8080/thmanyah3"

            },

            {

                "name": "FoX FM Shahid 1",

                "id": "36",

                "url": "http://foxfm.xyz:8080/shahid1"

            },

            {

                "name": "FoX FM Shahid 2",

                "id": "37",

                "url": "http://foxfm.xyz:8080/shahid2"

            },

            {

                "name": "FoX FM Alkass 5",

                "id": "38",

                "url": "http://foxfm.xyz:8080/alkass5"

            },

            {

                "name": "FoX FM Alkass 6",

                "id": "39",

                "url": "http://foxfm.xyz:8080/alkass6"

            },

            {

                "name": "FoX FM Alkass 7",

                "id": "40",

                "url": "http://foxfm.xyz:8080/alkass7"

            },

            {

                "name": "FoX FM Alkass 8",

                "id": "41",

                "url": "http://foxfm.xyz:8080/alkass8"

            }

        ]

    },

    {

        "name": "AYHEM",

        "badge": "AYHEM",

        "channels": [

            {

                "name": "AYHEM 1 FM",

                "id": "1",

                "url": "https://ayhemazerbaijan.s.gy/FM1"

            },

            {

                "name": "AYHEM 2 FM",

                "id": "2",

                "url": "https://ayhemazerbaijan.s.gy/FM2"

            },

            {

                "name": "AYHEM 3 FM",

                "id": "3",

                "url": "https://ayhemazerbaijan.s.gy/FM3"

            },

            {

                "name": "AYHEM 4 FM",

                "id": "4",

                "url": "https://ayhemazerbaijan.s.gy/FM4"

            },

            {

                "name": "AYHEM NouNa 1 FM",

                "id": "5",

                "url": "https://ayhemazerbaijan.s.gy/NouNa1"

            },

            {

                "name": "AYHEM NouNa 2 FM",

                "id": "6",

                "url": "https://ayhemazerbaijan.s.gy/NouNa2"

            },

            {

                "name": "AYHEM News FM",

                "id": "7",

                "url": "https://ayhemazerbaijan.s.gy/News"

            }

        ]

    },

    {

        "name": "Music Stations",

        "badge": "Music",

        "channels": [

            {

                "name": "NRJ",

                "id": "1",

                "url": "https://live-bauerse-fm.sharp-stream.com/nrj_instreamtest_se_mp3"

            },

            {

                "name": "Rotana Jordan",

                "id": "2",

                "url": "http://45.63.116.205:8000/stream"

            },

            {

                "name": "TRT",

                "id": "3",

                "url": "http://192.168.0.100:8001/1:0:1F:3FAC:A860:42E:1A40000:0:0:0:"

            },

            {

                "name": "Nrj Lebanon",

                "id": "4",

                "url": "http://cdn.nrjaudio.fm/adwz1/lb/55219/mp3_128.mp3"

            },

            {

                "name": "Rotana Fm",

                "id": "5",

                "url": "http://curiosity.shoutca.st:6035/"

            }

        ]

    }

]

def get_channel_subtitle(ch_item, srv_name=""):

    if isinstance(ch_item, dict):

        info = ch_item.get("freq") or ch_item.get("info") or ch_item.get("subtitle") or ch_item.get("comment")

        if info:

            return str(info)

    if srv_name:

        return f"{srv_name} • IP Audio"

    return "12399 H 27500"



def build_channel_entry(index, ch_item, srv_name="", is_selected=False, is_playing=False, stream_status=None):

    if isinstance(ch_item, dict):

        name = ch_item.get("name", ch_item.get("Name", f"Channel {index}"))

        ch_id = ch_item.get("id", ch_item.get("Id", str(index)))

    else:

        name = str(ch_item)

        ch_id = str(index)

        ch_item = {}



    res = [(index, name)]



    # 1. Native Rounded Card Rectangle (Sat Air Design)

    # Selected: Vibrant Cyan border (#38bdf8), Rich blue fill (#0c2c4c)

    # Unselected: Subtle border (#26344b), Dark slate fill (#141b28)

    res.append(

        MultiContentEntryRectangle(

            pos=(4, 3),

            size=(566, 54),

            backgroundColor=0x00141b28,

            backgroundColorSelected=0x00007ac4,

            borderWidth=2,

            borderColor=0x0026344b,

            borderColorSelected=0x0038bdf8,

            cornerRadius=10,

            cornerEdges=15

        )

    )



    # 2. Left side: Channel Number Pill Badge (or Play Icon + Signal Status Bar if active)

    if is_playing:

        p_play = os.path.join(IMG_PATH, "icon_play.png")

        if os.path.exists(p_play):

            res.append(

                MultiContentEntryPixmapAlphaBlend(

                    pos=(18, 15),

                    size=(24, 24),

                    png=loadPNG(p_play)

                )

            )



        # Signal / Buffer Status Indicator (شريط إشارة واستقرار البث)

        if stream_status is None:

            stream_status = {"percent": 100, "bitrate": 128, "level": "EXCELLENT", "text": "مستقر"}



        pct = stream_status.get("percent", 100)

        bitrate = stream_status.get("bitrate", 128)

        level = stream_status.get("level", "EXCELLENT")



        if level == "EXCELLENT":

            meter_color = 0x0022c55e   # Vibrant Green

            bg_meter = 0x00062312      # Dark Emerald

            border_color = 0x0022c55e

            bars_active = 4

        elif level == "GOOD":

            meter_color = 0x0038bdf8   # Sky Cyan

            bg_meter = 0x000c2538      # Dark Navy

            border_color = 0x0038bdf8

            bars_active = 3

        elif level == "BUFFERING":

            meter_color = 0x00f59e0b   # Amber

            bg_meter = 0x00281c05      # Dark Amber

            border_color = 0x00f59e0b

            bars_active = 2

        else: # STALLED / تقطيع

            meter_color = 0x00ef4444   # Red

            bg_meter = 0x002d0b0b      # Dark Crimson

            border_color = 0x00ef4444

            bars_active = 1



        # Signal Badge Pill (pos: 48, 8, size: 116, 22)

        res.append(

            MultiContentEntryRectangle(

                pos=(48, 8),

                size=(116, 22),

                backgroundColor=bg_meter,

                backgroundColorSelected=bg_meter,

                borderWidth=1,

                borderColor=border_color,

                borderColorSelected=border_color,

                cornerRadius=5,

                cornerEdges=15

            )

        )



        # 4-bar cellular/wifi signal meter

        c1 = meter_color if bars_active >= 1 else 0x00334155

        c2 = meter_color if bars_active >= 2 else 0x00334155

        c3 = meter_color if bars_active >= 3 else 0x00334155

        c4 = meter_color if bars_active >= 4 else 0x00334155

        res.append(MultiContentEntryRectangle(pos=(54, 21), size=(3, 7), backgroundColor=c1, backgroundColorSelected=c1))

        res.append(MultiContentEntryRectangle(pos=(59, 18), size=(3, 10), backgroundColor=c2, backgroundColorSelected=c2))

        res.append(MultiContentEntryRectangle(pos=(64, 15), size=(3, 13), backgroundColor=c3, backgroundColorSelected=c3))

        res.append(MultiContentEntryRectangle(pos=(69, 12), size=(3, 16), backgroundColor=c4, backgroundColorSelected=c4))



        # Percentage and Bitrate Text inside Pill

        res.append(

            MultiContentEntryText(

                pos=(74, 8),

                size=(88, 22),

                font=1,

                flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,

                text=f"{pct}% • {bitrate}k",

                color=meter_color,

                color_sel=meter_color

            )

        )

    else:

        # Number Pill Badge

        res.append(

            MultiContentEntryRectangle(

                pos=(16, 12),

                size=(36, 30),

                backgroundColor=0x000b121e,

                backgroundColorSelected=0x00084c7c,

                borderWidth=1,

                borderColor=0x002a3a52,

                borderColorSelected=0x0038bdf8,

                cornerRadius=6,

                cornerEdges=15

            )

        )

        res.append(

            MultiContentEntryText(

                pos=(16, 12),

                size=(36, 30),

                font=1,

                flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,

                text=str(index),

                color=0x0038bdf8,

                color_sel=0x00ffffff

            )

        )



    # 3. Right side: Channel Logo Badge (56 x 40, Pos 496, 10)

    logo_pix = get_channel_logo(name, ch_id)

    if logo_pix:

        res.append(

            MultiContentEntryPixmapAlphaBlend(

                pos=(496, 10),

                size=(56, 40),

                png=logo_pix

            )

        )



    # 4. Text - Channel Name (Top line, Bold White/Yellow, Right-aligned towards logo)

    c_name = 0x00ffcc00 if is_playing else 0x00ffffff

    c_name_sel = 0x00ffcc00 if is_playing else 0x00ffffff

    name_x = 168 if is_playing else 56

    name_w = 316 if is_playing else 428

    res.append(

        MultiContentEntryText(

            pos=(name_x, 7),

            size=(name_w, 26),

            font=0,

            flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,

            text=name,

            color=c_name,

            color_sel=c_name_sel

        )

    )



    # 5. Text - Subtitle / Info (Bottom line, Right-aligned)

    if is_playing and stream_status:

        pct = stream_status.get("percent", 100)

        bitrate = stream_status.get("bitrate", 128)

        level = stream_status.get("level", "EXCELLENT")

        status_lbl = stream_status.get("text", "مستقر")



        if level in ("EXCELLENT", "GOOD"):

            sub_text = f"● استقرار البث: {pct}% • {bitrate} kbps • {status_lbl}"

            sub_color = 0x0022c55e

        elif level == "BUFFERING":

            sub_text = f"⚡ جاري التخزين المؤقت ({pct}%) • {bitrate} kbps"

            sub_color = 0x00f59e0b

        else: # STALLED

            sub_text = f"⚠ تنبيه: تقطيع في البث ({pct}%) • جاري محاولة الاستقرار"

            sub_color = 0x00ef4444

        sub_color_sel = sub_color

    else:

        sub_text = get_channel_subtitle(ch_item, srv_name)

        sub_color = 0x0022c55e

        sub_color_sel = 0x00e0f2fe



    res.append(

        MultiContentEntryText(

            pos=(56, 33),

            size=(428, 20),

            font=1,

            flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,

            text=sub_text,

            color=sub_color,

            color_sel=sub_color_sel

        )

    )



    return res





def build_server_entry(index, srv_item, is_current=False):

    if isinstance(srv_item, dict):

        name = srv_item.get("name", f"Server {index}")

        badge = srv_item.get("badge", "")

        ch_count = len(srv_item.get("channels", []))

    else:

        name = str(srv_item)

        badge = ""

        ch_count = 0



    res = [(index, name, badge)]



    # 1. Native Rounded Card Rectangle (Width 644, Height 54, Pos 8, 3)

    # Selected: Royal Ocean Blue (#007ac4), Vibrant Cyan border (#38bdf8)

    # Unselected: Dark slate (#141b28), Subtle border (#26344b)

    res.append(

        MultiContentEntryRectangle(

            pos=(8, 3),

            size=(644, 54),

            backgroundColor=0x00141b28,

            backgroundColorSelected=0x00007ac4,

            borderWidth=2,

            borderColor=0x0026344b,

            borderColorSelected=0x0038bdf8,

            cornerRadius=10,

            cornerEdges=15

        )

    )



    # 2. Server Number Pill on Left: Pos (20, 11), Size (36, 32)

    res.append(

        MultiContentEntryRectangle(

            pos=(20, 11),

            size=(36, 32),

            backgroundColor=0x000b121e,

            backgroundColorSelected=0x00084c7c,

            borderWidth=1,

            borderColor=0x002a3a52,

            borderColorSelected=0x0038bdf8,

            cornerRadius=6,

            cornerEdges=15

        )

    )

    res.append(

        MultiContentEntryText(

            pos=(20, 11),

            size=(36, 32),

            font=1,

            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,

            text=str(index),

            color=0x0038bdf8,

            color_sel=0x00ffffff

        )

    )



    # 3. Server Name: Pos (72, 11), Size (380, 32)

    res.append(

        MultiContentEntryText(

            pos=(72, 11),

            size=(380, 32),

            font=0,

            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,

            text=name,

            color=0x00ffffff,

            color_sel=0x00ffffff

        )

    )



    # 4. Active Badge or Channels Count

    if is_current:

        res.append(

            MultiContentEntryRectangle(

                pos=(470, 14),

                size=(110, 26),

                backgroundColor=0x000a4028,

                backgroundColorSelected=0x00083320,

                borderWidth=1,

                borderColor=0x0022c55e,

                borderColorSelected=0x004ade80,

                cornerRadius=5,

                cornerEdges=15

            )

        )

        res.append(

            MultiContentEntryText(

                pos=(470, 14),

                size=(110, 26),

                font=1,

                flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,

                text="ACTIVE",

                color=0x004ade80,

                color_sel=0x004ade80

            )

        )

    elif ch_count > 0:

        res.append(

            MultiContentEntryText(

                pos=(470, 14),

                size=(110, 26),

                font=1,

                flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,

                text=f"{ch_count} CH",

                color=0x0094a3b8,

                color_sel=0x00e0f2fe

            )

        )



    # 5. Chevron '>' on Far Right: Pos (605, 11), Size (28, 32)

    res.append(

        MultiContentEntryText(

            pos=(605, 11),

            size=(28, 32),

            font=0,

            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,

            text=">",

            color=0x0064748b,

            color_sel=0x00ffffff

        )

    )

    return res





def build_config_entry(item_type, title, value=""):

    # item_type: "separator", "switch", "value", "link"

    res = [(item_type, title, value)]

    if item_type == "separator":

        sep_p = os.path.join(IMG_PATH, "dotted_line.png")

        if os.path.exists(sep_p):

            res.append(

                MultiContentEntryPixmapAlphaBlend(

                    pos=(0, 19),

                    size=(574, 4),

                    png=loadPNG(sep_p)

                )

            )

        return res



    if item_type == "link":

        res.append(

            MultiContentEntryText(

                pos=(20, 1),

                size=(150, 40),

                font=0,

                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,

                text=f"• {title}",

                color=0x00cbd5e1,

                color_sel=0x00ffffff

            )

        )

        val_color = 0x0000d2ff if value and value != "Disabled" else 0x0094a3b8

        res.append(

            MultiContentEntryText(

                pos=(170, 1),

                size=(380, 40),

                font=1,

                flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,

                text=str(value),

                color=val_color,

                color_sel=0x0000d2ff

            )

        )

        return res



    # Title with Bullet

    res.append(

        MultiContentEntryText(

            pos=(20, 1),

            size=(340, 40),

            font=0,

            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,

            text=f"• {title}",

            color=0x00ffffff,

            color_sel=0x00ffffff

        )

    )



    if item_type == "switch":

        sw_file = "switch_on.png" if value == "ON" else "switch_off.png"

        sw_p = os.path.join(IMG_PATH, sw_file)

        if os.path.exists(sw_p):

            res.append(

                MultiContentEntryPixmapAlphaBlend(

                    pos=(500, 11),

                    size=(48, 20),

                    png=loadPNG(sw_p)

                )

            )

    elif item_type == "value":

        res.append(

            MultiContentEntryText(

                pos=(360, 1),

                size=(188, 40),

                font=0,

                flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,

                text=str(value),

                color=0x00ffffff,

                color_sel=0x00ffffff

            )

        )



    return res





# ==========================================

# Real-Time Stream Health & Buffer Monitor

# ==========================================

class StreamHealthMonitor:

    def __init__(self):

        self.is_active = False

        self.start_time = 0

        self.last_check_time = 0

        self.last_hw_ptr = None

        self.last_rx_bytes = None

        self.buffer_percent = 0

        self.bitrate_kbps = 128

        self.status_level = "IDLE"

        self.status_text = "جاهز"

        self.consecutive_underruns = 0



    def start(self, url=""):

        self.is_active = True

        self.start_time = time.time()

        self.last_check_time = self.start_time

        hw_ptr, _ = self._get_alsa_hw_ptr()

        self.last_hw_ptr = hw_ptr

        self.last_rx_bytes = self._get_network_rx_bytes()

        self.buffer_percent = 35  # Initial buffering

        self.bitrate_kbps = 128

        self.status_level = "BUFFERING"

        self.status_text = "جاري التخزين المؤقت..."

        self.consecutive_underruns = 0



    def stop(self):

        self.is_active = False

        self.buffer_percent = 0

        self.status_level = "IDLE"

        self.status_text = "متوقف"

        self.last_hw_ptr = None

        self.last_rx_bytes = None



    def _get_alsa_hw_ptr(self):

        status_path = "/proc/asound/card0/pcm0p/sub0/status"

        if not os.path.exists(status_path):

            return None, "NONE"

        try:

            with open(status_path, "r") as f:

                content = f.read()

            state = "UNKNOWN"

            hw_ptr = 0

            for line in content.splitlines():

                if line.startswith("state:"):

                    state = line.split(":", 1)[1].strip()

                elif "hw_ptr" in line:

                    parts = line.split(":", 1)

                    if len(parts) > 1:

                        hw_ptr = int(parts[1].strip())

            return hw_ptr, state

        except Exception:

            return None, "ERROR"



    def _get_network_rx_bytes(self):

        dev_path = "/proc/net/dev"

        if not os.path.exists(dev_path):

            return 0

        try:

            total = 0

            with open(dev_path, "r") as f:

                for line in f:

                    if ":" in line and not line.strip().startswith("lo:"):

                        parts = line.split(":", 1)[1].split()

                        total += int(parts[0])

            return total

        except Exception:

            return 0



    def update(self, process_alive=True):

        if not self.is_active or not process_alive:

            self.buffer_percent = 0

            self.status_level = "STALLED"

            self.status_text = "انقطع البث"

            return self.get_status()



        now = time.time()

        # If checked recently (less than 0.6s), return current cached status

        if (now - self.last_check_time) < 0.6 and self.last_hw_ptr is not None:

            return self.get_status()



        dt = max(0.4, now - self.last_check_time)

        self.last_check_time = now

        elapsed_since_start = now - self.start_time



        # 1. Check ALSA hardware playback

        hw_ptr, alsa_state = self._get_alsa_hw_ptr()

        alsa_advancing = False

        if hw_ptr is not None and self.last_hw_ptr is not None:

            diff_samples = hw_ptr - self.last_hw_ptr

            rate = diff_samples / dt

            if rate > 20000 and alsa_state == "RUNNING":

                alsa_advancing = True

        elif alsa_state == "RUNNING":

            alsa_advancing = True



        self.last_hw_ptr = hw_ptr



        # 2. Check Network throughput & bitrate

        rx = self._get_network_rx_bytes()

        if rx > 0 and self.last_rx_bytes is not None:

            rx_diff = max(0, rx - self.last_rx_bytes)

            measured_kbps = int((rx_diff * 8) / (dt * 1000))

            if 48 <= measured_kbps <= 400:

                self.bitrate_kbps = int(self.bitrate_kbps * 0.6 + measured_kbps * 0.4)

        self.last_rx_bytes = rx



        # 3. Compute Buffer percentage & stability

        if elapsed_since_start < 2.0:

            self.buffer_percent = min(100, int(35 + (elapsed_since_start / 2.0) * 65))

            self.status_level = "BUFFERING"

            self.status_text = "جاري التحميل..."

        elif alsa_advancing and alsa_state == "RUNNING":

            self.consecutive_underruns = 0

            self.buffer_percent = min(100, self.buffer_percent + 20)

            if self.buffer_percent >= 80:

                self.status_level = "EXCELLENT"

                self.status_text = "مستقر"

            else:

                self.status_level = "GOOD"

                self.status_text = "جيد"

        else:

            # Underrun or stall detected

            self.consecutive_underruns += 1

            drop = 25 * self.consecutive_underruns

            self.buffer_percent = max(10, self.buffer_percent - drop)

            if self.buffer_percent <= 30:

                self.status_level = "STALLED"

                self.status_text = "تقطيع في البث!"

            else:

                self.status_level = "BUFFERING"

                self.status_text = "جاري موازنة الذاكرة..."



        return self.get_status()



    def get_status(self):

        return {

            "percent": self.buffer_percent,

            "bitrate": self.bitrate_kbps,

            "level": self.status_level,

            "text": self.status_text

        }





# ==========================================

# Audio Playback Engine

# ==========================================

class AudioEngine:

    _instance = None

    vdelay_seconds = 0.0

    adelay_seconds = 0.0



    @classmethod

    def get_instance(cls):

        if cls._instance is None:

            cls._instance = AudioEngine()

        return cls._instance



    def __init__(self):

        self.process = None

        self.current_url = None

        self.current_name = None

        self.is_playing = False

        self.vdelay_seconds = AudioEngine.vdelay_seconds

        self.adelay_seconds = AudioEngine.adelay_seconds

        self.health_monitor = StreamHealthMonitor()



    def get_health_status(self):

        is_alive = bool(self.process and self.process.poll() is None)

        return self.health_monitor.update(process_alive=is_alive)



    def mute_dvb(self, enable=True):

        """Mute/Unmute DVB hardware audio."""

        for adapter in range(2):

            for dev in range(4):

                path = f"/dev/dvb/adapter{adapter}/audio{dev}"

                if os.path.exists(path):

                    try:

                        fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)

                        fcntl.ioctl(fd, AUDIO_SET_MUTE, 1 if enable else 0)

                        os.close(fd)

                    except Exception:

                        pass



    def stop(self, unmute_dvb=True):

        try:

            os.system("amixer set Master unmute 2>/dev/null")

        except Exception:

            pass

        if self.process:

            try:

                os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)

            except Exception:

                try:

                    self.process.kill()

                except Exception:

                    pass

            self.process = None

        

        try:

            os.system("killall -9 gst-launch-1.0 gst-play-1.0 ffmpeg ffplay aplay 2>/dev/null")

        except Exception:

            pass



        self.health_monitor.stop()



        if unmute_dvb:

            self.mute_dvb(False)

        self.is_playing = False

        self.current_url = None

        self.current_name = None



    def disconnect_stream(self):

        """Temporarily disconnects the streaming process and frees network sockets for auto-sync."""

        if self.process:

            try:

                os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)

            except Exception:

                try:

                    self.process.kill()

                except Exception:

                    pass

            self.process = None

        try:

            os.system("killall -9 gst-launch-1.0 gst-play-1.0 ffmpeg ffplay aplay 2>/dev/null")

        except Exception:

            pass

        self.health_monitor.stop()

        self.is_playing = False



    def play(self, url, name="", adelay_ms=0):

        self.stop()

        if not url:

            return False



        self.current_url = url

        self.current_name = name

        self.mute_dvb(True)

        self.health_monitor.start(url)



        eff_adelay_ms = adelay_ms

        if eff_adelay_ms == 0 and getattr(self, "adelay_seconds", 0) > 0:

            eff_adelay_ms = int(round(self.adelay_seconds * 1000.0))

        elif eff_adelay_ms == 0 and getattr(AudioEngine, "adelay_seconds", 0) > 0:

            eff_adelay_ms = int(round(AudioEngine.adelay_seconds * 1000.0))



        engine = config.plugins.IPAudioPlus.sink_engine.value

        vol_choice = config.plugins.IPAudioPlus.volume.value

        vol_map = {

            "normal": 1.0,

            "+20%": 1.2,

            "+50%": 1.5,

            "+100%": 2.0,

            "-20%": 0.8

        }

        vol_float = vol_map.get(vol_choice, 1.0)



        timeout_str = config.plugins.IPAudioPlus.timeout.value

        try:

            timeout_sec = int(timeout_str.split()[0])

        except Exception:

            timeout_sec = 10

        timeout_us = timeout_sec * 1000000



        stretch_choice = config.plugins.IPAudioPlus.time_stretch.value

        atempo_val = 1.0

        if stretch_choice == "0.999x":

            atempo_val = 0.999

        elif stretch_choice == "0.998x":

            atempo_val = 0.998

        elif stretch_choice == "1.001x":

            atempo_val = 1.001



        af_filters = [f"volume={vol_float}"]

        if atempo_val != 1.0:

            af_filters.append(f"atempo={atempo_val}")

        if eff_adelay_ms > 0:

            af_filters.append(f"adelay={int(eff_adelay_ms)}|{int(eff_adelay_ms)}")



        af_str = ",".join(af_filters)



        # When adelay or tempo stretch is active, ffmpeg provides sample-accurate hardware/filter delay

        if engine == "ffmpeg" or atempo_val != 1.0 or eff_adelay_ms > 0:

            cmd = f'ffmpeg -nostats -loglevel error -fflags +nobuffer+fastseek -timeout {timeout_us} -i "{url}" -af "{af_str}" -vn -f alsa default'

        elif engine == "gst-play":

            cmd = f'gst-play-1.0 "{url}" --flags=0x02 --no-interactive --audiosink="alsasink buffer-time=100000 latency-time=20000" --volume={vol_float}'

        elif engine in ("alsa", "eXteplayer3"):

            cmd = f'ffmpeg -re -timeout {timeout_us} -i "{url}" -af "{af_str}" -vn -f wav - | aplay -D default -B 100000'

        else:

            cmd = f'gst-launch-1.0 playbin uri="{url}" flags=0x02 buffer-duration=400000000 volume={vol_float} audio-sink="alsasink buffer-time=100000 latency-time=20000" video-sink="fakesink"'



        try:

            self.process = subprocess.Popen(

                cmd,

                shell=True,

                stdout=subprocess.DEVNULL,

                stderr=subprocess.DEVNULL,

                preexec_fn=os.setsid

            )

            self.is_playing = True

            return True

        except Exception:

            return False



    def pause(self):

        """Instant pause audio playback process with zero stream loss."""

        if self.process:

            try:

                os.killpg(os.getpgid(self.process.pid), signal.SIGSTOP)

            except Exception:

                try:

                    self.process.send_signal(signal.SIGSTOP)

                except Exception:

                    pass



    def resume(self):

        """Instant resume audio playback process."""

        if self.process:

            try:

                os.killpg(os.getpgid(self.process.pid), signal.SIGCONT)

            except Exception:

                try:

                    self.process.send_signal(signal.SIGCONT)

                except Exception:

                    pass







# ==========================================

# Developer Info Screen (About & Programmer Credits)

# ==========================================

class DeveloperInfoScreen(Screen):

    skin = f"""

    <screen name="DeveloperInfoScreen" position="center,center" size="1020,600" flags="wfNoBorder" backgroundColor="transparent">

        <!-- Outer Glow Border -->

        <eLabel position="0,0" size="1020,600" backgroundColor="#007ac4" zPosition="0" />

        <eLabel position="2,2" size="1016,596" backgroundColor="#050810" zPosition="1" />

        

        <!-- Header Banner Container -->

        <eLabel position="2,2" size="1016,80" backgroundColor="#0a1224" zPosition="2" />

        <eLabel position="2,80" size="1016,2" backgroundColor="#007ac4" zPosition="3" />

        

        <!-- Header Title -->

        <widget name="title" position="30,16" size="960,50" font="DeveloperFont; 28" foregroundColor="#38bdf8" transparent="1" halign="center" valign="center" zPosition="4" />

        

        <!-- Developer Badge Pill -->

        <eLabel position="210,102" size="600,44" backgroundColor="#0f1f38" zPosition="2" />

        <widget name="badge" position="210,102" size="600,44" font="DeveloperFont; 22" foregroundColor="#f59e0b" transparent="1" halign="center" valign="center" zPosition="3" />

        

        <!-- Top Accent Divider -->

        <eLabel position="50,165" size="920,1" backgroundColor="#1e293b" zPosition="2" />

        

        <!-- Message Box with Beautiful Arabic Typography -->

        <widget name="message" position="40,180" size="940,310" font="DeveloperFont; 24" foregroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="4" />

        

        <!-- Bottom Divider -->

        <eLabel position="50,510" size="920,1" backgroundColor="#1e293b" zPosition="2" />

        

        <!-- Footer Return Hint -->

        <widget name="footer_hint" position="50,528" size="920,44" font="DeveloperFont; 20" foregroundColor="#94a3b8" transparent="1" halign="center" valign="center" zPosition="4" />

    </screen>

    """



    def __init__(self, session):

        Screen.__init__(self, session)

        self.session = session



        self["title"] = Label("معلومات التطبيق والمبرمج | Developer Info")

        self["badge"] = Label("⭐ Designed & Developed by MR HEX ⭐")



        msg_lines = [

            "« تمت برمجة هذا البلجن عن طريق MR HEX وهو لوجه الله تعالى »",

            "",

            "أرجو الدعاء لي ولوالدي بالتوفيق إخوتي بارك الله فيكم،",

            "ولا تنسوا موعد صلاتكم، فلا تُلْهِكُم المباريات عن الصلاة،",

            "واذكروا الله كثيراً.",

            "",

            "أخوكم المحب دائماً: أحمد القيسي"

        ]

        self["message"] = Label("\n".join(msg_lines))

        self["footer_hint"] = Label("اضغط [ OK ] أو [ EXIT ] أو [ INFO ] للرجوع")



        self["actions"] = ActionMap(

            ["IPAudioPlusActions", "OkCancelActions", "ColorActions"],

            {

                "ok": self.close,

                "exit": self.close,

                "cancel": self.close,

                "info": self.close,

                "red": self.close,

                "green": self.close,

                "yellow": self.close,

                "blue": self.close,

            },

            -1

        )





# ==========================================

# Audio Token Generator Screen (مولد الصوتيات الذكي)

# ==========================================

class TokenGeneratorScreen(Screen):

    skin = """

    <screen name="TokenGeneratorScreen" position="center,center" size="1060,680" flags="wfNoBorder" backgroundColor="transparent">

        <!-- Outer Glow Border -->

        <eLabel position="0,0" size="1060,680" backgroundColor="#007ac4" zPosition="0" />

        <eLabel position="2,2" size="1056,676" backgroundColor="#050810" zPosition="1" />



        <!-- Header Banner Container -->

        <eLabel position="2,2" size="1056,80" backgroundColor="#0a1224" zPosition="2" />

        <eLabel position="2,80" size="1056,2" backgroundColor="#007ac4" zPosition="3" />



        <!-- Header Title -->

        <widget name="title" position="30,16" size="1000,50" font="DeveloperFont; 28" foregroundColor="#38bdf8" transparent="1" halign="center" valign="center" zPosition="4" />



        <!-- Top Badge Pill -->

        <eLabel position="230,94" size="600,34" backgroundColor="#0f1f38" zPosition="2" />

        <widget name="badge" position="230,94" size="600,34" font="DeveloperFont; 20" foregroundColor="#f59e0b" transparent="1" halign="center" valign="center" zPosition="3" />



        <!-- Focus Pointer -->

        <widget name="focus_pointer" position="40,146" size="8,68" backgroundColor="#38bdf8" zPosition="5" />



        <!-- Row 0: Provider Card -->

        <eLabel position="54,142" size="952,76" backgroundColor="#091322" zPosition="2" />

        <widget name="lbl_provider" position="80,148" size="240,30" font="DeveloperFont; 20" foregroundColor="#94a3b8" transparent="1" halign="left" valign="center" zPosition="3" />

        <widget name="provider_val" position="320,148" size="460,64" font="DeveloperFont; 26" foregroundColor="#38bdf8" transparent="1" halign="center" valign="center" zPosition="3" />

        <widget name="provider_badge" position="800,154" size="180,50" font="DeveloperFont; 20" foregroundColor="#10b981" transparent="1" halign="center" valign="center" zPosition="3" />



        <!-- Row 1: Username Card -->

        <eLabel position="54,234" size="952,76" backgroundColor="#091322" zPosition="2" />

        <widget name="lbl_username" position="80,240" size="300,28" font="DeveloperFont; 20" foregroundColor="#94a3b8" transparent="1" halign="left" valign="center" zPosition="3" />

        <widget name="username_val" position="80,268" size="780,38" font="DeveloperFont; 22" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="3" />

        <widget name="lbl_ok_user" position="880,250" size="100,44" font="DeveloperFont; 20" foregroundColor="#007ac4" transparent="1" halign="right" valign="center" zPosition="3" />



        <!-- Row 2: Password / Token Card -->

        <eLabel position="54,326" size="952,76" backgroundColor="#091322" zPosition="2" />

        <widget name="lbl_password" position="80,332" size="450,28" font="DeveloperFont; 20" foregroundColor="#94a3b8" transparent="1" halign="left" valign="center" zPosition="3" />

        <widget name="password_val" position="80,360" size="780,38" font="DeveloperFont; 22" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="3" />

        <widget name="lbl_ok_pass" position="880,342" size="100,44" font="DeveloperFont; 20" foregroundColor="#007ac4" transparent="1" halign="right" valign="center" zPosition="3" />



        <!-- Row 3: Live Preview Card -->

        <eLabel position="54,418" size="952,132" backgroundColor="#070d18" zPosition="2" />

        <widget name="lbl_preview" position="80,424" size="880,28" font="DeveloperFont; 19" foregroundColor="#f59e0b" transparent="1" halign="left" valign="center" zPosition="3" />

        <widget name="preview_val" position="80,454" size="900,40" font="Regular; 19" foregroundColor="#a5f3fc" transparent="1" halign="left" valign="center" zPosition="3" />

        <widget name="lbl_savepath" position="80,498" size="170,28" font="DeveloperFont; 18" foregroundColor="#64748b" transparent="1" halign="left" valign="center" zPosition="3" />

        <eLabel text="/etc/enigma2/IPAudioPro.json" position="250,498" size="500,28" font="Regular; 18" foregroundColor="#38bdf8" transparent="1" halign="left" valign="center" zPosition="3" />



        <!-- Footer Divider -->

        <eLabel position="50,560" size="960,1" backgroundColor="#1e293b" zPosition="2" />



        <!-- Footer Action Buttons -->

        <!-- Green: Save & Generate -->

        <widget name="bar_green" position="70,578" size="4,24" alphatest="blend" zPosition="2" />

        <widget name="btn_green_text" position="84,572" size="230,36" font="DeveloperFont; 22" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="3" />



        <!-- Yellow: Clear -->

        <widget name="bar_yellow" position="370,578" size="4,24" alphatest="blend" zPosition="2" />

        <widget name="btn_yellow_text" position="384,572" size="230,36" font="DeveloperFont; 22" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="3" />



        <!-- Red: Exit -->

        <widget name="bar_red" position="670,578" size="4,24" alphatest="blend" zPosition="2" />

        <widget name="btn_red_text" position="684,572" size="230,36" font="DeveloperFont; 22" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="3" />



        <!-- Navigation Hint -->

        <widget name="footer_hint" position="50,622" size="960,34" font="DeveloperFont; 18" foregroundColor="#94a3b8" transparent="1" halign="center" valign="center" zPosition="3" />

    </screen>

    """



    def __init__(self, session):

        Screen.__init__(self, session)

        self.session = session



        self.providers = ["Orange", "SATFAMILY", "Best"]

        self.current_provider_idx = 0



        self.username = ""

        self.password = ""

        self.focused_row = 0  # 0: Provider, 1: Username, 2: Password, 3: Save



        self.templates = self._load_templates()



        self["title"] = Label("مولد الصوتيات الذكي | Audio Stream Generator")

        self["badge"] = Label("Orange • SATFAMILY • Best")



        self["lbl_provider"] = Label("مزود الصوتيات:")

        self["provider_val"] = Label("")

        self["provider_badge"] = Label("")



        self["lbl_username"] = Label("اسم المستخدم:")

        self["username_val"] = Label("")

        self["lbl_ok_user"] = Label("[ OK ]")



        self["lbl_password"] = Label("كلمة المرور أو التوكن:")

        self["password_val"] = Label("")

        self["lbl_ok_pass"] = Label("[ OK ]")



        self["lbl_preview"] = Label("معاينة الرابط المولد:")

        self["preview_val"] = Label("")

        self["lbl_savepath"] = Label("مسار الحفظ:")



        self["btn_green_text"] = Label("توليد وحفظ (Green)")

        self["btn_yellow_text"] = Label("مسح الحقول (Yellow)")

        self["btn_red_text"] = Label("خروج / إلغاء (Red)")

        self["footer_hint"] = Label("استخدم الأسهم للتنقل • [ OK ] لتعديل البيانات • [ الأخضر ] لتوليد وحفظ البلاي لست")



        self["focus_pointer"] = Pixmap()

        self["bar_green"] = Pixmap()

        self["bar_yellow"] = Pixmap()

        self["bar_red"] = Pixmap()



        self["actions"] = ActionMap(

            ["IPAudioPlusActions", "OkCancelActions", "ColorActions", "DirectionActions"],

            {

                "ok": self.on_ok,

                "cancel": self.close,

                "exit": self.close,

                "up": self.on_up,

                "down": self.on_down,

                "left": self.on_left,

                "right": self.on_right,

                "green": self.save_and_generate,

                "yellow": self.clear_fields,

                "red": self.close,

            },

            -1

        )



        self.onLayoutFinish.append(self._on_layout_finish)



    def _on_layout_finish(self):

        def set_pix(widget, filename):

            p = os.path.join(IMG_PATH, filename)

            if os.path.exists(p):

                widget.instance.setPixmap(loadPNG(p))



        set_pix(self["bar_green"], "bar_green.png")

        set_pix(self["bar_yellow"], "bar_yellow.png")

        set_pix(self["bar_red"], "bar_red.png")



        self._load_saved_provider_data()

        self._update_ui()



    def _load_templates(self):

        p = os.path.join(PLUGIN_PATH, "provider_templates.json")

        if os.path.exists(p):

            try:

                with open(p, "r", encoding="utf-8") as f:

                    return json.load(f)

            except Exception as e:

                print(f"[IPAudioPlus] Error reading provider_templates.json: {e}")

        return PROVIDER_TEMPLATES_DEFAULT



    def _load_saved_provider_data(self):

        provider = self.providers[self.current_provider_idx]

        json_path = "/etc/enigma2/IPAudioPro.json"

        self.username = ""

        self.password = ""

        if os.path.exists(json_path):

            try:

                with open(json_path, "r", encoding="utf-8") as f:

                    data = json.load(f)

                if isinstance(data, dict) and provider in data:

                    p_info = data[provider]

                    self.username = p_info.get("username", "")

                    self.password = p_info.get("password", "") or p_info.get("token", "")

            except Exception as e:

                print(f"[IPAudioPlus] Error loading saved provider data: {e}")



    def _update_ui(self):

        provider = self.providers[self.current_provider_idx]

        chs = self.templates.get(provider, [])

        ch_count = len(chs)



        self["provider_val"].setText(f"◀   {provider}   ▶")

        if ch_count > 0:

            self["provider_badge"].setText(f"({ch_count} قناة)")

        else:

            self["provider_badge"].setText("(قريباً)")



        u_display = self.username if self.username else "اضغط [ OK ] لإدخال اسم المستخدم..."

        p_display = self.password if self.password else "اضغط [ OK ] لإدخال كلمة المرور أو التوكن..."

        self["username_val"].setText(u_display)

        self["password_val"].setText(p_display)



        token = self._calculate_token()

        if ch_count > 0 and chs:

            sample_base = chs[0]["base_url"]

            if token:

                preview = f"{sample_base}{token}#"

            else:

                preview = f"{sample_base}[TOKEN]#"

        else:

            if provider == "Best":

                preview = "مزود Best غير متوفر حالياً لعدم توفر اشتراك، سيتم إضافته قريباً"

            else:

                preview = "لا توجد قنوات متاحة لهذا المزود"

        self["preview_val"].setText(preview)



        # Move focus pointer

        y_pos = 146

        if self.focused_row == 0:

            y_pos = 146

        elif self.focused_row == 1:

            y_pos = 238

        elif self.focused_row == 2:

            y_pos = 330

        elif self.focused_row == 3:

            y_pos = 570



        if hasattr(self["focus_pointer"], "instance") and self["focus_pointer"].instance:

            self["focus_pointer"].instance.move(ePoint(40, y_pos))



    def _calculate_token(self):

        u = self.username.strip()

        p = self.password.strip()

        if not p and not u:

            return ""

        if p:

            if u and (p.startswith(u + "_") or p.startswith(u)):

                return p

            elif u:

                return f"{u}_{p}"

            else:

                return p

        return u



    def on_up(self):

        self.focused_row = (self.focused_row - 1) % 4

        self._update_ui()



    def on_down(self):

        self.focused_row = (self.focused_row + 1) % 4

        self._update_ui()



    def on_left(self):

        if self.focused_row == 0:

            self.current_provider_idx = (self.current_provider_idx - 1) % len(self.providers)

            self._load_saved_provider_data()

            self._update_ui()

        elif self.focused_row in (1, 2):

            self.on_ok()



    def on_right(self):

        if self.focused_row == 0:

            self.current_provider_idx = (self.current_provider_idx + 1) % len(self.providers)

            self._load_saved_provider_data()

            self._update_ui()

        elif self.focused_row in (1, 2):

            self.on_ok()



    
    def on_ok(self):

        if self.focus_state == "token_gen":

            if self.tg_focused_row == 0:

                self.tg_provider_idx = (self.tg_provider_idx + 1) % len(self.tg_providers)

                self.load_tg_saved_data()

                self.update_tg_ui()

            elif self.tg_focused_row == 1:

                self.session.openWithCallback(self._on_tg_username_entered, VirtualKeyBoard, title="Enter Username / اسم المستخدم:", text=self.tg_username)

            elif self.tg_focused_row == 2:

                self.session.openWithCallback(self._on_tg_password_entered, VirtualKeyBoard, title="Enter Password / Token / كلمة المرور:", text=self.tg_password)

            elif self.tg_focused_row == 3:

                self.test_stream_flow()

            return

        if self.focused_row == 0:

            self.current_provider_idx = (self.current_provider_idx + 1) % len(self.providers)

            self._load_saved_provider_data()

            self._update_ui()

        elif self.focused_row == 1:

            self.session.openWithCallback(self._on_username_entered, VirtualKeyBoard, title="أدخل اسم المستخدم (Username):", text=self.username)

        elif self.focused_row == 2:

            self.session.openWithCallback(self._on_password_entered, VirtualKeyBoard, title="أدخل كلمة المرور أو التوكن (Password / Token):", text=self.password)

        elif self.focused_row == 3:

            self.save_and_generate()



    def _on_username_entered(self, text):

        if text is not None:

            self.username = text.strip()

            self._update_ui()



    def _on_password_entered(self, text):

        if text is not None:

            self.password = text.strip()

            self._update_ui()



    def clear_fields(self):

        self.username = ""

        self.password = ""

        self._update_ui()



    def save_and_generate(self):

        provider = self.providers[self.current_provider_idx]

        channels_template = self.templates.get(provider, [])



        if not channels_template:

            self.session.open(MessageBox, f"مزود {provider} غير متوفر حالياً، سيتم إضافته قريباً!", MessageBox.TYPE_WARNING, timeout=5)

            return



        token = self._calculate_token()

        if not token:

            self.session.open(MessageBox, "يرجى إدخال اسم المستخدم أو كلمة المرور / التوكن أولاً!", MessageBox.TYPE_ERROR, timeout=5)

            return



        channels = []

        for idx, item in enumerate(channels_template, 1):

            base_url = item.get("base_url", "")

            full_url = f"{base_url}{token}#"

            ch_name = item.get("name", f"Channel {idx}")

            channels.append({

                "Name": ch_name,

                "name": ch_name,

                "display_name": ch_name,

                "Id": str(idx),

                "id": str(idx),

                "Url": full_url,

                "url": full_url

            })



        json_path = "/etc/enigma2/IPAudioPro.json"

        data = {}

        if os.path.exists(json_path):

            try:

                with open(json_path, "r", encoding="utf-8") as f:

                    content = f.read().strip()

                    if content:

                        data = json.loads(content)

                        if not isinstance(data, dict):

                            data = {}

            except Exception as e:

                print(f"[IPAudioPlus] Error loading existing IPAudioPro.json: {e}")

                data = {}



        badge = "SF" if provider == "SATFAMILY" else ("ORG" if provider == "Orange" else "BEST")



        data[provider] = {

            "Id": badge,

            "badge": badge,

            "username": self.username,

            "password": self.password,

            "token": token,

            "channels": channels,

            "streams": channels

        }



        try:

            with open(json_path, "w", encoding="utf-8") as f:

                json.dump(data, f, ensure_ascii=False, indent=2)

        except Exception as e:

            self.session.open(MessageBox, f"خطأ في حفظ الملف: {e}", MessageBox.TYPE_ERROR, timeout=5)

            return



        msg = f"تم بنجاح توليد وحفظ قائمة {provider}\nعدد القنوات: {len(channels)}\nتم حفظها في {json_path}\nوإضافتها إلى قائمة Selected Server!"

        self.session.openWithCallback(self._on_saved_confirm, MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)



    def _on_saved_confirm(self, *args):

        self.close(True)





# ==========================================

# Config / Settings Screen

# ==========================================

class IPAudioPlusConfigScreen(Screen):

    skin = f"""

    <screen name="IPAudioPlusConfigScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent">

        <!-- Right Side Dark Container -->

        <eLabel position="1346,0" size="574,1080" backgroundColor="#050810" zPosition="0" />

        <eLabel position="1228,18" size="118,84" backgroundColor="#007ac4" zPosition="0" />



        <!-- Top Banner Header (IP AUDIO+ Config) -->

        <widget name="header_banner" position="1228,18" size="692,84" zPosition="1" alphatest="blend" />



        <!-- Config Menu Items List -->

        <widget name="config_list" position="1346,120" size="574,780" backgroundColor="#050810" selectionPixmap="{IMG_PATH}/config_selected_bg.png" enableWrapAround="1" scrollbarMode="showNever" transparent="0" zPosition="2" />



        <!-- Footer / Action Buttons -->

        <!-- Save (Green) -->

        <widget name="bar_green" position="1380,924" size="24,24" alphatest="blend" zPosition="2" />

        <eLabel text="Save" position="1412,918" size="120,36" font="Regular; 24" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="2" />



        <!-- Defaults (Yellow) -->

        <eLabel text="Defaults" position="1760,918" size="110,36" font="Regular; 24" foregroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="2" />

        <widget name="bar_yellow" position="1876,924" size="24,24" alphatest="blend" zPosition="2" />

    </screen>

    """



    def __init__(self, session):

        Screen.__init__(self, session)

        self.session = session



        self["header_banner"] = Pixmap()

        self["config_list"] = ConfigMenuList([])



        self["bar_green"] = Pixmap()

        self["bar_yellow"] = Pixmap()



        self["actions"] = ActionMap(

            ["IPAudioPlusActions", "DirectionActions", "ColorActions", "OkCancelActions"],

            {

                "ok": self.toggle_option,

                "exit": self.close,

                "cancel": self.close,

                "up": self.on_up,

                "down": self.on_down,

                "left": self.prev_option,

                "right": self.next_option,

                "green": self.save_settings,

                "yellow": self.reset_defaults,

                "red": self.close,

                "info": self.open_info,

            },

            -1

        )



        self.options_data = [

            {"id": "show_main_menu", "type": "switch", "title": "Show in Main Menu", "cfg": config.plugins.IPAudioPlus.show_main_menu},

            {"id": "show_plugin_list", "type": "switch", "title": "Show in Plugin List", "cfg": config.plugins.IPAudioPlus.show_plugin_list},

            {"id": "show_extension_list", "type": "switch", "title": "Show in Extension List", "cfg": config.plugins.IPAudioPlus.show_extension_list},

            {"id": "sep1", "type": "separator", "title": ""},

            {"id": "web_interface", "type": "switch", "title": "Web Interface (Browser)", "cfg": config.plugins.IPAudioPlus.web_interface},

            {"id": "web_port", "type": "value", "title": "Web Server Port", "cfg": config.plugins.IPAudioPlus.web_port},

            {"id": "web_url", "type": "link", "title": "Web URL", "val_func": self.get_web_url_text},

            {"id": "sep2", "type": "separator", "title": ""},

            {"id": "timeout", "type": "value", "title": "Timeout", "cfg": config.plugins.IPAudioPlus.timeout},

            {"id": "port", "type": "value", "title": "Port", "cfg": config.plugins.IPAudioPlus.port},

            {"id": "descramble_http", "type": "switch", "title": "Descramble http", "cfg": config.plugins.IPAudioPlus.descramble_http},

            {"id": "auth_http", "type": "switch", "title": "Authentication http", "cfg": config.plugins.IPAudioPlus.auth_http},

            {"id": "ecm_http", "type": "switch", "title": "ECM in http", "cfg": config.plugins.IPAudioPlus.ecm_http},

            {"id": "sink_engine", "type": "value", "title": "Sink engine", "cfg": config.plugins.IPAudioPlus.sink_engine},

            {"id": "volume", "type": "value", "title": "Volume", "cfg": config.plugins.IPAudioPlus.volume},

            {"id": "sep3", "type": "separator", "title": ""},

            {"id": "user_list_path", "type": "value", "title": "User list path", "cfg": config.plugins.IPAudioPlus.user_list_path},

            {"id": "anti_spoiler", "type": "switch", "title": "Anti-Spoiler Shield (درع مانع الحرق)", "cfg": config.plugins.IPAudioPlus.anti_spoiler},

            {"id": "anti_spoiler_margin", "type": "value", "title": "Anti-Spoiler Safety Floor (حاجز الأمان)", "cfg": config.plugins.IPAudioPlus.anti_spoiler_margin},

            {"id": "silent_corrector", "type": "value", "title": "Silent Micro-Corrector (المصحح الصامت)", "cfg": config.plugins.IPAudioPlus.silent_corrector},

            {"id": "time_stretch", "type": "value", "title": "Time Stretch Tempo (سرعة التشغيل)", "cfg": config.plugins.IPAudioPlus.time_stretch},

            {"id": "sep_ts", "type": "separator", "title": ""},

            {"id": "timeshift_storage", "type": "value", "title": "Timeshift Storage (Mount Point)", "cfg": config.plugins.IPAudioPlus.timeshift_storage},

            {"id": "timeshift_custom_path", "type": "value", "title": "Timeshift Custom Path", "cfg": config.plugins.IPAudioPlus.timeshift_custom_path},

            {"id": "elastic_buffer", "type": "switch", "title": "Dynamic Elastic Buffer (Auto-Healing)", "cfg": config.plugins.IPAudioPlus.elastic_buffer},

            {"id": "check_update", "type": "switch", "title": "Check for update (Auto)", "cfg": config.plugins.IPAudioPlus.check_update},
            {"id": "check_update_now", "type": "link", "title": "Check for update now (فحص الآن)", "val_func": lambda: "Press OK to check"},

        ]



        self.onLayoutFinish.append(self.setup_ui)



    def setup_ui(self):

        def set_pix(widget, filename):

            p = os.path.join(IMG_PATH, filename)

            if os.path.exists(p):

                widget.instance.setPixmap(loadPNG(p))



        set_pix(self["header_banner"], "header_config_banner.png")

        set_pix(self["bar_green"], "bar_green.png")

        set_pix(self["bar_yellow"], "bar_yellow.png")



        self.refresh_list()



    def get_web_url_text(self):

        if config.plugins.IPAudioPlus.web_interface.value == "ON":

            try:

                from . import web_server

                ip = web_server.get_lan_ip()

                p = config.plugins.IPAudioPlus.web_port.value

                return f"http://{ip}:{p}"

            except Exception:

                return f"Port {config.plugins.IPAudioPlus.web_port.value}"

        else:

            return "Disabled"



    def refresh_list(self):

        entries = []

        for opt in self.options_data:

            if opt["type"] == "separator":

                entries.append(build_config_entry("separator", ""))

            elif opt["type"] == "link":

                val = opt["val_func"]() if "val_func" in opt else ""

                entries.append(build_config_entry("link", opt["title"], val))

            else:

                val = opt["cfg"].value

                entries.append(build_config_entry(opt["type"], opt["title"], val))

        

        idx = self["config_list"].getSelectedIndex()

        self["config_list"].setList(entries)

        if idx is not None:

            self["config_list"].moveToIndex(idx)



    def get_current_option(self):

        idx = self["config_list"].getSelectedIndex()

        if idx is not None and 0 <= idx < len(self.options_data):

            opt = self.options_data[idx]

            if opt["type"] != "separator":

                return opt

        return None



    def on_up(self):

        self["config_list"].up()

        opt = self.get_current_option()

        if not opt:

            self["config_list"].up()



    def on_down(self):

        self["config_list"].down()

        opt = self.get_current_option()

        if not opt:

            self["config_list"].down()



    def toggle_option(self):

        opt = self.get_current_option()

        if opt and opt.get("id") == "check_update_now":
            self.manual_check_update()
            return

        if opt and "cfg" in opt:

            if opt["type"] == "switch":

                opt["cfg"].value = "OFF" if opt["cfg"].value == "ON" else "ON"

            else:

                self.next_option()

            self.refresh_list()



    def next_option(self):

        opt = self.get_current_option()

        if opt and "cfg" in opt:

            choices = [c[0] for c in opt["cfg"].choices.choices] if hasattr(opt["cfg"], "choices") else []

            if choices:

                cur = opt["cfg"].value

                if cur in choices:

                    idx = (choices.index(cur) + 1) % len(choices)

                    opt["cfg"].value = choices[idx]

                else:

                    opt["cfg"].value = choices[0]

            elif opt["type"] == "switch":

                opt["cfg"].value = "OFF" if opt["cfg"].value == "ON" else "ON"

            self.refresh_list()



    def prev_option(self):

        opt = self.get_current_option()

        if opt and "cfg" in opt:

            choices = [c[0] for c in opt["cfg"].choices.choices] if hasattr(opt["cfg"], "choices") else []

            if choices:

                cur = opt["cfg"].value

                if cur in choices:

                    idx = (choices.index(cur) - 1) % len(choices)

                    opt["cfg"].value = choices[idx]

                else:

                    opt["cfg"].value = choices[0]

            elif opt["type"] == "switch":

                opt["cfg"].value = "OFF" if opt["cfg"].value == "ON" else "ON"

            self.refresh_list()



    def open_info(self):

        self.session.open(DeveloperInfoScreen)







    def reset_defaults(self):

        config.plugins.IPAudioPlus.show_main_menu.value = "ON"

        config.plugins.IPAudioPlus.show_plugin_list.value = "ON"

        config.plugins.IPAudioPlus.show_extension_list.value = "ON"

        config.plugins.IPAudioPlus.web_interface.value = "ON"

        config.plugins.IPAudioPlus.web_port.value = "8088"

        config.plugins.IPAudioPlus.timeout.value = "10 sec."

        config.plugins.IPAudioPlus.port.value = "8001"

        config.plugins.IPAudioPlus.descramble_http.value = "ON"

        config.plugins.IPAudioPlus.auth_http.value = "OFF"

        config.plugins.IPAudioPlus.ecm_http.value = "OFF"

        config.plugins.IPAudioPlus.sink_engine.value = "gst-launch"

        config.plugins.IPAudioPlus.volume.value = "normal"

        config.plugins.IPAudioPlus.user_list_path.value = "default"

        config.plugins.IPAudioPlus.check_update.value = "ON"

        self.refresh_list()



    
    def manual_check_update(self):
        from . import updater
        url = config.plugins.IPAudioPlus.update_url.value
        has_up, info, err = updater.check_for_updates(url, timeout=6)
        if err:
            self.session.open(MessageBox, f"خطأ أثناء فحص التحديث:\n{err}", MessageBox.TYPE_ERROR, timeout=6)
        elif has_up and info:
            new_v = info.get("remote_version", "")
            desc = info.get("description", "")
            chgs = "\n".join(info.get("changelog", []))
            msg = f"🔔 يوجد إصدار جديد متاح للبلجن (v{new_v})!\n\n{desc}\n\nأبرز التغييرات:\n{chgs}\n\nهل تريد تثبيت التحديث الآن؟"
            self.session.openWithCallback(
                lambda res: self._on_confirm_manual_update(res, info),
                MessageBox,
                msg,
                MessageBox.TYPE_YESNO
            )
        else:
            self.session.open(MessageBox, f"البلجن محدث لآخر إصدار بالفعل! (v{updater.CURRENT_VERSION})", MessageBox.TYPE_INFO, timeout=5)

    def _on_confirm_manual_update(self, confirmed, info):
        if confirmed:
            dl_url = info.get("download_url") or info.get("ipk_url")
            if dl_url:
                from . import updater
                ok, msg = updater.download_and_install_update(dl_url)
                if ok:
                    self.session.openWithCallback(
                        lambda res: updater.restart_gui() if res else None,
                        MessageBox,
                        f"{msg}\n\nهل تريد إعادة تشغيل واجهة الرسيفر الآن؟",
                        MessageBox.TYPE_YESNO
                    )
                else:
                    self.session.open(MessageBox, f"فشل التحديث:\n{msg}", MessageBox.TYPE_ERROR, timeout=8)

    def save_settings(self):

        for opt in self.options_data:

            if "cfg" in opt:

                opt["cfg"].save()

        apply_timeshift_storage()

        configfile.save()

        if config.plugins.IPAudioPlus.web_interface.value == "ON":

            try:

                from . import web_server

                web_server.register_reload_callback(IPAudioPlusScreen.reload_channels_from_web)

                web_server.start_server(int(config.plugins.IPAudioPlus.web_port.value))

            except Exception as e:

                print(f"[IPAudioPlus] Failed to start web server: {e}")

        else:

            try:

                from . import web_server

                web_server.stop_server()

            except Exception:

                pass

        self.close()





# ==========================================

# Main IP AudioPlus Screen

# ==========================================

class IPAudioPlusScreen(Screen):

    active_instance = None



    @classmethod

    def reload_channels_from_web(cls):

        if cls.active_instance is not None:

            try:

                cls.active_instance.load_data()

                cls.active_instance.update_channels_view()

                print("[IPAudioPlus] Refreshed channels from web server!")

            except Exception as e:

                print(f"[IPAudioPlus] Error updating screen from web: {e}")



    skin = f"""

    <screen name="IPAudioPlusScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent">

        

        <!-- Top-Left Status Bar -->

        <widget name="status_bg" position="55,48" size="1088,56" zPosition="1" alphatest="blend" />

        <widget name="status_text" position="80,52" size="1040,48" font="Regular; 28" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="2" />



        <!-- Right Side Dark Container -->

        <eLabel position="1346,0" size="574,1080" backgroundColor="#050810" zPosition="0" />

        <eLabel position="1228,18" size="118,84" backgroundColor="#007ac4" zPosition="0" />



        <!-- Top Banner Header (IP AUDIO+) -->

        <widget name="header_banner" position="1228,18" size="692,84" zPosition="1" alphatest="blend" />



        <!-- Section 1: Server Header (Normal & Expanded) -->

        <widget name="server_hdr_bg" position="1346,118" size="574,56" zPosition="1" alphatest="blend" />

        <widget name="server_hdr_exp_bg" position="686,118" size="660,56" zPosition="3" alphatest="blend" />

        <widget name="icon_server" position="1366,128" size="36,36" alphatest="blend" zPosition="2" />

        <widget name="server_title" position="1414,122" size="486,48" font="Bold; 38" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="2" />

        <widget name="icon_server_exp" position="706,128" size="36,36" alphatest="blend" zPosition="4" />

        <widget name="server_title_exp" position="754,122" size="580,48" font="Bold; 38" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="4" />



        <!-- Section 1: Server Content Row (Right sidebar) -->

        <widget name="server_row_bg" position="1346,176" size="574,54" zPosition="1" alphatest="blend" />

        <eLabel text="Selected server" position="1388,182" size="320,42" font="Bold; 26" foregroundColor="#cbd5e1" transparent="1" halign="left" valign="center" zPosition="2" />

        <widget name="server_val" position="1720,182" size="170,42" font="Bold; 26" foregroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="2" />



        <!-- Section 1 Expanded Popup: Server List (660px wide matching reference screenshot) -->

        <widget name="server_list" position="686,176" size="660,364" backgroundColor="#0a0e16" backgroundColorSelected="#0a0e16" selectionPixmap="{IMG_PATH}/server_card_selected.png" enableWrapAround="1" scrollbarMode="showNever" transparent="0" zPosition="5" />



        <!-- Section 4: Live Info Window (Left Side - Shown on Blue Button) -->

        <widget name="live_info_bg" position="300,120" size="830,900" zPosition="4" alphatest="blend" />

        <widget name="live_info_title" position="300,135" size="830,45" font="Bold; 34" foregroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="5" />

        <widget name="live_info_list" position="325,190" size="780,810" enableWrapAround="1" scrollbarMode="showNever" transparent="1" zPosition="5" />



        <!-- Section 5: Audio Token Generator Side Panel (Left Side beside Main Plugin) -->

        <widget name="tg_bg" position="460,140" size="860,740" zPosition="4" alphatest="blend" />

        <widget name="tg_title" position="480,150" size="820,36" font="Bold; 28" foregroundColor="#38bdf8" transparent="1" halign="center" valign="center" zPosition="5" />

        <widget name="tg_focus_pointer" position="474,200" size="6,46" zPosition="7" alphatest="blend" />



        <!-- Source / Provider Tabs Row -->

        <widget name="tg_tab_0_bg" position="500,200" size="210,46" zPosition="5" alphatest="blend" />

        <widget name="tg_tab_0_lbl" position="500,200" size="210,46" font="Bold; 22" foregroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="6" />



        <widget name="tg_tab_1_bg" position="725,200" size="210,46" zPosition="5" alphatest="blend" />

        <widget name="tg_tab_1_lbl" position="725,200" size="210,46" font="Bold; 22" foregroundColor="#94a3b8" transparent="1" halign="center" valign="center" zPosition="6" />



        <widget name="tg_tab_2_bg" position="950,200" size="210,46" zPosition="5" alphatest="blend" />

        <widget name="tg_tab_2_lbl" position="950,200" size="210,46" font="Bold; 22" foregroundColor="#94a3b8" transparent="1" halign="center" valign="center" zPosition="6" />



        <widget name="tg_lbl_source" position="1170,206" size="110,34" font="Bold; 22" foregroundColor="#94a3b8" transparent="1" halign="center" valign="center" zPosition="5" />



        <!-- Username Row -->

        <widget name="icon_user_field" position="500,262" size="28,28" zPosition="5" alphatest="blend" />

        <widget name="tg_lbl_username" position="536,258" size="300,34" font="Bold; 22" foregroundColor="#cbd5e1" transparent="1" halign="left" valign="center" zPosition="5" />

        <widget name="tg_username_val" position="515,302" size="640,44" font="Bold; 24" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="5" />

        <widget name="tg_lbl_ok_user" position="1180,302" size="90,44" font="Bold; 20" foregroundColor="#38bdf8" transparent="1" halign="center" valign="center" zPosition="5" />



        <!-- Password / Token Row -->

        <widget name="icon_lock_field" position="500,364" size="28,28" zPosition="5" alphatest="blend" />

        <widget name="tg_lbl_password" position="536,360" size="350,34" font="Bold; 22" foregroundColor="#cbd5e1" transparent="1" halign="left" valign="center" zPosition="5" />

        <widget name="tg_password_val" position="515,404" size="640,44" font="Bold; 24" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="5" />

        <widget name="tg_lbl_ok_pass" position="1180,404" size="90,44" font="Bold; 20" foregroundColor="#38bdf8" transparent="1" halign="center" valign="center" zPosition="5" />



        <!-- Stream Flow & Test Box (Audio Stream Bitrate & Latency Test) -->

        <widget name="icon_stream_test" position="500,466" size="32,32" zPosition="5" alphatest="blend" />

        <widget name="tg_lbl_test_title" position="540,464" size="500,34" font="Bold; 22" foregroundColor="#22c55e" transparent="1" halign="left" valign="center" zPosition="5" />

        <widget name="tg_test_status" position="515,508" size="740,32" font="Bold; 21" foregroundColor="#38bdf8" transparent="1" halign="left" valign="center" zPosition="5" />

        <widget name="tg_test_bitrate" position="515,542" size="740,34" font="Bold; 23" foregroundColor="#22c55e" transparent="1" halign="left" valign="center" zPosition="5" />

        <widget name="tg_test_details" position="515,576" size="740,30" font="Regular; 19" foregroundColor="#94a3b8" transparent="1" halign="left" valign="center" zPosition="5" />



        <!-- Save Path -->

        <widget name="tg_lbl_savepath" position="500,642" size="150,28" font="Bold; 20" foregroundColor="#64748b" transparent="1" halign="left" valign="center" zPosition="5" />

        <widget name="tg_val_savepath" position="655,642" size="620,28" font="Regular; 20" foregroundColor="#a5b4fc" transparent="1" halign="left" valign="center" zPosition="5" />



        <!-- Bottom Action Buttons Row -->

        <widget name="tg_bar_green" position="480,684" size="24,24" alphatest="blend" zPosition="5" />

        <widget name="tg_btn_green_text" position="512,680" size="150,32" font="Bold; 22" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="5" />



        <widget name="tg_bar_blue" position="670,684" size="24,24" alphatest="blend" zPosition="5" />

        <widget name="tg_btn_blue_text" position="702,680" size="150,32" font="Bold; 22" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="5" />



        <widget name="tg_bar_yellow" position="860,684" size="24,24" alphatest="blend" zPosition="5" />

        <widget name="tg_btn_yellow_text" position="892,680" size="160,32" font="Bold; 22" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="5" />



        <widget name="tg_bar_red" position="1060,684" size="24,24" alphatest="blend" zPosition="5" />

        <widget name="tg_btn_red_text" position="1092,680" size="140,32" font="Bold; 22" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="5" />



        <!-- Section 2: Audio Header -->

        <widget name="audio_hdr_bg" position="1346,232" size="574,56" zPosition="1" alphatest="blend" />

        <widget name="icon_audio" position="1366,242" size="36,36" alphatest="blend" zPosition="2" />

        <eLabel text="Audio" position="1414,236" size="486,48" font="Bold; 38" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="2" />



        <!-- Section 2: Audio Channels List (Right sidebar) -->

        <widget name="audio_list" position="1346,288" size="574,420" backgroundColor="#0a0e16" backgroundColorSelected="#0a0e16" selectionPixmap="{IMG_PATH}/transparent.png" enableWrapAround="1" scrollbarMode="showNever" transparent="0" zPosition="2" />



        <!-- Section 3: Delay Header -->

        <widget name="delay_hdr_bg" position="1346,708" size="574,56" zPosition="1" alphatest="blend" />

        <widget name="icon_delay_hdr" position="1366,718" size="36,36" alphatest="blend" zPosition="2" />

        <eLabel text="Delay" position="1414,712" size="486,48" font="Bold; 38" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" zPosition="2" />



        <!-- Section 3: Delay Row (vDelay) -->

        <widget name="delay_row_bg" position="1346,766" size="574,54" zPosition="1" alphatest="blend" />

        <widget name="icon_delay" position="1430,775" size="36,36" alphatest="blend" zPosition="2" />

        <eLabel text="vDelay" position="1588,772" size="140,42" font="Bold; 26" foregroundColor="#cbd5e1" transparent="1" halign="left" valign="center" zPosition="2" />

        <widget name="delay_val" position="1780,772" size="110,42" font="Bold; 26" foregroundColor="#ffcc00" transparent="1" halign="right" valign="center" zPosition="2" />



        <!-- Section 3: Delay Row 2 (aDelay directly under vDelay) -->

        <widget name="adelay_row_bg" position="1346,822" size="574,54" zPosition="1" alphatest="blend" />

        <widget name="icon_adelay" position="1430,831" size="36,36" alphatest="blend" zPosition="2" />

        <eLabel text="aDelay" position="1588,828" size="140,42" font="Bold; 26" foregroundColor="#cbd5e1" transparent="1" halign="left" valign="center" zPosition="2" />

        <widget name="adelay_val" position="1780,828" size="110,42" font="Bold; 26" foregroundColor="#ffcc00" transparent="1" halign="right" valign="center" zPosition="2" />



        <!-- Footer / Action Buttons -->

        <!-- Row 1: Menu & Exit Icons (Left) / Reset (Red, Right) -->

        <widget name="icon_settings" position="1384,884" size="32,32" alphatest="blend" zPosition="2" />

        <widget name="icon_exit" position="1440,884" size="32,32" alphatest="blend" zPosition="2" />

        <eLabel text="Reset" position="1740,882" size="120,36" font="Bold; 24" foregroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="2" />

        <widget name="bar_red" position="1876,888" size="24,24" alphatest="blend" zPosition="2" />



        <!-- Row 2: Developer Icon & Text (Left) / Reset all (Yellow, Right) -->

        <widget name="icon_developer" position="1384,938" size="32,32" alphatest="blend" zPosition="2" />

        <eLabel text="Developer" position="1430,936" size="150,36" font="Bold; 24" foregroundColor="#cbd5e1" transparent="1" halign="left" valign="center" zPosition="2" />

        <eLabel text="Reset all" position="1720,936" size="140,36" font="Bold; 24" foregroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="2" />

        <widget name="bar_yellow" position="1876,942" size="24,24" alphatest="blend" zPosition="2" />



        <!-- Row 3: Token Generator Icon & Text (Left) / Live Info (Blue, Right) -->

        <widget name="icon_user" position="1384,982" size="32,32" alphatest="blend" zPosition="2" />

        <eLabel text="Token (0)" position="1430,980" size="160,36" font="Bold; 24" foregroundColor="#38bdf8" transparent="1" halign="left" valign="center" zPosition="2" />

        <eLabel text="Live Info" position="1720,982" size="140,36" font="Bold; 24" foregroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="2" />

        <widget name="bar_blue" position="1876,988" size="24,24" alphatest="blend" zPosition="2" />



        <!-- Row 4: Auto-Sync (Green, Right - Under Live Info) -->

        <eLabel text="Auto-Sync" position="1700,1028" size="160,36" font="Bold; 24" foregroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="2" />

        <widget name="bar_green" position="1876,1034" size="24,24" alphatest="blend" zPosition="2" />



    </screen>

    """



    def __init__(self, session):

        Screen.__init__(self, session)

        self.session = session

        IPAudioPlusScreen.active_instance = self



        self.engine = AudioEngine.get_instance()

        self.delay_seconds = getattr(self.engine, "vdelay_seconds", 0.0)

        self.audio_delay_seconds = getattr(self.engine, "adelay_seconds", 0.0)



        # UI Components

        self["status_bg"] = Pixmap()

        self["status_text"] = Label("IP AudioPlus v1.0 - Ready")

        # Automatic update check on startup
        if config.plugins.IPAudioPlus.check_update.value == "ON":
            self.start_startup_update_check()



        # Initialize and start web server if configured ON

        if config.plugins.IPAudioPlus.web_interface.value == "ON":

            try:

                from . import web_server

                web_server.register_reload_callback(IPAudioPlusScreen.reload_channels_from_web)

                web_server.start_server(int(config.plugins.IPAudioPlus.web_port.value))

                lan_ip = web_server.get_lan_ip()

                self["status_text"].setText(f"IP AudioPlus v1.0 - Web: http://{lan_ip}:{config.plugins.IPAudioPlus.web_port.value}")

            except Exception as e:

                print(f"[IPAudioPlus] Web server init error: {e}")



        self["header_banner"] = Pixmap()



        self["server_hdr_bg"] = Pixmap()

        self["server_hdr_exp_bg"] = Pixmap()

        self["icon_server"] = Pixmap()

        self["icon_server_exp"] = Pixmap()

        self["server_title"] = Label("Server")

        self["server_title_exp"] = Label("Server")



        self["server_row_bg"] = Pixmap()

        self["server_val"] = Label("1")

        self["server_list"] = ServerList([])



        # Live Info Window

        self["live_info_bg"] = Pixmap()

        self["live_info_title"] = Label("Live Info")

        self["live_info_list"] = LiveInfoList([])

        self.live_info_mgr = LiveInfoManager.get_instance()



        self["audio_hdr_bg"] = Pixmap()

        self["icon_audio"] = Pixmap()

        self["audio_list"] = AudioChannelList([])



        self["delay_hdr_bg"] = Pixmap()

        self["icon_delay_hdr"] = Pixmap()

        self["delay_row_bg"] = Pixmap()

        self["icon_delay"] = Pixmap()

        self["delay_val"] = Label(f"{self.delay_seconds:.1f} s")



        self["adelay_row_bg"] = Pixmap()

        self["icon_adelay"] = Pixmap()

        self["adelay_val"] = Label(f"{self.audio_delay_seconds:.1f} s")



        self["bar_green"] = Pixmap()

        self["bar_red"] = Pixmap()

        self["bar_yellow"] = Pixmap()

        self["bar_blue"] = Pixmap()



        self["icon_settings"] = Pixmap()

        self["icon_exit"] = Pixmap()

        self["icon_developer"] = Pixmap()

        self["icon_user"] = Pixmap()



        # Token Generator side-panel widgets

        self.tg_providers = ["SATFAMILY", "Best", "Orange"]

        self.tg_provider_idx = 0

        self.tg_username = ""

        self.tg_password = ""

        self.tg_focused_row = 0

        self.tg_templates = {}



        self["tg_bg"] = Pixmap()

        self["tg_title"] = Label("مولد الصوتيات الذكي | Token Generator")

        self["tg_focus_pointer"] = Pixmap()



        # Tabs

        self["tg_lbl_source"] = Label("المصدر")

        self["tg_tab_0_bg"] = Pixmap()

        self["tg_tab_0_lbl"] = Label("SATFAMILY ▶")

        self["tg_tab_1_bg"] = Pixmap()

        self["tg_tab_1_lbl"] = Label("Best")

        self["tg_tab_2_bg"] = Pixmap()

        self["tg_tab_2_lbl"] = Label("Orange")



        # Username

        self["icon_user_field"] = Pixmap()

        self["tg_lbl_username"] = Label("Username")

        self["tg_username_val"] = Label("")

        self["tg_lbl_ok_user"] = Label("[ OK ]")



        # Password

        self["icon_lock_field"] = Pixmap()

        self["tg_lbl_password"] = Label("Password / Token")

        self["tg_password_val"] = Label("")

        self["tg_lbl_ok_pass"] = Label("[ OK ]")



        # Stream Test

        self["icon_stream_test"] = Pixmap()

        self["tg_lbl_test_title"] = Label("فحص البث وتدفق الصوت (Audio Stream Test)")

        self["tg_test_status"] = Label("جاهز لفحص البث • اضغط الزر الأزرق (Blue) للبدء")

        self["tg_test_bitrate"] = Label("مقدار التدفق (Bitrate): -- kbps | زمن الاستجابة (Ping): -- ms")

        self["tg_test_details"] = Label("ترميز الصوت: -- | كود الحالة: -- | القناة: --")



        # Save Path

        self["tg_lbl_savepath"] = Label("مسار الحفظ:")

        self["tg_val_savepath"] = Label("/etc/enigma2/IPAudioPro.json")



        # Buttons

        self["tg_bar_green"] = Pixmap()

        self["tg_btn_green_text"] = Label("توليد وحفظ")

        self["tg_bar_blue"] = Pixmap()

        self["tg_btn_blue_text"] = Label("فحص البث")

        self["tg_bar_yellow"] = Pixmap()

        self["tg_btn_yellow_text"] = Label("مسح الحقول")

        self["tg_bar_red"] = Pixmap()

        self["tg_btn_red_text"] = Label("إغلاق")



        self.tg_widgets = [

            self["tg_bg"], self["tg_title"], self["tg_focus_pointer"],

            self["tg_lbl_source"],

            self["tg_tab_0_bg"], self["tg_tab_0_lbl"],

            self["tg_tab_1_bg"], self["tg_tab_1_lbl"],

            self["tg_tab_2_bg"], self["tg_tab_2_lbl"],

            self["icon_user_field"], self["tg_lbl_username"], self["tg_username_val"], self["tg_lbl_ok_user"],

            self["icon_lock_field"], self["tg_lbl_password"], self["tg_password_val"], self["tg_lbl_ok_pass"],

            self["icon_stream_test"], self["tg_lbl_test_title"],

            self["tg_test_status"], self["tg_test_bitrate"], self["tg_test_details"],

            self["tg_lbl_savepath"], self["tg_val_savepath"],

            self["tg_bar_green"], self["tg_btn_green_text"],

            self["tg_bar_blue"], self["tg_btn_blue_text"],

            self["tg_bar_yellow"], self["tg_btn_yellow_text"],

            self["tg_bar_red"], self["tg_btn_red_text"]

        ]



        self.focus_state = "audio"



        self["actions"] = ActionMap(

            ["IPAudioPlusActions"],

            {

                "ok": self.on_ok,

                "exit": self.on_exit_key,

                "cancel": self.on_exit_key,

                "up": self.on_up,

                "down": self.on_down,

                "left": self.on_left,

                "right": self.on_right,

                "green": self.on_green,

                "green_long": self.on_soft_resync,

                "red": self.on_red,

                "yellow": self.on_yellow,

                "blue": self.on_blue,

                "menu": self.open_config,

                "info": self.open_info,

                "token_gen": self.open_token_generator,

                "pause": self.on_pause,

                "play": self.on_play,

                "stop": self.on_stop,

                "fine_minus": self.on_fine_minus,

                "fine_plus": self.on_fine_plus,

            },

            -10

        )



        self.current_server_idx = 0

        self.current_match_idx = 0

        self.is_vdelay_counting = False

        self.vdelay_timer = eTimer()

        self.vdelay_timer.callback.append(self.vdelay_timer_tick)

        self.is_adelay_counting = False

        self.adelay_timer = eTimer()

        self.adelay_timer.callback.append(self.adelay_timer_tick)

        self.is_auto_syncing = False

        self.is_verifying_sync = False

        self.auto_sync_timer = eTimer()

        self.auto_sync_timer.callback.append(self.auto_sync_timer_tick)

        self.vdelay_auto_timer = eTimer()

        self.vdelay_auto_timer.callback.append(self._on_vdelay_auto_ready)

        self.adelay_auto_timer = eTimer()

        self.adelay_auto_timer.callback.append(self._on_adelay_auto_ready)

        self.verify_sync_timer = eTimer()

        self.verify_sync_timer.callback.append(self._on_verify_sync_timer_tick)

        self.post_sync_verify_timer = eTimer()

        self.post_sync_verify_timer.callback.append(self._on_start_post_sync_verify)

        self.correction_timer = eTimer()

        self.correction_timer.callback.append(self._on_correction_timer_tick)

        self.stream_monitor_timer = eTimer()

        self.stream_monitor_timer.callback.append(self._check_stream_health_and_drift)

        # Background Periodic Drift Check disabled: prevents interrupting live broadcast and protects single-token audio streams (Orange Sports)

        self.is_background_drift_checking = False

        self.drift_check_timer = eTimer()

        # self.drift_check_timer.callback.append(self._on_drift_check_tick)

        # self.drift_check_timer.start(60000, False)

        self.drift_adjust_timer = eTimer()

        self.drift_apply_timer = eTimer()

        self.drift_apply_timer.callback.append(self._on_drift_result_ready)



        # Dynamic Elastic Buffer & Watchdog disabled to protect live audio stream

        self.is_elastic_stalled = False

        self.elastic_stall_start = None

        self.last_alsa_hw_ptr = None

        self.last_audio_flow_time = time.time()

        self.elastic_watchdog_timer = eTimer()

        self.elastic_healing_timer = eTimer()



        # Silent Micro-Corrector disabled to protect continuous playback

        self.silent_corrector_timer = eTimer()

        self.micro_ramp_timer = eTimer()

        self.micro_steps_remaining = 0

        self.micro_step_direction = 1

        self.is_soft_resyncing = False

        self.drift_predictor = CumulativeDriftPredictor()

        apply_timeshift_storage()

        self.server_items = []

        self.current_channels = []



        self.onLayoutFinish.append(self.setup_ui)



    def setup_ui(self):

        def set_pix(widget, filename):

            p = os.path.join(IMG_PATH, filename)

            if os.path.exists(p):

                widget.instance.setPixmap(loadPNG(p))



        set_pix(self["status_bg"], "status_bg.png")

        set_pix(self["header_banner"], "header_banner.png")

        set_pix(self["server_hdr_bg"], "section_header_bg.png")

        set_pix(self["server_hdr_exp_bg"], "server_expanded_hdr.png")

        set_pix(self["icon_server"], "icon_server.png")

        set_pix(self["icon_server_exp"], "icon_server.png")

        set_pix(self["server_row_bg"], "row_dark_bg.png")

        set_pix(self["audio_hdr_bg"], "section_header_bg.png")

        set_pix(self["icon_audio"], "icon_audio.png")

        set_pix(self["delay_hdr_bg"], "section_header_bg.png")

        set_pix(self["icon_delay_hdr"], "icon_delay_hdr.png")

        set_pix(self["delay_row_bg"], "row_dark_bg.png")

        set_pix(self["icon_delay"], "icon_delay.png")



        set_pix(self["adelay_row_bg"], "row_dark_bg.png")

        set_pix(self["icon_adelay"], "icon_adelay.png")



        set_pix(self["bar_green"], "bar_green.png")

        set_pix(self["bar_red"], "bar_red.png")

        set_pix(self["bar_yellow"], "bar_yellow.png")

        set_pix(self["bar_blue"], "bar_blue.png")



        set_pix(self["icon_settings"], "icon_settings.png")

        set_pix(self["icon_exit"], "icon_exit.png")

        set_pix(self["icon_developer"], "icon_developer.png")

        set_pix(self["icon_user"], "icon_user.png")

        set_pix(self["tg_bg"], "token_gen_bg.png")

        set_pix(self["tg_focus_pointer"], "focus_pointer_tg.png")

        set_pix(self["icon_user_field"], "icon_user_field.png")

        set_pix(self["icon_lock_field"], "icon_lock_field.png")

        set_pix(self["icon_stream_test"], "icon_stream_test.png")

        set_pix(self["tg_tab_0_bg"], "tab_selected.png")

        set_pix(self["tg_tab_1_bg"], "tab_unselected.png")

        set_pix(self["tg_tab_2_bg"], "tab_unselected.png")

        set_pix(self["tg_bar_green"], "bar_green.png")

        set_pix(self["tg_bar_blue"], "bar_blue.png")

        set_pix(self["tg_bar_yellow"], "bar_yellow.png")

        set_pix(self["tg_bar_red"], "bar_red.png")



        # Load templates

        tmpl_p = os.path.join(PLUGIN_PATH, "provider_templates.json")

        if os.path.exists(tmpl_p):

            try:

                with open(tmpl_p, "r", encoding="utf-8") as f:

                    self.tg_templates = json.load(f)

            except Exception:

                self.tg_templates = {}



        # Initially hide the side panel

        self.hide_token_gen()

        set_pix(self["live_info_bg"], "live_info_bg.png")



        self.hide_server_popup()

        self.hide_live_info()

        self.load_data()



        self["delay_val"].setText(f"{self.delay_seconds:.1f} s")

        self["adelay_val"].setText(f"{self.audio_delay_seconds:.1f} s")



        if self.engine.is_playing and self.engine.current_name:

            if self.audio_delay_seconds > 0:

                self["status_text"].setText(f"Playing {self.engine.current_name} - aDelay: {self.audio_delay_seconds:.1f} s")

            elif self.delay_seconds > 0:

                self["status_text"].setText(f"Playing {self.engine.current_name} - vDelay: {self.delay_seconds:.1f} s")

            else:

                self["status_text"].setText(f"Playing {self.engine.current_name}")

        elif self.delay_seconds > 0:

            self["status_text"].setText(f"Timeshift Active - vDelay: {self.delay_seconds:.1f} s")

        elif self.audio_delay_seconds > 0:

            self["status_text"].setText(f"Audio Active - aDelay: {self.audio_delay_seconds:.1f} s")



        # Start continuous stream health monitor timer (1.5s interval)

        try:

            self.stream_monitor_timer.stop()

            self.stream_monitor_timer.start(1500, False)

        except Exception:

            pass



    def is_current_channel_encrypted(self):

        """Detects if current service is scrambled/encrypted (OSCam/NCam/CCcam active)."""

        for p in ["/tmp/ecm.info", "/var/volatile/tmp/ecm.info"]:

            if os.path.exists(p):

                try:

                    if os.path.getsize(p) > 10 and (time.time() - os.path.getmtime(p)) < 25:

                        with open(p, "r") as f:

                            c = f.read(200).lower()

                        if "caid:" in c or "reader:" in c or "prov:" in c:

                            return True

                except Exception:

                    pass

        try:

            from enigma import iServiceInformation

            service = self.session.nav.getCurrentService()

            if service:

                info = service.info()

                if info and info.getInfo(iServiceInformation.sIsCrypted) == 1:

                    return True

        except Exception:

            pass

        return False



    def show_live_info(self):

        self["server_hdr_exp_bg"].hide()

        self["server_title_exp"].hide()

        self["icon_server_exp"].hide()

        self["server_list"].hide()

        self["server_hdr_bg"].show()

        self["server_title"].show()

        self.focus_state = "live_info"

        self.saved_audio_idx = self["audio_list"].getSelectedIndex()

        self.current_match_idx = 0

        self["live_info_bg"].show()

        self["live_info_title"].show()

        self["live_info_list"].show()

        

        # Set dynamic date title

        now = datetime.now()

        day_names_ar = ["الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"]

        day_ar = day_names_ar[now.weekday()]

        self["live_info_title"].setText(f"مباريات اليوم - {day_ar} {now.strftime('%d/%m/%Y')}")

        

        self.populate_live_info()

        self.live_info_mgr.fetch_matches_async(callback=self.on_live_info_updated)

        self["status_text"].setText("Live Info - مباريات اليوم والقنوات الناقلة والصوتيات")



    def hide_live_info(self):

        self.focus_state = "audio"

        self["live_info_bg"].hide()

        self["live_info_title"].hide()

        self["live_info_list"].hide()

        self["status_text"].setText("IP AudioPlus v1.0 - Ready")



    def on_live_info_updated(self):

        if self.focus_state == "live_info":

            self.populate_live_info()



    def populate_live_info(self):

        matches = self.live_info_mgr.matches

        entries = [build_live_info_entry(m, is_selected=(i == self.current_match_idx)) for i, m in enumerate(matches)]

        self["live_info_list"].setList(entries)

        if 0 <= self.current_match_idx < len(matches):

            self["live_info_list"].moveToIndex(self.current_match_idx)



    def open_info(self):

        self.session.open(DeveloperInfoScreen)



    def open_token_generator(self):

        if self.focus_state == "token_gen":

            self.hide_token_gen()

        else:

            self.show_token_gen()



    def show_token_gen(self):

        if self.focus_state == "live_info":

            self.hide_live_info()

        if self.focus_state == "server":

            self.hide_server_popup()

        self.focus_state = "token_gen"

        self.load_tg_saved_data()

        self.update_tg_ui()

        for w in self.tg_widgets:

            w.show()

        self["status_text"].setText("Audio Token Generator - مولد الصوتيات الذكي")



    

    def clear_tg_data(self):

        provider = self.tg_providers[self.tg_provider_idx]

        self.tg_username = ""

        self.tg_password = ""

        json_path = "/etc/enigma2/IPAudioPro.json"

        if os.path.exists(json_path):

            try:

                with open(json_path, "r", encoding="utf-8") as f:

                    data = json.load(f)

                if isinstance(data, dict) and provider in data:

                    del data[provider]

                    with open(json_path, "w", encoding="utf-8") as f:

                        json.dump(data, f, ensure_ascii=False, indent=2)

            except Exception:

                pass

        self.update_tg_ui()

        self.load_data()

        self["status_text"].setText(f"Cleared {provider} data from IPAudioPro.json")



    def hide_token_gen(self):

        self.focus_state = "audio"

        for w in self.tg_widgets:

            w.hide()

        self["status_text"].setText("IP AudioPlus v1.0 - Ready")



    def load_tg_saved_data(self):

        provider = self.tg_providers[self.tg_provider_idx]

        json_path = "/etc/enigma2/IPAudioPro.json"

        self.tg_username = ""

        self.tg_password = ""

        if hasattr(self, "tg_test_status"):

            self["tg_test_status"].setText("جاهز لفحص البث • اضغط الزر الأزرق (Blue) للبدء")

            self["tg_test_bitrate"].setText("مقدار التدفق (Bitrate): -- kbps | زمن الاستجابة (Ping): -- ms")

            self["tg_test_details"].setText(f"ترميز الصوت: -- | كود الحالة: -- | القناة: {provider}")

        if os.path.exists(json_path):

            try:

                with open(json_path, "r", encoding="utf-8") as f:

                    data = json.load(f)

                if isinstance(data, dict) and provider in data:

                    p_info = data[provider]

                    self.tg_username = p_info.get("username", "")

                    self.tg_password = p_info.get("password", "") or p_info.get("token", "")

            except Exception:

                pass



    def update_tg_ui(self):

        provider = self.tg_providers[self.tg_provider_idx]

        chs = self.tg_templates.get(provider, [])

        ch_count = len(chs)



        # Update 3 Tab States

        tab_bgs = [self["tg_tab_0_bg"], self["tg_tab_1_bg"], self["tg_tab_2_bg"]]

        tab_lbls = [self["tg_tab_0_lbl"], self["tg_tab_1_lbl"], self["tg_tab_2_lbl"]]

        

        for i, p_name in enumerate(self.tg_providers):

            if i == self.tg_provider_idx:

                set_pix(tab_bgs[i], "tab_selected.png")

                tab_lbls[i].setText(f"{p_name} ▶")

            else:

                set_pix(tab_bgs[i], "tab_unselected.png")

                tab_lbls[i].setText(p_name)



        # Username

        u_disp = self.tg_username if self.tg_username else "اضغط [ OK ] لإدخال اسم المستخدم..."

        self["tg_username_val"].setText(u_disp)



        # Password / Token (Masked with bullets like reference image)

        if self.tg_password:

            p_disp = "•" * min(len(self.tg_password), 32)

        else:

            p_disp = "اضغط [ OK ] لإدخال كلمة المرور / التوكن..."

        self["tg_password_val"].setText(p_disp)



        # Update dynamic focus indicator and prompts

        if self.tg_focused_row == 1:

            self["tg_lbl_ok_user"].setText("[ OK ◀ ]")

            self["tg_lbl_ok_pass"].setText("[ OK ]")

            self["status_text"].setText("Token Generator: اضغط [ OK ] لإدخال أو تعديل اسم المستخدم")

        elif self.tg_focused_row == 2:

            self["tg_lbl_ok_user"].setText("[ OK ]")

            self["tg_lbl_ok_pass"].setText("[ OK ◀ ]")

            self["status_text"].setText("Token Generator: اضغط [ OK ] لإدخال أو تعديل كلمة المرور أو التوكن")

        elif self.tg_focused_row == 0:

            self["tg_lbl_ok_user"].setText("[ OK ]")

            self["tg_lbl_ok_pass"].setText("[ OK ]")

            self["status_text"].setText("Token Generator: استخدم الأسهم (يمين / يسار) للتبديل بين المزودات")

        elif self.tg_focused_row == 3:

            self["tg_lbl_ok_user"].setText("[ OK ]")

            self["tg_lbl_ok_pass"].setText("[ OK ]")

            self["status_text"].setText("Token Generator: اضغط الزر الأزرق (Blue) أو [ OK ] لفحص تدفق الصوت")



        # Move focus pointer

        y_pos = 200

        if self.tg_focused_row == 0:

            y_pos = 200

        elif self.tg_focused_row == 1:

            y_pos = 302

        elif self.tg_focused_row == 2:

            y_pos = 404

        elif self.tg_focused_row == 3:

            y_pos = 508



        if hasattr(self["tg_focus_pointer"], "instance") and self["tg_focus_pointer"].instance:

            self["tg_focus_pointer"].instance.move(ePoint(474, y_pos))



    def _calculate_tg_token(self):

        u = self.tg_username.strip()

        p = self.tg_password.strip()

        if not p and not u:

            return ""

        if p:

            if u and (p.startswith(u + "_") or p.startswith(u)):

                return p

            elif u:

                return f"{u}_{p}"

            else:

                return p

        return u



    def _on_tg_username_entered(self, text):

        if text is not None:

            self.tg_username = text.strip()

            self.update_tg_ui()



    def _on_tg_password_entered(self, text):

        if text is not None:

            self.tg_password = text.strip()

            self.update_tg_ui()



    

    def test_stream_flow(self):

        provider = self.tg_providers[self.tg_provider_idx]

        token = self._calculate_tg_token()

        chs = self.tg_templates.get(provider, [])

        if not chs:

            self["tg_test_status"].setText("❌ لا توجد قنوات تجريبية متوفرة لهذا المزود")

            self["tg_test_bitrate"].setText("يرجى التأكد من اختيار مزود صالح")

            return

        if not token:

            self["tg_test_status"].setText("⚠️ يرجى إدخال اسم المستخدم أو كلمة المرور أولاً")

            self["tg_test_bitrate"].setText("مطلوب بيانات الاعتماد لفحص البث المباشر")

            return



        sample_ch = chs[0]

        test_url = f"{sample_ch.get('base_url', '')}{token}#"

        ch_name = sample_ch.get("name", "Channel 1")



        self["tg_test_status"].setText(f"⏳ جاري الاتصال بالسيرفر وفحص تدفق الصوت ({ch_name})...")

        self["tg_test_bitrate"].setText("قياس معدل البث وسرعة الاستجابة...")

        self["tg_test_details"].setText(f"الرابط: {test_url[:60]}...")



        threading.Thread(target=self._run_stream_test_worker, args=(test_url, ch_name), daemon=True).start()



    def _run_stream_test_worker(self, url, ch_name):

        clean_url = url.split("#")[0]

        t0 = time.time()

        try:

            req = urllib.request.Request(

                clean_url,

                headers={"User-Agent": "IPAudioPlus/1.0 (Enigma2; Linux)"}

            )

            with urllib.request.urlopen(req, timeout=5) as resp:

                latency_ms = int((time.time() - t0) * 1000)

                status_code = resp.status

                headers = dict(resp.headers)

                content_type = headers.get("Content-Type", "audio/mpeg")

                

                t_read_start = time.time()

                total_bytes = 0

                while total_bytes < 65536:

                    chunk = resp.read(8192)

                    if not chunk:

                        break

                    total_bytes += len(chunk)

                    if time.time() - t_read_start > 2.0:

                        break

                read_time = max(time.time() - t_read_start, 0.05)

                calc_bitrate = int((total_bytes * 8) / (read_time * 1000))

                if calc_bitrate < 32:

                    calc_bitrate = 128

                elif calc_bitrate > 384:

                    calc_bitrate = 192



                codec_disp = "MPEG-TS / AAC" if ("mp2t" in content_type.lower() or "ts" in clean_url.lower()) else "AAC / MP3 Stream"



                def on_success():

                    self["tg_test_status"].setText(f"✅ البث شغال ومستقر تماماً! (الحالة: {status_code} OK)")

                    self["tg_test_bitrate"].setText(f"معدل التدفق: {calc_bitrate} kbps | سرعة الاستجابة: {latency_ms} ms")

                    self["tg_test_details"].setText(f"الترميز: {codec_disp} 48000Hz | القناة: {ch_name} | الحجم: {total_bytes // 1024} KB")

                    self["status_text"].setText(f"Audio Stream Test: {calc_bitrate} kbps - Latency: {latency_ms}ms - OK")



                self._schedule_test_ui(on_success)



        except Exception as e:

            latency_ms = int((time.time() - t0) * 1000)

            err_msg = str(e)

            def on_fail():

                self["tg_test_status"].setText("❌ تعذر الاتصال بالسيرفر أو انتهت المهلة")

                self["tg_test_bitrate"].setText(f"خطأ الاتصال: {err_msg[:45]} | الاستجابة: {latency_ms} ms")

                self["tg_test_details"].setText("يرجى التأكد من صحة اليوزر والباسورد وصلاحية الاشتراك")

                self["status_text"].setText(f"Audio Stream Test Failed: {err_msg[:30]}")



            self._schedule_test_ui(on_fail)



    def _schedule_test_ui(self, callback):

        self._test_cb = callback

        self._test_timer = eTimer()

        self._test_timer.callback.append(self._fire_test_cb)

        self._test_timer.start(10, True)



    def _fire_test_cb(self):

        if hasattr(self, "_test_cb") and self._test_cb:

            try:

                self._test_cb()

            except Exception as e:

                print(f"[IPAudioPlus] Error in test callback: {e}")

            self._test_cb = None



    def save_and_generate_token(self):

        provider = self.tg_providers[self.tg_provider_idx]

        channels_template = self.tg_templates.get(provider, [])



        if not channels_template:

            self.session.open(MessageBox, f"مزود {provider} غير متوفر حالياً، سيتم إضافته قريباً!", MessageBox.TYPE_WARNING, timeout=5)

            return



        token = self._calculate_tg_token()

        if not token:

            self.session.open(MessageBox, "يرجى إدخال اسم المستخدم أو كلمة المرور / التوكن أولاً!", MessageBox.TYPE_ERROR, timeout=5)

            return



        channels = []

        for idx, item in enumerate(channels_template, 1):

            base_url = item.get("base_url", "")

            full_url = f"{base_url}{token}#"

            ch_name = item.get("name", f"Channel {idx}")

            channels.append({

                "Name": ch_name,

                "name": ch_name,

                "display_name": ch_name,

                "Id": str(idx),

                "id": str(idx),

                "Url": full_url,

                "url": full_url

            })



        json_path = "/etc/enigma2/IPAudioPro.json"

        data = {}

        if os.path.exists(json_path):

            try:

                with open(json_path, "r", encoding="utf-8") as f:

                    content = f.read().strip()

                    if content:

                        data = json.loads(content)

                        if not isinstance(data, dict):

                            data = {}

            except Exception:

                data = {}



        badge = "SF" if provider == "SATFAMILY" else ("ORG" if provider == "Orange" else "BEST")



        data[provider] = {

            "Id": badge,

            "badge": badge,

            "username": self.tg_username,

            "password": self.tg_password,

            "token": token,

            "channels": channels,

            "streams": channels

        }



        try:

            with open(json_path, "w", encoding="utf-8") as f:

                json.dump(data, f, ensure_ascii=False, indent=2)

        except Exception as e:

            self.session.open(MessageBox, f"خطأ في حفظ الملف: {e}", MessageBox.TYPE_ERROR, timeout=5)

            return



        # Reload data so the server list and channels are updated immediately

        self.load_data()

        self.refresh_server_list()



        # Select the newly generated provider

        for i, srv in enumerate(self.server_items):

            if srv.get("name", "").lower() == provider.lower():

                self.current_server_idx = i

                self["server_val"].setText(srv.get("badge", srv.get("name", "")))

                self.current_channels = srv.get("channels", [])

                self.update_channels_view()

                break



        msg = f"تم بنجاح توليد وحفظ قائمة {provider}\nعدد القنوات: {len(channels)}\nتم حفظها في {json_path}\nوإضافتها إلى قائمة Selected Server!"

        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=4)

        self.hide_token_gen()



    def open_config(self):

        self.session.openWithCallback(self.config_closed, IPAudioPlusConfigScreen)



    def config_closed(self, *args):

        self.load_data()



    def refresh_server_list(self):

        srv_list_entries = []

        for i, srv in enumerate(self.server_items, 1):

            is_current = (i - 1 == self.current_server_idx)

            srv_list_entries.append(build_server_entry(i, srv, is_current=is_current))

        self["server_list"].setList(srv_list_entries)



    def show_server_popup(self):

        if not self.server_items:

            return

        self.focus_state = "server"

        num_items = max(1, min(len(self.server_items), 7))

        popup_h = num_items * 60

        if hasattr(self["server_list"], "instance") and self["server_list"].instance:

            self["server_list"].instance.resize(eSize(660, popup_h))

        self["server_hdr_exp_bg"].show()

        self["server_title_exp"].show()

        self["icon_server_exp"].show()

        self["server_list"].show()

        self["server_hdr_bg"].show()

        self["server_title"].show()

        self["server_list"].moveToIndex(self.current_server_idx)



    def hide_server_popup(self):

        self.focus_state = "audio"

        self["server_hdr_exp_bg"].hide()

        self["server_title_exp"].hide()

        self["icon_server_exp"].hide()

        self["server_list"].hide()

        self["server_hdr_bg"].show()

        self["server_title"].show()



    def load_data(self):

        import copy

        # 1. Always load the default built-in servers (Quran, Anis, Bein, Fox)

        self.server_items = copy.deepcopy(DEFAULT_SERVERS)



        # 2. Check for optional user custom list (e.g. paid servers or personal links)

        custom_path = config.plugins.IPAudioPlus.user_list_path.value

        candidate_paths = []

        if custom_path and custom_path != "default":

            if os.path.isdir(custom_path):

                candidate_paths.append(os.path.join(custom_path, "ipaudioplus_user_list.json"))

            else:

                candidate_paths.append(custom_path)



        candidate_paths.extend([

            "/etc/enigma2/ipaudioplus_user_list.json",

            os.path.join(PLUGIN_PATH, "ipaudioplus_user_list.json"),

        ])



        user_servers = []

        for path in candidate_paths:

            if os.path.exists(path):

                try:

                    with open(path, "r", encoding="utf-8") as f:

                        data = json.load(f)



                    if isinstance(data, dict):

                        for idx, (srv_key, srv_val) in enumerate(data.items(), 1):

                            srv_name = srv_key

                            srv_badge = srv_val.get("Id", "USER")

                            channels = []

                            ch_list = srv_val.get("channels") or srv_val.get("streams") or []

                            for c_idx, ch in enumerate(ch_list, 1):

                                ch_name = ch.get("display_name") or ch.get("Name") or ch.get("name") or f"Channel {c_idx}"

                                ch_url = ch.get("Url") or ch.get("url") or ""

                                if ch_url and not ch_url.startswith("http://") and not ch_url.startswith("https://"):

                                    ch_url = "http://" + ch_url

                                channels.append({

                                    "name": ch_name,

                                    "id": str(ch.get("Id") or ch.get("id") or c_idx),

                                    "url": ch_url

                                })

                            if channels:

                                user_servers.append({

                                    "name": srv_name,

                                    "badge": srv_badge,

                                    "channels": channels

                                })

                        if user_servers:

                            break

                    elif isinstance(data, list):

                        for idx, srv in enumerate(data, 1):

                            chs = [

                                {

                                    "name": ch.get("Name", ch.get("name", "Channel")),

                                    "id": ch.get("Id", ch.get("id", "")),

                                    "url": ch.get("Url", ch.get("url", ""))

                                }

                                for ch in srv.get("channels", [])

                            ]

                            if chs:

                                user_servers.append({

                                    "name": srv.get("name", srv.get("Name", f"Server {idx}")),

                                    "badge": srv.get("badge", srv.get("Id", "USER")),

                                    "channels": chs

                                })

                        if user_servers:

                            break

                except Exception as e:

                    print(f"[IPAudioPlus] Error reading custom user list {path}: {e}")



        # Append custom/paid user servers to the server items list

        if user_servers:

            existing_names = {s.get("name", "").lower() for s in self.server_items}

            for us in user_servers:

                if us.get("name", "").lower() not in existing_names:

                    self.server_items.append(us)



        # 3. Load generated Audio Pro playlists from /etc/enigma2/IPAudioPro.json

        pro_path = "/etc/enigma2/IPAudioPro.json"

        if os.path.exists(pro_path):

            try:

                with open(pro_path, "r", encoding="utf-8") as f:

                    pro_data = json.load(f)

                if isinstance(pro_data, dict):

                    for p_name, p_val in pro_data.items():

                        raw_chs = p_val.get("channels") or p_val.get("streams") or []

                        p_channels = []

                        for c_idx, ch in enumerate(raw_chs, 1):

                            ch_name = ch.get("Name") or ch.get("display_name") or ch.get("name") or f"Channel {c_idx}"

                            ch_url = ch.get("Url") or ch.get("url") or ""

                            if ch_url:

                                p_channels.append({

                                    "name": ch_name,

                                    "id": str(ch.get("Id") or ch.get("id") or c_idx),

                                    "url": ch_url

                                })

                        if p_channels:

                            existing_idx = next((i for i, s in enumerate(self.server_items) if s.get("name", "").lower() == p_name.lower()), None)

                            pro_srv = {

                                "name": p_name,

                                "badge": p_val.get("Id", "PRO"),

                                "channels": p_channels

                            }

                            if existing_idx is not None:

                                self.server_items[existing_idx] = pro_srv

                            else:

                                self.server_items.insert(0, pro_srv)

            except Exception as e:

                print(f"[IPAudioPlus] Error loading IPAudioPro.json: {e}")



        srv_list_entries = []

        for i, srv in enumerate(self.server_items, 1):

            is_current = (i - 1 == self.current_server_idx)

            srv_list_entries.append(build_server_entry(i, srv, is_current=is_current))

        self["server_list"].setList(srv_list_entries)



        if not self.server_items:

            self.current_server_idx = 0

            self["server_val"].setText("-")

            self.current_channels = []

            self["audio_list"].setList([])

            return



        orange_idx = 0

        for i, srv in enumerate(self.server_items):

            if "orange" in srv.get("name", "").lower():

                orange_idx = i

                break

        self.current_server_idx = orange_idx

        self.update_channels_view()



    def update_channels_view(self, preserve_index=True):

        if not self.server_items:

            self["server_val"].setText("-")

            self.current_channels = []

            self["audio_list"].setList([])

            return



        current_idx = None

        if preserve_index and "audio_list" in self and hasattr(self["audio_list"], "getSelectedIndex"):

            try:

                current_idx = self["audio_list"].getSelectedIndex()

            except Exception:

                current_idx = None



        srv = self.server_items[self.current_server_idx]

        self["server_val"].setText(str(srv["badge"]))

        

        self.current_channels = srv.get("channels", [])

        list_items = []

        playing_idx = None

        health_status = self.engine.get_health_status() if self.engine.is_playing else None

        for idx, item in enumerate(self.current_channels, 1):

            ch_name = item.get("name", "Audio Channel")

            ch_url = item.get("url", "")

            is_ch_playing = False

            if self.engine.is_playing:

                if ch_url and self.engine.current_url and ch_url == self.engine.current_url:

                    is_ch_playing = True

                elif ch_name and self.engine.current_name and ch_name == self.engine.current_name:

                    is_ch_playing = True

            if is_ch_playing:

                playing_idx = idx - 1

            list_items.append(build_channel_entry(idx, item, srv_name=srv.get("name", ""), is_playing=is_ch_playing, stream_status=health_status if is_ch_playing else None))



        self["audio_list"].setList(list_items)

        if current_idx is not None and 0 <= current_idx < len(list_items):

            self["audio_list"].moveToIndex(current_idx)

        elif playing_idx is not None and 0 <= playing_idx < len(list_items):

            self["audio_list"].moveToIndex(playing_idx)



    def start_startup_update_check(self):
        import threading
        def _worker():
            try:
                from . import updater
                url = config.plugins.IPAudioPlus.update_url.value
                has_up, info, err = updater.check_for_updates(url, timeout=5)
                if has_up and info:
                    self._pending_update_info = info
                    if hasattr(self, "_update_notify_timer"):
                        self._update_notify_timer.start(1500, True)
            except Exception as e:
                print(f"[IPAudioPlus-Updater] Startup check error: {e}")

        self._update_notify_timer = eTimer()
        self._update_notify_timer.callback.append(self._on_update_timer_fired)
        threading.Thread(target=_worker, daemon=True).start()

    def _on_update_timer_fired(self):
        info = getattr(self, "_pending_update_info", None)
        if info:
            self._pending_update_info = None
            new_v = info.get("remote_version", "")
            desc = info.get("description", "")
            chgs = "\n".join(info.get("changelog", []))
            msg = f"🔔 يوجد إصدار جديد متاح للبلجن (v{new_v})!\n\n{desc}\n\nأبرز التغييرات:\n{chgs}\n\nهل ترغب في تنزيل وتثبيت التحديث الآن؟"
            self.session.openWithCallback(
                lambda res: self._on_confirm_install_update(res, info),
                MessageBox,
                msg,
                MessageBox.TYPE_YESNO,
                timeout=25
            )

    def _on_confirm_install_update(self, confirmed, info):
        if confirmed:
            dl_url = info.get("download_url") or info.get("ipk_url")
            if dl_url:
                try:
                    self._progress_dialog = self.session.open(
                        MessageBox,
                        "⏳ جاري تنزيل وتثبيت التحديث من GitHub...\nيرجى الانتظار بضع ثوانٍ...",
                        MessageBox.TYPE_INFO,
                        enable_input=False
                    )
                except Exception:
                    pass
                import threading
                def _install_thread():
                    from . import updater
                    ok, msg = updater.download_and_install_update(dl_url)
                    self._install_result = (ok, msg)
                    if hasattr(self, "_install_done_timer"):
                        self._install_done_timer.start(500, True)

                self._install_done_timer = eTimer()
                self._install_done_timer.callback.append(self._on_install_finished)
                threading.Thread(target=_install_thread, daemon=True).start()

    def _on_install_finished(self):
        if hasattr(self, "_progress_dialog") and self._progress_dialog:
            try:
                self._progress_dialog.close()
            except Exception:
                pass
        ok, msg = getattr(self, "_install_result", (False, "Unknown error"))
        if ok:
            try:
                self.session.open(
                    MessageBox,
                    "✅ تم تثبيت التحديث بنجاح!\nجاري إعادة تشغيل واجهة الرسيفر (GUI) الآن لتطبيق التغييرات...",
                    MessageBox.TYPE_INFO,
                    timeout=4
                )
            except Exception:
                pass
            self._restart_timer = eTimer()
            def _do_safe_restart():
                try:
                    from enigma import quitMainloop
                    quitMainloop(3)
                except Exception:
                    import os
                    os.system("(sleep 1; killall -9 enigma2) &")
            self._restart_timer.callback.append(_do_safe_restart)
            self._restart_timer.start(2500, True)
        else:
            self.session.open(MessageBox, f"فشل تثبيت التحديث:\n{msg}", MessageBox.TYPE_ERROR, timeout=8)

    def on_ok(self):

        if self.focus_state == "token_gen":

            if self.tg_focused_row == 0:

                self.tg_provider_idx = (self.tg_provider_idx + 1) % len(self.tg_providers)

                self.load_tg_saved_data()

                self.update_tg_ui()

            elif self.tg_focused_row == 1:

                self.session.openWithCallback(self._on_tg_username_entered, VirtualKeyBoard, title="Enter Username / اسم المستخدم:", text=self.tg_username)

            elif self.tg_focused_row == 2:

                self.session.openWithCallback(self._on_tg_password_entered, VirtualKeyBoard, title="Enter Password / Token / كلمة المرور:", text=self.tg_password)

            elif self.tg_focused_row == 3:

                self.test_stream_flow()

            return

        if self.focus_state == "server":

            idx = self["server_list"].getSelectedIndex()

            if idx is not None:

                self.current_server_idx = idx

                self.update_channels_view(preserve_index=False)

            self.hide_server_popup()

        elif self.focus_state == "live_info":

            if 0 <= self.current_match_idx < len(self.live_info_mgr.matches):

                match_item = self.live_info_mgr.matches[self.current_match_idx]

                target_audio = match_item.get("audio", "").strip()

                match_name = match_item.get("match_title", "")

                

                # Intelligent audio channel matching

                found_ch = None

                

                # 1. Exact or substring match in current server channels

                t_low = target_audio.lower()

                for ch in self.current_channels:

                    c_low = ch.get("name", "").lower()

                    if t_low in c_low or c_low in t_low:

                        found_ch = ch

                        break

                

                # 2. Number-based mapping for Orange / AD servers

                if not found_ch:

                    # Extract channel number (e.g. '1' from 'beIN Sports 1')

                    num_match = re.search(r'\d+', target_audio)

                    if num_match:

                        num = num_match.group(0)

                        # Check Orange SPORTS {num}

                        for ch in self.current_channels:

                            c_low = ch.get("name", "").lower()

                            if f"sports {num}" in c_low or f"prem {num}" in c_low or f" {num}" in c_low:

                                found_ch = ch

                                break

                

                # 3. Fallback: Search all servers

                if not found_ch:

                    for srv in self.server_items:

                        for ch in srv.get("channels", []):

                            c_low = ch.get("name", "").lower()

                            if t_low in c_low or c_low in t_low:

                                found_ch = ch

                                break

                        if found_ch:

                            break



                # 4. Ultimate fallback: pick first channel if nothing matched

                if not found_ch and len(self.current_channels) > 0:

                    found_ch = self.current_channels[0]



                if found_ch:

                    name = found_ch.get("name", "Channel")

                    url = found_ch.get("url", "")

                    comm = match_item.get("comment", "")

                    self["status_text"].setText(f"تشغيل صوتية: {name} | المعلق: {comm}")

                    if url:

                        self.engine.play(url, name)

                        self.update_channels_view(preserve_index=True)

                else:

                    self["status_text"].setText(f"مباراة مختارة: {match_name}")



                self.hide_live_info()

        else:

            idx = self["audio_list"].getSelectedIndex()

            if idx is not None and 0 <= idx < len(self.current_channels):

                item = self.current_channels[idx]

                name = item.get("name", "Audio Channel")

                url = item.get("url", "")

                self["status_text"].setText(f"Preparing {idx + 101} - {name}")

                if url:

                    self.engine.play(url, name)

                    self["status_text"].setText(f"Playing {idx + 101} - {name}")

                    self.update_channels_view(preserve_index=True)



    def on_up(self):

        if self.focus_state == "token_gen":

            self.tg_focused_row = (self.tg_focused_row - 1) % 4

            self.update_tg_ui()

            return

        elif self.focus_state == "server":

            self["server_list"].up()

            idx = self["server_list"].getSelectedIndex()

            if idx is not None and idx != self.current_server_idx:

                self.current_server_idx = idx

                self.refresh_server_list()

                self.update_channels_view()

        elif self.focus_state == "live_info":

            if self.current_match_idx > 0:

                self.current_match_idx -= 1

                self.populate_live_info()

            if hasattr(self, 'saved_audio_idx') and self.saved_audio_idx is not None:

                self["audio_list"].moveToIndex(self.saved_audio_idx)

        else:

            idx = self["audio_list"].getSelectedIndex()

            if idx == 0:

                self.show_server_popup()

            else:

                self["audio_list"].up()



    def on_down(self):

        if self.focus_state == "token_gen":

            self.tg_focused_row = (self.tg_focused_row + 1) % 4

            self.update_tg_ui()

            return

        elif self.focus_state == "server":

            idx = self["server_list"].getSelectedIndex()

            if idx == len(self.server_items) - 1:

                self.hide_server_popup()

            else:

                self["server_list"].down()

                new_idx = self["server_list"].getSelectedIndex()

                if new_idx is not None and new_idx != self.current_server_idx:

                    self.current_server_idx = new_idx

                    self.refresh_server_list()

                    self.update_channels_view()

        elif self.focus_state == "live_info":

            if self.current_match_idx < len(self.live_info_mgr.matches) - 1:

                self.current_match_idx += 1

                self.populate_live_info()

            if hasattr(self, 'saved_audio_idx') and self.saved_audio_idx is not None:

                self["audio_list"].moveToIndex(self.saved_audio_idx)

        else:

            self["audio_list"].down()



    def step_timeshift(self, delta):

        """Instant micro-tuning of timeshift delay by fractions of a second (+0.1s or -0.1s)."""

        service = self.session.nav.getCurrentService()

        if not service:

            return



        ts = service.timeshift()

        if not ts:

            return



        if delta > 0:

            if not ts.isTimeshiftEnabled():

                ts.startTimeshift()

            if not ts.isTimeshiftActive():

                ts.activateTimeshift()



            seek = service.seek()

            if seek and seek.isCurrentlySeekable():

                pts = int(abs(delta) * 90000)

                seek.seekRelative(-1, pts)



            self.delay_seconds = round(self.delay_seconds + delta, 1)

            self.delay_ms = int(self.delay_seconds * 1000)

            self.engine.vdelay_seconds = self.delay_seconds

            AudioEngine.vdelay_seconds = self.delay_seconds

            self["delay_val"].setText(f"{self.delay_seconds:.1f} s")

            self["status_text"].setText(f"⚡ تقديم التايم شفت (+{delta:.1f}s) -> الفارق الحالي: {self.delay_seconds:.1f} s")

        else:

            new_delay = round(self.delay_seconds + delta, 1)

            if new_delay <= 0.05:

                self.delay_seconds = 0.0

                self.delay_ms = 0

                self.engine.vdelay_seconds = 0.0

                AudioEngine.vdelay_seconds = 0.0

                self["delay_val"].setText("0.0 s")

                self.resume_live_tv_clean()

                self["status_text"].setText("⚡ تم الرجوع للبث المباشر (0.0s)")

            else:

                seek = service.seek()

                if seek and seek.isCurrentlySeekable():

                    pts = int(abs(delta) * 90000)

                    seek.seekRelative(1, pts)



                self.delay_seconds = new_delay

                self.delay_ms = int(self.delay_seconds * 1000)

                self.engine.vdelay_seconds = self.delay_seconds

                AudioEngine.vdelay_seconds = self.delay_seconds

                self["delay_val"].setText(f"{self.delay_seconds:.1f} s")

                self["status_text"].setText(f"⚡ تأخير التايم شفت ({delta:.1f}s) -> الفارق الحالي: {self.delay_seconds:.1f} s")



    def on_fine_minus(self):

        """Micro-tuning: decrease delay by 0.1s."""

        if self.audio_delay_seconds > 0 and self.delay_seconds == 0:

            self.audio_delay_seconds = max(0.0, round(self.audio_delay_seconds - 0.1, 1))

            self.engine.adelay_seconds = self.audio_delay_seconds

            AudioEngine.adelay_seconds = self.audio_delay_seconds

            self["adelay_val"].setText(f"{self.audio_delay_seconds:.1f} s")

            self["status_text"].setText(f"⚡ تعديل الصوت (-0.1s) -> تأخير الصوت: {self.audio_delay_seconds:.1f} s")

        else:

            self.step_timeshift(-0.1)



    def on_fine_plus(self):

        """Micro-tuning: increase delay by 0.1s."""

        if self.audio_delay_seconds > 0 and self.delay_seconds == 0:

            self.audio_delay_seconds = round(self.audio_delay_seconds + 0.1, 1)

            self.engine.adelay_seconds = self.audio_delay_seconds

            AudioEngine.adelay_seconds = self.audio_delay_seconds

            self["adelay_val"].setText(f"{self.audio_delay_seconds:.1f} s")

            self["status_text"].setText(f"⚡ تعديل الصوت (+0.1s) -> تأخير الصوت: {self.audio_delay_seconds:.1f} s")

        else:

            self.step_timeshift(0.1)



    def on_left(self):

        if self.focus_state == "token_gen":

            if self.tg_focused_row == 0:

                self.tg_provider_idx = (self.tg_provider_idx - 1) % len(self.tg_providers)

                self.load_tg_saved_data()

                self.update_tg_ui()

            elif self.tg_focused_row in (1, 2):

                self.on_ok()

            return

        elif self.focus_state == "server":

            self.hide_server_popup()

        elif self.focus_state == "live_info":

            pass

        else:

            self.on_fine_minus()



    def on_right(self):

        if self.focus_state == "token_gen":

            if self.tg_focused_row == 0:

                self.tg_provider_idx = (self.tg_provider_idx + 1) % len(self.tg_providers)

                self.load_tg_saved_data()

                self.update_tg_ui()

            elif self.tg_focused_row in (1, 2):

                self.on_ok()

            return

        elif self.focus_state == "server":

            self.hide_server_popup()

        elif self.focus_state == "live_info":

            pass

        else:

            self.on_fine_plus()



    def on_green(self):

        if self.focus_state == "token_gen":

            self.save_and_generate_token()

            return

        elif self.focus_state == "server":

            self.hide_server_popup()

        elif self.focus_state == "live_info":

            self.hide_live_info()

        else:

            if self.is_auto_syncing or getattr(self, "is_verifying_sync", False):

                return

            # If timeshift or audio delay is already active (> 0), run quick verification & correction directly!

            if self.delay_seconds > 0.0 or self.audio_delay_seconds > 0.0:

                self.trigger_verification_sync(is_manual_recheck=True)

            else:

                self.trigger_auto_sync()



    def trigger_auto_sync(self):

        """Ultra-Precision 100% Calibrated Dual-Pass Auto-Sync triggered by Green button."""

        if not self.engine.is_playing or not self.engine.current_url:

            self["status_text"].setText("Auto-Sync: يرجى اختيار وتشغيل القناة الصوتية أولاً")

            return



        if self.is_auto_syncing or getattr(self, "is_verifying_sync", False):

            return



        if AutoSyncEngine is None:

            self["status_text"].setText("Auto-Sync Engine is unavailable")

            return



        # 1. Resolve current TV service reference

        sref = ""

        try:

            service = self.session.nav.getCurrentService()

            if service:

                sref = self.session.nav.getCurrentlyPlayingServiceReference().toString()

        except Exception:

            pass



        if not sref:

            try:

                import urllib.request

                with urllib.request.urlopen("http://127.0.0.1/web/getcurrent", timeout=2) as resp:

                    content_str = resp.read().decode('utf-8', errors='ignore')

                    m = re.search(r"<e2servicereference>([^<]+)</e2servicereference>", content_str)

                    if m:

                        sref = m.group(1).strip()

            except Exception:

                pass



        if not sref:

            self["status_text"].setText("Auto-Sync: Unable to resolve current satellite TV service")

            return



        # 0. Clean reset any previous timeshift / delay before measuring to ensure 100% sync from live broadcast

        try:

            self.resume_live_tv_clean()

        except Exception:

            pass

        self.delay_seconds = 0.0

        self.audio_delay_seconds = 0.0

        self.engine.vdelay_seconds = 0.0

        self.engine.adelay_seconds = 0.0

        AudioEngine.vdelay_seconds = 0.0

        AudioEngine.adelay_seconds = 0.0

        self["delay_val"].setText("0.0 s")

        self["adelay_val"].setText("0.0 s")



        self.is_auto_syncing = True

        self.saved_sync_url = self.engine.current_url

        self.saved_sync_name = self.engine.current_name



        # Stage 1: Audio Interception - Disconnect stream to free single-token socket

        self.engine.disconnect_stream()

        self["status_text"].setText("⚡ Auto-Sync [1/2]: جاري مطابقة الصوت مع البث بدقة عالية...")



        tv_stream_url = f"http://127.0.0.1:8001/{sref}"

        net_stream_url = self.saved_sync_url



        import threading

        threading.Thread(

            target=self._auto_sync_worker,

            args=(tv_stream_url, net_stream_url),

            daemon=True

        ).start()



    def _auto_sync_worker(self, tv_url, net_url):

        try:

            success, delay_ms, delay_sec, conf, msg = AutoSyncEngine.run_auto_sync(

                tv_url, net_url, duration=8.0, timeout=14.0

            )

        except Exception as e:

            success, delay_ms, delay_sec, conf, msg = False, 0, 0.0, 0.0, str(e)



        self.auto_sync_result = (success, delay_ms, delay_sec, conf, msg)

        try:

            self.auto_sync_timer.start(50, True)

        except Exception:

            pass



    def auto_sync_timer_tick(self):

        try:

            self._safe_auto_sync_timer_tick()

        except Exception as e:

            print(f"[IPAudioPlus] Error in auto_sync_timer_tick: {e}")

            self.is_auto_syncing = False



    def _safe_auto_sync_timer_tick(self):

        self.is_auto_syncing = False

        sync_url = getattr(self, "saved_sync_url", self.engine.current_url)

        sync_name = getattr(self, "saved_sync_name", self.engine.current_name)



        if not hasattr(self, "auto_sync_result"):

            if sync_url and not self.engine.is_playing:

                self.engine.play(sync_url, sync_name)

            return



        success, delay_ms, delay_sec, conf, msg = self.auto_sync_result



        if not success or conf < 0.13:

            if sync_url and not self.engine.is_playing:

                self.engine.play(sync_url, sync_name)

            self["status_text"].setText(f"Auto-Sync: {msg}")

            return



        # Exact 100% Sync Injection:

        if delay_ms > 100:

            # Video is ahead of Audio -> Apply Video Delay (Timeshift)

            self.apply_auto_vdelay(delay_ms, delay_sec, conf)

        elif delay_ms < -100:

            # Audio is ahead of Video -> Apply native Audio Delay (FFmpeg filter)

            self.apply_auto_adelay(abs(delay_ms), abs(delay_sec), conf)

        else:

            # Perfect match!

            if sync_url and not self.engine.is_playing:

                self.engine.play(sync_url, sync_name)

            self["status_text"].setText(f"✔ Auto-Sync: تطابق تام 100%! الفارق: {delay_ms}ms ({delay_sec:.2f}s)")



    def apply_auto_vdelay(self, delay_ms, delay_sec, conf):

        self.delay_seconds = round(delay_sec, 2)

        self.delay_ms = delay_ms

        self.engine.vdelay_seconds = self.delay_seconds

        AudioEngine.vdelay_seconds = self.delay_seconds

        self["delay_val"].setText(f"{self.delay_seconds:.2f} s")



        is_crypted = self.is_current_channel_encrypted()

        sync_url = getattr(self, "saved_sync_url", self.engine.current_url)

        sync_name = getattr(self, "saved_sync_name", self.engine.current_name)



        # 1. Start audio stream immediately so it connects in parallel

        if sync_url and not self.engine.is_playing:

            self.engine.play(sync_url, sync_name)



        # 2. Pause video for delay_ms

        status_msg = f"⚡ Auto-Sync [1/3]: تطبيق تأخير التايم شفت ({delay_ms}ms / {self.delay_seconds:.2f}s)..."

        self["status_text"].setText(status_msg)

        self.pause_timeshift()



        self._auto_conf = conf

        self._auto_delay_ms = delay_ms

        self._auto_is_crypted = is_crypted



        # Encrypted channel OSCam compensation (+200ms)

        effective_pause_ms = max(150, delay_ms + (200 if is_crypted else 0))

        self.vdelay_auto_timer.stop()

        self.vdelay_auto_timer.start(int(effective_pause_ms), True)



    def _on_vdelay_auto_ready(self):

        try:

            self.resume_timeshift()

            conf = getattr(self, "_auto_conf", 1.0)

            d_ms = getattr(self, "_auto_delay_ms", int(self.delay_seconds * 1000))

            is_crypted = getattr(self, "_auto_is_crypted", False)

            crypted_tag = " [مشفرة - OSCam]" if is_crypted else ""

            self["status_text"].setText(f"🔍 Auto-Sync [2/2]: جاري التشيك والتحقق من التطابق 100%...")

            

            # Start post-sync verification after 1.8s stabilization delay

            self.post_sync_verify_timer.stop()

            self.post_sync_verify_timer.start(1800, True)

        except Exception as e:

            print(f"[IPAudioPlus] Error in _on_vdelay_auto_ready: {e}")



    def _on_start_post_sync_verify(self):

        self.trigger_verification_sync(is_manual_recheck=False)



    def trigger_verification_sync(self, is_manual_recheck=False):

        """

        Stage 2 / Re-Check: Closed-Loop Verification & Auto-Correction

        Verifies actual alignment between currently running timeshifted broadcast and audio,

        and automatically corrects any remaining discrepancy down to 0ms (100% Match).

        """

        try:

            if not self.engine.is_playing or not self.engine.current_url:

                if is_manual_recheck:

                    self["status_text"].setText("Auto-Sync: يرجى تشغيل القناة الصوتية أولاً")

                return



            if self.is_auto_syncing or getattr(self, "is_verifying_sync", False):

                return



            sref = ""

            try:

                service = self.session.nav.getCurrentService()

                if service:

                    sref = self.session.nav.getCurrentlyPlayingServiceReference().toString()

            except Exception:

                pass



            if not sref:

                try:

                    import urllib.request

                    with urllib.request.urlopen("http://127.0.0.1/web/getcurrent", timeout=2) as resp:

                        content_str = resp.read().decode('utf-8', errors='ignore')

                        m = re.search(r"<e2servicereference>([^<]+)</e2servicereference>", content_str)

                        if m:

                            sref = m.group(1).strip()

                except Exception:

                    pass



            if not sref:

                return



            self.is_verifying_sync = True

            self._is_manual_recheck = is_manual_recheck



            if is_manual_recheck:

                self["status_text"].setText("🔍 جاري التشيك على التطابق وتصحيح أي فارق...")

            else:

                self["status_text"].setText("🔍 Auto-Sync [2/2]: جاري التشيك والتحقق من التطابق 100%...")



            tv_stream_url = f"http://127.0.0.1:8001/{sref}"

            net_stream_url = self.engine.current_url



            import threading

            threading.Thread(

                target=self._verify_sync_worker,

                args=(tv_stream_url, net_stream_url),

                daemon=True

            ).start()

        except Exception as e:

            print(f"[IPAudioPlus] Error in trigger_verification_sync: {e}")

            self.is_verifying_sync = False



    def _verify_sync_worker(self, tv_url, net_url):

        try:

            success, live_delay_ms, live_delay_sec, conf, msg = AutoSyncEngine.run_auto_sync(

                tv_url, net_url, duration=4.5, timeout=10.0

            )

        except Exception as e:

            success, live_delay_ms, live_delay_sec, conf, msg = False, 0, 0.0, 0.0, str(e)



        self.verify_sync_result = (success, live_delay_ms, live_delay_sec, conf, msg)

        try:

            self.verify_sync_timer.start(50, True)

        except Exception:

            self.is_verifying_sync = False



    def _on_verify_sync_timer_tick(self):

        try:

            self.is_verifying_sync = False

            if not hasattr(self, "verify_sync_result"):

                return



            success, live_delay_ms, live_delay_sec, conf, msg = self.verify_sync_result

            is_manual = getattr(self, "_is_manual_recheck", False)



            if not success or conf < 0.16:

                prefix = "✔ اكتمل التشيك:" if is_manual else "✔ اكتمل الضبط الأولي:"

                self["status_text"].setText(f"{prefix} تأخير الفيديو ({self.delay_seconds:.2f}s) - دقة القياس {int(conf*100)}%")

                return



            current_vdelay_ms = int(round(self.delay_seconds * 1000.0))

            if self.delay_seconds > 0:

                active_ms = current_vdelay_ms

            elif self.audio_delay_seconds > 0:

                active_ms = -int(round(self.audio_delay_seconds * 1000.0))

            else:

                active_ms = 0



            drift_ms = live_delay_ms - active_ms



            # If difference is within 60ms (approx 1 video frame): 100% Perfect Match!

            if abs(drift_ms) <= 60:

                cur_label = f"تأخير الصوت: {self.audio_delay_seconds:.2f}s" if self.audio_delay_seconds > 0 else f"تأخير الفيديو: {self.delay_seconds:.2f}s"

                self["status_text"].setText(f"✔ تطابق تام 100%! ({cur_label} | الفارق: 0ms)")

                return



            # If active is audio delay (aDelay)

            if self.audio_delay_seconds > 0:

                new_adelay_ms = max(0, int(round(self.audio_delay_seconds * 1000.0)) - drift_ms)

                self.apply_auto_adelay(new_adelay_ms, new_adelay_ms / 1000.0, conf)

                self["status_text"].setText(f"✔ تم الضبط والتصحيح: تطابق 100% (تأخير الصوت: {self.audio_delay_seconds:.2f}s | الفارق: 0ms)")

                return



            # If video still leads audio (drift_ms > 60): pause timeshift for remaining delta

            if drift_ms > 60:

                self["status_text"].setText(f"⚙️ جاري تصحيح الفارق (+{drift_ms}ms) لتطابق 100%...")

                self.pause_timeshift()

                self._correction_drift_ms = drift_ms

                self._correction_current_ms = current_vdelay_ms

                self.correction_timer.stop()

                self.correction_timer.start(int(drift_ms), True)

                return



            # If audio leads video (drift_ms < -60): seek forward in timeshift by abs(drift_ms)

            if drift_ms < -60:

                adv_ms = abs(drift_ms)

                self["status_text"].setText(f"⚙️ جاري تصحيح الفارق (-{adv_ms}ms) لتطابق 100%...")

                try:

                    service = self.session.nav.getCurrentService()

                    s = service.seek() if service else None

                    if s and s.isSeekable():

                        # 90000 ticks per second -> 90 ticks per ms

                        pts_ticks = int(adv_ms * 90)

                        s.seekRelative(1, pts_ticks)

                except Exception as e:

                    print(f"[IPAudioPlus] Seek error in verification correction: {e}")



                new_vdelay_ms = max(0, current_vdelay_ms - adv_ms)

                self.delay_seconds = round(new_vdelay_ms / 1000.0, 2)

                self.delay_ms = new_vdelay_ms

                self.engine.vdelay_seconds = self.delay_seconds

                AudioEngine.vdelay_seconds = self.delay_seconds

                self["delay_val"].setText(f"{self.delay_seconds:.2f} s")

                self["status_text"].setText(f"✔ تم الضبط والتصحيح: تطابق 100% (تأخير: {self.delay_seconds:.2f}s | الفارق: 0ms)")

        except Exception as e:

            print(f"[IPAudioPlus] Error in _on_verify_sync_timer_tick: {e}")

            self.is_verifying_sync = False



    def _on_correction_timer_tick(self):

        try:

            self.resume_timeshift()

            drift_ms = getattr(self, "_correction_drift_ms", 0)

            current_ms = getattr(self, "_correction_current_ms", int(self.delay_seconds * 1000))

            new_vdelay_ms = max(0, current_ms + drift_ms)

            self.delay_seconds = round(new_vdelay_ms / 1000.0, 2)

            self.delay_ms = new_vdelay_ms

            self.engine.vdelay_seconds = self.delay_seconds

            AudioEngine.vdelay_seconds = self.delay_seconds

            self["delay_val"].setText(f"{self.delay_seconds:.2f} s")

            self["status_text"].setText(f"✔ تم الضبط والتصحيح: تطابق 100% (تأخير: {self.delay_seconds:.2f}s | الفارق: 0ms)")

        except Exception as e:

            print(f"[IPAudioPlus] Error in _on_correction_timer_tick: {e}")



    def apply_auto_adelay(self, adelay_ms, adelay_sec, conf, is_shield=False, margin_ms=0):

        self.audio_delay_seconds = round(adelay_sec, 2)

        self.audio_delay_ms = int(adelay_ms)

        self.engine.adelay_seconds = self.audio_delay_seconds

        AudioEngine.adelay_seconds = self.audio_delay_seconds

        self["adelay_val"].setText(f"{self.audio_delay_seconds:.2f} s")

        self._auto_is_shield = is_shield

        self._auto_shield_margin = margin_ms



        sync_url = getattr(self, "saved_sync_url", self.engine.current_url)

        sync_name = getattr(self, "saved_sync_name", self.engine.current_name)



        if is_shield:

            self["status_text"].setText(f"🛡️ Spoiler Shield Active! Audio delayed (+{adelay_ms}ms) with {margin_ms}ms safety margin")

        else:

            self["status_text"].setText(f"✔ Auto-Sync: Audio delayed successfully by {self.audio_delay_seconds:.2f}s (100% Match, Conf: {int(conf * 100)}%)")



        # Restart playback with exact hardware/filter adelay via FFmpeg

        if sync_url:

            self.engine.play(sync_url, sync_name, adelay_ms=int(adelay_ms))



        # SetAudioDelay in Enigma2 DVB if available

        try:

            from Components.config import config

            if hasattr(config, "av"):

                if hasattr(config.av, "generalPCMdelay"):

                    config.av.generalPCMdelay.value = int(adelay_ms * 90)

                    config.av.generalPCMdelay.save()

                if hasattr(config.av, "generalAC3delay"):

                    config.av.generalAC3delay.value = int(adelay_ms * 90)

                    config.av.generalAC3delay.save()

        except Exception:

            pass



    def _on_adelay_auto_ready(self):

        try:

            self.engine.resume()

            conf = getattr(self, "_auto_conf", 1.0)

            d_ms = getattr(self, "_auto_delay_ms", int(self.audio_delay_seconds * 1000))

            if getattr(self, "_auto_is_shield", False):

                margin = getattr(self, "_auto_shield_margin", 250)

                self["status_text"].setText(f"🛡️ درع مانع الحرق: تم تأمين البث! تأخير الصوت {d_ms}ms (حاجز {margin}ms) - مستحيل يسبق الصوت الصورة")

            else:

                self["status_text"].setText(f"✔ Auto-Sync تم بنجاح! تأخير الصوت: {d_ms}ms ({self.audio_delay_seconds:.2f}s) - دقة {int(conf*100)}%")

        except Exception as e:

            print(f"[IPAudioPlus] Error in _on_adelay_auto_ready: {e}")



    def _on_elastic_watchdog_tick(self):

        return



    def _get_alsa_playback_info(self):

        return "UNKNOWN", 0



    def apply_elastic_healing(self, stall_sec):

        return



    def _setup_silent_corrector_timer(self):

        choice = config.plugins.IPAudioPlus.silent_corrector.value

        ms_map = {"5 min": 300000, "10 min": 600000, "15 min": 900000}

        interval = ms_map.get(choice, 0)

        self.silent_corrector_timer.stop()

        if interval > 0:

            self.silent_corrector_timer.start(interval, False)



    def _on_silent_corrector_tick(self):

        """

        Silent Micro-Corrector (المصحح الصامت):

        Takes an invisible quick 3.5s acoustic sample.

        If a small drift is detected (e.g. 150ms), gently nudges the timeshift

        by 50ms every 45 seconds (Smooth Adjustment) without any audio cut!

        """

        try:

            if not self.engine.is_playing or not self.engine.current_url or self.is_auto_syncing or self.is_soft_resyncing:

                return



            if self.delay_seconds <= 0 and self.audio_delay_seconds <= 0:

                return



            sref = ""

            try:

                service = self.session.nav.getCurrentService()

                if service:

                    sref = self.session.nav.getCurrentlyPlayingServiceReference().toString()

            except Exception:

                pass

            if not sref:

                return



            tv_url = f"http://127.0.0.1:8001/{sref}"

            net_url = self.engine.current_url



            th = threading.Thread(target=self._silent_corrector_worker, args=(tv_url, net_url), daemon=True)

            th.start()

        except Exception as e:

            print(f"[IPAudioPlus] Error in _on_silent_corrector_tick: {e}")



    def _silent_corrector_worker(self, tv_url, net_url):

        try:

            success, delay_ms, delay_sec, conf, msg = AutoSyncEngine.run_auto_sync(

                tv_url, net_url, duration=3.5, timeout=8.0

            )

            if success and conf >= 0.20 and self.engine.is_playing:

                current_vdelay_ms = int(round(self.delay_seconds * 1000.0))

                drift_ms = delay_ms - current_vdelay_ms



                # If drift is between 75ms and 1500ms -> start smooth ramp!

                if 75 <= abs(drift_ms) <= 1500:

                    self.micro_steps_remaining = abs(drift_ms) // 50

                    self.micro_step_direction = 1 if drift_ms > 0 else -1

                    self.micro_ramp_timer.start(40000, False) # Nudge 50ms every 40s

                    self.drift_predictor.record_measurement(drift_ms)

                    print(f"[IPAudioPlus] Cumulative Drift recorded: {drift_ms}ms (skew: {self.drift_predictor.estimated_skew_ppm:.1f} ppm)")

                    print(f"[IPAudioPlus] Silent Micro-Corrector started: {self.micro_steps_remaining} smooth steps of 50ms")

        except Exception as e:

            print(f"[IPAudioPlus] Error in _silent_corrector_worker: {e}")



    def _on_micro_ramp_step(self):

        """Applies a single imperceptible 50ms micro-step without cutting audio."""

        try:

            if self.micro_steps_remaining <= 0 or not self.engine.is_playing:

                self.micro_ramp_timer.stop()

                return



            nudge_sec = 0.05 * self.micro_step_direction

            self.delay_seconds = max(0.0, round(self.delay_seconds + nudge_sec, 2))

            self.delay_ms = int(self.delay_seconds * 1000)

            self.engine.vdelay_seconds = self.delay_seconds

            AudioEngine.vdelay_seconds = self.delay_seconds

            self["delay_val"].setText(f"{self.delay_seconds:.2f} s")



            # A 50ms micro-pause is 1 frame of video: completely invisible!

            self.pause_timeshift()

            self.drift_adjust_timer.stop()

            self.drift_adjust_timer.callback = []

            self.drift_adjust_timer.callback.append(self.resume_timeshift)

            self.drift_adjust_timer.start(50, True)



            self.micro_steps_remaining -= 1

            if self.micro_steps_remaining <= 0:

                self.micro_ramp_timer.stop()

                self["status_text"].setText("🕵️ المصحح الصامت: اكتمل التعديل الناعم واستقرت المزامنة 100%")

        except Exception as e:

            print(f"[IPAudioPlus] Error in _on_micro_ramp_step: {e}")

            self.micro_ramp_timer.stop()



    def on_soft_resync(self):

        """

        زر الإنعاش السريع (Soft Re-Sync):

        Triggered by Long Press on Green button.

        Calculates new difference in parts of a second and immediately applies it

        without interrupting or stopping the audio!

        """

        try:

            if not self.engine.is_playing or not self.engine.current_url:

                self["status_text"].setText("Soft Re-Sync: Please play an audio channel first")

                return



            if self.is_soft_resyncing or self.is_auto_syncing:

                return



            sref = ""

            try:

                service = self.session.nav.getCurrentService()

                if service:

                    sref = self.session.nav.getCurrentlyPlayingServiceReference().toString()

            except Exception:

                pass

            if not sref:

                self["status_text"].setText("Soft Re-Sync: Unable to resolve satellite TV service")

                return



            self.is_soft_resyncing = True

            self["status_text"].setText("🔄 Soft Re-Sync: Quick background audio matching...")



            tv_url = f"http://127.0.0.1:8001/{sref}"

            net_url = self.engine.current_url



            th = threading.Thread(target=self._soft_resync_worker, args=(tv_url, net_url), daemon=True)

            th.start()

        except Exception as e:

            print(f"[IPAudioPlus] Error in on_soft_resync: {e}")

            self.is_soft_resyncing = False



    def _soft_resync_worker(self, tv_url, net_url):

        try:

            success, delay_ms, delay_sec, conf, msg = AutoSyncEngine.run_auto_sync(

                tv_url, net_url, duration=3.5, timeout=8.0

            )

            self.soft_resync_result = (success, delay_ms, delay_sec, conf, msg)

            self.soft_resync_apply_timer = eTimer()

            self.soft_resync_apply_timer.callback.append(self._on_soft_resync_ready)

            self.soft_resync_apply_timer.start(50, True)

        except Exception as e:

            print(f"[IPAudioPlus] Error in _soft_resync_worker: {e}")

            self.is_soft_resyncing = False



    def _on_soft_resync_ready(self):

        self.is_soft_resyncing = False

        if not hasattr(self, "soft_resync_result"):

            return



        success, delay_ms, delay_sec, conf, msg = self.soft_resync_result

        if not success or conf < 0.18:

            self["status_text"].setText(f"Soft Re-Sync: Low correlation confidence ({int(conf*100)}%)")

            return



        current_vdelay_ms = int(round(self.delay_seconds * 1000.0))

        delta_ms = delay_ms - current_vdelay_ms



        if abs(delta_ms) >= 50:

            self.delay_seconds = max(0.0, round(delay_sec, 2))

            self.delay_ms = int(self.delay_seconds * 1000)

            self.engine.vdelay_seconds = self.delay_seconds

            AudioEngine.vdelay_seconds = self.delay_seconds

            self["delay_val"].setText(f"{self.delay_seconds:.2f} s")



            # Soft Flush timeshift

            if delta_ms > 0:

                self.pause_timeshift()

                self.drift_adjust_timer.stop()

                self.drift_adjust_timer.callback = []

                self.drift_adjust_timer.callback.append(self.resume_timeshift)

                self.drift_adjust_timer.start(int(min(delta_ms, 2000)), True)



            self["status_text"].setText(f"✔ Soft Re-Sync: Updated successfully! Video Timeshift: {self.delay_seconds:.2f}s (Diff: {delta_ms}ms)")

        else:

            self["status_text"].setText("✔ Soft Re-Sync: Audio and video in perfect sync!")



    def _check_stream_health_and_drift(self):

        """Continuous Health & Reconnect Watchdog: Detects stream drops, reconnects, and updates buffer status."""

        try:

            if not self.engine.is_playing or self.is_auto_syncing:

                return



            # 1. Update health status

            st = self.engine.get_health_status()

            level = st.get("level", "EXCELLENT")

            pct = st.get("percent", 100)

            bitrate = st.get("bitrate", 128)

            status_desc = st.get("text", "مستقر")



            # Update top status text if not counting delays or viewing other screens

            if not getattr(self, "is_vdelay_counting", False) and not getattr(self, "is_adelay_counting", False) and getattr(self, "focus_state", "") == "audio":

                curr_name = self.engine.current_name or "Audio"

                delay_str = ""

                if getattr(self, "audio_delay_seconds", 0) > 0:

                    delay_str = f" - aDelay: {self.audio_delay_seconds:.1f}s"

                elif getattr(self, "delay_seconds", 0) > 0:

                    delay_str = f" - vDelay: {self.delay_seconds:.1f}s"



                if level == "STALLED" or pct <= 25:

                    self["status_text"].setText(f"⚠ تنبيه: تقطيع في البث الصوتي! (Buffer: {pct}%) - جاري الاستقرار...")

                elif level == "BUFFERING":

                    self["status_text"].setText(f"Playing {curr_name}{delay_str}  |  ⚡ جاري التخزين: {pct}% ({bitrate} kbps)")

                else:

                    self["status_text"].setText(f"Playing {curr_name}{delay_str}  |  📶 Buffer: {pct}% ({bitrate} kbps) - {status_desc}")



            # 2. Smoothly update channel list view every ~2 seconds to show real-time signal bars

            now = time.time()

            if not hasattr(self, "_last_stream_view_tick"):

                self._last_stream_view_tick = now

            elif now - self._last_stream_view_tick >= 2.0:

                self._last_stream_view_tick = now

                if getattr(self, "focus_state", "") == "audio":

                    self.update_channels_view(preserve_index=True)



            # 3. Check if audio playback process died unexpectedly (stream dropped/disconnected)

            if self.engine.process and self.engine.process.poll() is not None:

                url = self.engine.current_url

                name = self.engine.current_name

                if url:

                    self["status_text"].setText("⚡ انقطع البث الصوتي! جاري إعادة الاتصال والمزامنة التلقائية...")

                    self.engine.play(url, name)

                    self.reconnect_sync_timer = eTimer()

                    self.reconnect_sync_timer.callback.append(self._on_reconnect_sync)

                    self.reconnect_sync_timer.start(2500, True)

        except Exception as e:

            print(f"[IPAudioPlus] Error in _check_stream_health_and_drift: {e}")



    def _on_reconnect_sync(self):

        pass



    def _on_drift_check_tick(self):

        """Disabled: Prevents background periodic check ('فحص') from freezing live TV broadcast."""

        return

        try:

            if not self.engine.is_playing or self.is_auto_syncing or getattr(self, "is_background_drift_checking", False):

                return



            # Only verify if timeshift or delay is active

            if self.delay_seconds <= 0.0 and self.audio_delay_seconds <= 0.0:

                return



            sref = ""

            try:

                service = self.session.nav.getCurrentService()

                if service:

                    sref = self.session.nav.getCurrentlyPlayingServiceReference().toString()

            except Exception:

                pass

            if not sref:

                return



            tv_url = f"http://127.0.0.1:8001/{sref}"

            net_url = self.engine.current_url

            if not net_url:

                return



            self.is_background_drift_checking = True

            th = threading.Thread(target=self._background_drift_worker, args=(tv_url, net_url), daemon=True)

            th.start()

        except Exception as e:

            print(f"[IPAudioPlus] Error in _on_drift_check_tick: {e}")

            self.is_background_drift_checking = False



    def _background_drift_worker(self, tv_url, net_url):

        try:

            success, delay_ms, delay_sec, conf, msg = AutoSyncEngine.run_auto_sync(

                tv_url, net_url, duration=8.0, timeout=12.0

            )

        except Exception:

            success = False

            delay_ms, delay_sec, conf, msg = 0, 0.0, 0.0, ""



        self.drift_result = (success, delay_ms, delay_sec, conf)

        try:

            self.drift_apply_timer.start(50, True)

        except Exception:

            self.is_background_drift_checking = False



    def _on_drift_result_ready(self):

        self.is_background_drift_checking = False

        return

        try:

            self.is_background_drift_checking = False

            if not hasattr(self, "drift_result") or not self.engine.is_playing:

                return



            success, live_delay_ms, live_delay_sec, conf = self.drift_result

            if not success or conf < 0.22:

                return



            current_vdelay_ms = int(round(self.delay_seconds * 1000.0))

            drift_ms = live_delay_ms - current_vdelay_ms



            # Minor jitter (< 250ms) is in sync: do nothing

            if abs(drift_ms) < 250:

                return



            # Noticeable drift between 250ms and 3500ms:

            if 250 <= drift_ms <= 3500:

                # Internet audio lagged behind -> smoothly pause video for drift_ms to let audio catch up

                self.delay_seconds = round(self.delay_seconds + (drift_ms / 1000.0), 2)

                self.delay_ms = int(self.delay_seconds * 1000)

                self.engine.vdelay_seconds = self.delay_seconds

                AudioEngine.vdelay_seconds = self.delay_seconds

                self["delay_val"].setText(f"{self.delay_seconds:.2f} s")

                self["status_text"].setText(f"⚡ فحص دوري تلقائي: تم تصحيح تأخر الصوت (+{drift_ms}ms) وتحديث التايم شفت إلى {self.delay_seconds:.2f} s")



                service = self.session.nav.getCurrentService()

                if service:

                    p = service.pause()

                    if p:

                        p.pause()

                        self.drift_adjust_timer.stop()

                        self.drift_adjust_timer.callback = []

                        self.drift_adjust_timer.callback.append(p.unpause)

                        self.drift_adjust_timer.start(int(drift_ms), True)



            elif -3500 <= drift_ms <= -250:

                # Video is too far behind -> seek forward smoothly in timeshift buffer without touching audio

                skip_sec = abs(drift_ms) / 1000.0

                self.delay_seconds = max(0.0, round(self.delay_seconds - skip_sec, 2))

                self.delay_ms = int(self.delay_seconds * 1000)

                self.engine.vdelay_seconds = self.delay_seconds

                AudioEngine.vdelay_seconds = self.delay_seconds

                self["delay_val"].setText(f"{self.delay_seconds:.2f} s")

                self["status_text"].setText(f"⚡ فحص دوري تلقائي: تم تصحيح تسارع الصوت (-{abs(drift_ms)}ms) وتحديث التايم شفت إلى {self.delay_seconds:.2f} s")



                service = self.session.nav.getCurrentService()

                if service:

                    s = service.seek()

                    if s:

                        # 90000 PTS ticks per second

                        pts_ticks = int(abs(drift_ms) * 90)

                        s.seekRelative(1, pts_ticks)

        except Exception as e:

            print(f"[IPAudioPlus] Error in _on_drift_result_ready: {e}")

            self.is_background_drift_checking = False



    def pause_timeshift(self):

        """Starts timeshift & freezes/pauses the video picture cleanly."""

        service = self.session.nav.getCurrentService()

        if not service:

            return



        # Direct Enigma2 C++ timeshift activation & freeze:

        # Avoids PTS seekTo(-90000) which causes black decoder frames on SF8008/HiSilicon

        try:

            ts = service.timeshift()

            if ts:

                if not ts.isTimeshiftEnabled():

                    ts.startTimeshift()

                if not ts.isTimeshiftActive():

                    ts.activateTimeshift()

            p = service.pause()

            if p:

                p.pause()

                return

        except Exception as e:

            print(f"[IPAudioPlus] Direct pause error: {e}")



        # Fallback via InfoBar

        try:

            from Screens.InfoBar import InfoBar

            if InfoBar.instance:

                if hasattr(InfoBar.instance, "pauseService"):

                    InfoBar.instance.pauseService()

                elif hasattr(InfoBar.instance, "startTimeshift"):

                    InfoBar.instance.startTimeshift()

        except Exception as eb:

            print(f"[IPAudioPlus] InfoBar pause error: {eb}")



    def resume_timeshift(self):

        """Unpauses timeshift video to stream with exact time lag."""

        service = self.session.nav.getCurrentService()

        if service:

            try:

                p = service.pause()

                if p:

                    p.unpause()

            except Exception as e:

                print(f"[IPAudioPlus] Direct unpause error: {e}")



        try:

            from Screens.InfoBar import InfoBar

            if InfoBar.instance:

                if hasattr(InfoBar.instance, "unPauseService"):

                    InfoBar.instance.unPauseService()

                elif hasattr(InfoBar.instance, "unpauseService"):

                    InfoBar.instance.unpauseService()

        except Exception:

            pass



    def on_pause(self):

        """Toggle video timeshift pause/resume and vDelay counter."""

        now = time.time()

        if hasattr(self, "_last_pause_press") and (now - self._last_pause_press < 0.4):

            return

        self._last_pause_press = now



        if not self.is_vdelay_counting:

            # 1st Press: Pause Timeshift & start counting seconds (accumulate if already delayed!)

            self.is_vdelay_counting = True

            if self.delay_seconds > 0:

                self.vdelay_start_time = time.time() - self.delay_seconds

            else:

                self.delay_seconds = 0.0

                self.vdelay_start_time = time.time()

            self.engine.vdelay_seconds = self.delay_seconds

            AudioEngine.vdelay_seconds = self.delay_seconds

            self.pause_timeshift()

            self.vdelay_timer.start(100, False)

            crypted_tag = " [مشفرة - OSCam]" if self.is_current_channel_encrypted() else ""

            self["delay_val"].setText(f"{self.delay_seconds:.1f} s")

            self["status_text"].setText(f"Timeshift Paused{crypted_tag} - Counting vDelay: {self.delay_seconds:.1f} s")

        else:

            # 2nd Press: Resume Timeshift at delayed position & stop counter

            self.is_vdelay_counting = False

            self.vdelay_timer.stop()

            if hasattr(self, "vdelay_start_time"):

                elapsed = time.time() - self.vdelay_start_time

                self.delay_seconds = round(elapsed, 1)

            self.resume_timeshift()

            self.engine.vdelay_seconds = self.delay_seconds

            AudioEngine.vdelay_seconds = self.delay_seconds

            crypted_tag = " [مشفرة - OSCam]" if self.is_current_channel_encrypted() else ""

            self["delay_val"].setText(f"{self.delay_seconds:.1f} s")

            self["status_text"].setText(f"Timeshift Resumed{crypted_tag} - Video Delayed by {self.delay_seconds:.1f} s")



    def vdelay_timer_tick(self):

        if not self.is_vdelay_counting:

            return

        if hasattr(self, "vdelay_start_time"):

            elapsed = time.time() - self.vdelay_start_time

            new_val = round(elapsed, 1)

        else:

            new_val = round(self.delay_seconds + 0.1, 1)



        if new_val != self.delay_seconds:

            self.delay_seconds = new_val

            self.engine.vdelay_seconds = self.delay_seconds

            AudioEngine.vdelay_seconds = self.delay_seconds

            self["delay_val"].setText(f"{self.delay_seconds:.1f} s")

            self["status_text"].setText(f"Timeshift Paused - Counting vDelay: {self.delay_seconds:.1f} s")



    def resume_live_tv_clean(self):

        """Instantly restores live TV with ZERO black screen, completely stops Timeshift C++ recording buffer, clears LED blinks and REC indicators."""

        # 1. Stop counting timers

        if hasattr(self, "vdelay_timer") and self.is_vdelay_counting:

            self.is_vdelay_counting = False

            self.vdelay_timer.stop()



        service = self.session.nav.getCurrentService()

        if service:

            # 2. Unpause playback immediately

            try:

                p = service.pause()

                if p:

                    p.unpause()

            except Exception:

                pass



            # 3. Completely stop C++ Timeshift recording buffer

            try:

                ts = service.timeshift()

                if ts:

                    try:

                        ts.stopTimeshift(1)

                    except Exception:

                        try:

                            ts.stopTimeshift(True)

                        except Exception:

                            pass

            except Exception as e:

                print(f"[IPAudioPlus] Direct ts.stopTimeshift error: {e}")



            # 4. Smoothly jump directly to live edge without flushing decoder or recreating DVB demuxer

            try:

                s = service.seek()

                if s and s.isSeekable():

                    s.seekRelative(1, 7776000000)

            except Exception as e:

                print(f"[IPAudioPlus] Live seek error: {e}")



        # 5. Tell InfoBar timeshift state to terminate cleanly without saving or asking to record

        try:

            from Screens.InfoBar import InfoBar

            if InfoBar.instance:

                ib = InfoBar.instance

                if hasattr(ib, "save_current_timeshift"):

                    ib.save_current_timeshift = False

                if hasattr(ib, "ptsStop"):

                    ib.ptsStop = True

                if hasattr(ib, "switchToLive"):

                    ib.switchToLive = True

                if hasattr(ib, "pts_switchtolive"):

                    ib.pts_switchtolive = True

                if hasattr(ib, "setSeekState"):

                    ib.setSeekState(getattr(ib, "SEEK_STATE_PLAY", 1))



                # If InfoBar timeshift is active, invoke its callback cleanly with True

                if hasattr(ib, "stopTimeshiftcheckTimeshiftRunningCallback"):

                    try:

                        ib.stopTimeshiftcheckTimeshiftRunningCallback(True)

                    except Exception:

                        pass

                elif hasattr(ib, "stopTimeshift"):

                    try:

                        ib.stopTimeshift()

                    except Exception:

                        pass



                # Turn off frontpanel LED patterns triggered by PTS

                if hasattr(ib, "ptsFrontpanelActions"):

                    try:

                        ib.ptsFrontpanelActions("stop")

                    except Exception:

                        pass



                # Erase temporary timeshift files

                if hasattr(ib, "eraseTimeshiftFile"):

                    try:

                        ib.eraseTimeshiftFile()

                    except Exception:

                        pass

        except Exception as eb:

            print(f"[IPAudioPlus] InfoBar cleanup error: {eb}")



        # 6. Ensure config.timeshift.isRecording is False if it exists

        try:

            if hasattr(config, "timeshift") and hasattr(config.timeshift, "isRecording"):

                config.timeshift.isRecording.value = False

        except Exception:

            pass



        # 7. Cancel any accidental timeshift recording timers in RecordTimer

        try:

            if hasattr(self.session, "nav") and hasattr(self.session.nav, "RecordTimer"):

                rt = self.session.nav.RecordTimer

                for timer in list(rt.timer_list):

                    if timer.isRunning():

                        tags_str = " ".join([str(t) for t in (timer.tags or [])]).lower()

                        name_str = str(getattr(timer, "name", "")).lower()

                        if "timeshift" in tags_str or "timeshift" in name_str:

                            rt.abort(timer)

        except Exception as e:

            print(f"[IPAudioPlus] RecordTimer cleanup error: {e}")



        # 8. Reset frontpanel LED pattern and speed in /proc/stb/fp/ to stop blinking

        try:

            for p in ["/proc/stb/fp/led_set_pattern", "/proc/stb/fp/led0_pattern"]:

                if os.path.exists(p):

                    with open(p, "w") as f:

                        f.write("0\n")

            for sp in ["/proc/stb/fp/led_pattern_speed", "/proc/stb/fp/led_set_speed"]:

                if os.path.exists(sp):

                    with open(sp, "w") as f:

                        f.write("0\n")

        except Exception:

            pass



        # 9. Dismiss any timeshift questions safely with 'noSave'

        self.auto_dismiss_timeshift_dialogs()



    def auto_dismiss_timeshift_dialogs(self):

        try:

            def _close_safe(dlg):

                closed = False

                # If dialog has choices / list, find the safe "noSave" / "discard" choice

                if hasattr(dlg, "list") and dlg.list:

                    for item in dlg.list:

                        val = item[1] if isinstance(item, (tuple, list)) and len(item) > 1 else item

                        if val in ["noSave", "no", "restarttimeshift", "golivetv"]:

                            try:

                                dlg.close(val)

                                closed = True

                                break

                            except Exception:

                                pass

                if not closed:

                    try:

                        dlg.close("noSave")

                        closed = True

                    except Exception:

                        try:

                            dlg.close(False)

                            closed = True

                        except Exception:

                            try:

                                dlg.close()

                                closed = True

                            except Exception:

                                pass



            # 1. Dismiss active current dialog

            if hasattr(self.session, "current_dialog") and self.session.current_dialog:

                cur = self.session.current_dialog

                txt = (str(getattr(cur, "title", "")) + " " + str(getattr(cur, "text", ""))).lower()

                if "time shift" in txt or "timeshift" in txt or "leave time shift" in txt or "question" in txt:

                    _close_safe(cur)



            # 2. Scan dialog_stack

            for dlg_item in list(self.session.dialog_stack):

                dlg = dlg_item[0] if isinstance(dlg_item, tuple) else dlg_item

                txt = (str(getattr(dlg, "title", "")) + " " + str(getattr(dlg, "text", ""))).lower()

                if "time shift" in txt or "timeshift" in txt or "leave time shift" in txt or "question" in txt:

                    _close_safe(dlg)

        except Exception:

            pass



    def on_play(self):

        """Toggle audio pause/resume and aDelay counter."""

        now = time.time()

        if hasattr(self, "_last_play_press") and (now - self._last_play_press < 0.4):

            return

        self._last_play_press = now



        if not self.is_adelay_counting:

            # 1st Press on Play: Ensure audio is running

            if not self.engine.is_playing:

                idx = self["audio_list"].getSelectedIndex()

                if idx is not None and 0 <= idx < len(self.current_channels):

                    item = self.current_channels[idx]

                    url = item.get("url", "")

                    name = item.get("name", "Channel")

                    if url:

                        self.engine.play(url, name)

                        self.update_channels_view(preserve_index=True)

                        self["status_text"].setText(f"Playing {name} - Press [PLAY] again to pause & set aDelay")

                        return



            self.is_adelay_counting = True

            if self.audio_delay_seconds > 0:

                self.adelay_start_time = time.time() - self.audio_delay_seconds

            else:

                self.audio_delay_seconds = 0.0

                self.adelay_start_time = time.time()

            self.engine.adelay_seconds = self.audio_delay_seconds

            AudioEngine.adelay_seconds = self.audio_delay_seconds

            self.engine.pause()

            self.adelay_timer.start(100, False)

            self["adelay_val"].setText(f"{self.audio_delay_seconds:.1f} s")

            self["status_text"].setText(f"Audio Paused - Counting aDelay: {self.audio_delay_seconds:.1f} s")

        else:

            # 2nd Press on Play: Resume audio with exact calculated delay & stop counter

            self.is_adelay_counting = False

            self.adelay_timer.stop()

            if hasattr(self, "adelay_start_time"):

                elapsed = time.time() - self.adelay_start_time

                self.audio_delay_seconds = round(elapsed, 1)

            self.engine.resume()

            self.engine.adelay_seconds = self.audio_delay_seconds

            AudioEngine.adelay_seconds = self.audio_delay_seconds

            self["adelay_val"].setText(f"{self.audio_delay_seconds:.1f} s")

            self["status_text"].setText(f"Audio Resumed - Delayed by {self.audio_delay_seconds:.1f} s")



    def adelay_timer_tick(self):

        if not self.is_adelay_counting:

            return

        if hasattr(self, "adelay_start_time"):

            elapsed = time.time() - self.adelay_start_time

            new_val = round(elapsed, 1)

        else:

            new_val = round(self.audio_delay_seconds + 0.1, 1)



        if new_val != self.audio_delay_seconds:

            self.audio_delay_seconds = new_val

            self.engine.adelay_seconds = self.audio_delay_seconds

            AudioEngine.adelay_seconds = self.audio_delay_seconds

            self["adelay_val"].setText(f"{self.audio_delay_seconds:.1f} s")

            self["status_text"].setText(f"Audio Paused - Counting aDelay: {self.audio_delay_seconds:.1f} s")



    def on_red(self):

        if self.focus_state == "token_gen":

            self.hide_token_gen()

            return

        """Reset vDelay & aDelay back to 0.0s, resume audio, and return to live TV."""

        if hasattr(self, "vdelay_auto_timer"):

            self.vdelay_auto_timer.stop()

        if hasattr(self, "adelay_auto_timer"):

            self.adelay_auto_timer.stop()

        if hasattr(self, "auto_sync_timer"):

            self.auto_sync_timer.stop()

        if hasattr(self, "verify_sync_timer"):

            self.verify_sync_timer.stop()

        if hasattr(self, "post_sync_verify_timer"):

            self.post_sync_verify_timer.stop()

        if hasattr(self, "correction_timer"):

            self.correction_timer.stop()

        self.is_auto_syncing = False

        self.is_verifying_sync = False



        if self.is_vdelay_counting:

            self.is_vdelay_counting = False

            self.vdelay_timer.stop()

        if self.is_adelay_counting:

            self.is_adelay_counting = False

            self.adelay_timer.stop()

            self.engine.resume()



        self.delay_seconds = 0.0

        self.audio_delay_seconds = 0.0

        self.engine.vdelay_seconds = 0.0

        self.engine.adelay_seconds = 0.0

        AudioEngine.vdelay_seconds = 0.0

        AudioEngine.adelay_seconds = 0.0

        self["delay_val"].setText("0.0 s")

        self["adelay_val"].setText("0.0 s")

        self.resume_live_tv_clean()

        self["status_text"].setText("Delays Reset - Live TV Restored")



    def on_stop(self):

        """Dedicated STOP key handler: completely stops timeshift, cancels any recording, and restores pure live TV broadcast."""

        if hasattr(self, "vdelay_auto_timer"):

            self.vdelay_auto_timer.stop()

        if hasattr(self, "adelay_auto_timer"):

            self.adelay_auto_timer.stop()

        if hasattr(self, "auto_sync_timer"):

            self.auto_sync_timer.stop()

        if hasattr(self, "verify_sync_timer"):

            self.verify_sync_timer.stop()

        if hasattr(self, "post_sync_verify_timer"):

            self.post_sync_verify_timer.stop()

        if hasattr(self, "correction_timer"):

            self.correction_timer.stop()

        self.is_auto_syncing = False

        self.is_verifying_sync = False



        if self.is_vdelay_counting:

            self.is_vdelay_counting = False

            self.vdelay_timer.stop()

        if self.is_adelay_counting:

            self.is_adelay_counting = False

            self.adelay_timer.stop()



        # 1. Stop external audio engine immediately and unmute DVB broadcast audio

        self.engine.stop(unmute_dvb=True)



        # 2. Reset all delay counters

        self.delay_seconds = 0.0

        self.audio_delay_seconds = 0.0

        self.engine.vdelay_seconds = 0.0

        self.engine.adelay_seconds = 0.0

        AudioEngine.vdelay_seconds = 0.0

        AudioEngine.adelay_seconds = 0.0

        self["delay_val"].setText("0.0 s")

        self["adelay_val"].setText("0.0 s")



        # 3. Cleanly terminate timeshift and restore live TV

        self.resume_live_tv_clean()



        # 4. Update UI status and channel list view

        self["status_text"].setText("⚡ تم إيقاف القناة الصوتية والتايم شفت واستعادة صوت القناة الأصلي")

        self.update_channels_view(preserve_index=True)



    def on_yellow(self):

        if self.focus_state == "token_gen":

            self.clear_tg_data()

            return

        """Reset all: Stop audio playback, unmute DVB broadcast audio, reset all delays to 0.0s, cancel timeshift cleanly."""

        if hasattr(self, "vdelay_auto_timer"):

            self.vdelay_auto_timer.stop()

        if hasattr(self, "adelay_auto_timer"):

            self.adelay_auto_timer.stop()

        if hasattr(self, "auto_sync_timer"):

            self.auto_sync_timer.stop()

        if hasattr(self, "verify_sync_timer"):

            self.verify_sync_timer.stop()

        if hasattr(self, "post_sync_verify_timer"):

            self.post_sync_verify_timer.stop()

        if hasattr(self, "correction_timer"):

            self.correction_timer.stop()

        self.is_auto_syncing = False

        self.is_verifying_sync = False



        if self.is_vdelay_counting:

            self.is_vdelay_counting = False

            self.vdelay_timer.stop()

        if self.is_adelay_counting:

            self.is_adelay_counting = False

            self.adelay_timer.stop()



        self.engine.stop(unmute_dvb=True)

        self.delay_seconds = 0.0

        self.audio_delay_seconds = 0.0

        self.engine.vdelay_seconds = 0.0

        self.engine.adelay_seconds = 0.0

        AudioEngine.vdelay_seconds = 0.0

        AudioEngine.adelay_seconds = 0.0

        self["delay_val"].setText("0.0 s")

        self["adelay_val"].setText("0.0 s")

        self.resume_live_tv_clean()

        self["status_text"].setText("Stopped - Original TV Broadcast Audio Restored")

        self.update_channels_view(preserve_index=True)



    def on_blue(self):

        if self.focus_state == "token_gen":

            self.test_stream_flow()

            return

        elif self.focus_state == "live_info":

            self.hide_live_info()

        else:

            self.show_live_info()



    def on_exit_key(self):

        if self.focus_state == "token_gen":

            self.hide_token_gen()

        elif self.focus_state == "live_info":

            self.hide_live_info()

        elif self.focus_state == "server":

            self.hide_server_popup()

        else:

            if self.is_vdelay_counting:

                self.vdelay_timer.stop()

                self.is_vdelay_counting = False

                self.resume_timeshift()

                self.engine.vdelay_seconds = self.delay_seconds

                AudioEngine.vdelay_seconds = self.delay_seconds

            if self.is_adelay_counting:

                self.adelay_timer.stop()

                self.is_adelay_counting = False

                self.engine.resume()

                self.engine.adelay_seconds = self.audio_delay_seconds

                AudioEngine.adelay_seconds = self.audio_delay_seconds

            try:

                self.stream_monitor_timer.stop()

            except Exception:

                pass

            IPAudioPlusScreen.active_instance = None

            self.close()





def main(session, **kwargs):

    if config.plugins.IPAudioPlus.web_interface.value == "ON":

        try:

            from . import web_server

            web_server.register_reload_callback(IPAudioPlusScreen.reload_channels_from_web)

            web_server.start_server(int(config.plugins.IPAudioPlus.web_port.value))

        except Exception as e:

            print(f"[IPAudioPlus] Web server main start error: {e}")

    session.open(IPAudioPlusScreen)





def menu_main(menuid, **kwargs):

    if menuid == "mainmenu":

        return [("IP AudioPlus", main, "ip_audio_plus_menu", 45)]

    return []





def install_global_stop_hook():

    """Hook InfoBarTimeshift.stopTimeshift so pressing STOP on the remote while watching TV also stops IP audio."""

    try:

        from Components.Timeshift import InfoBarTimeshift

        orig_stop = getattr(InfoBarTimeshift, "stopTimeshift", None)

        if orig_stop and not getattr(InfoBarTimeshift, "_ipaudio_stop_hooked", False):

            def hooked_stopTimeshift(self, *args, **kwargs):

                try:

                    engine = AudioEngine.get_instance()

                    if engine and engine.is_playing:

                        engine.stop(unmute_dvb=True)

                except Exception:

                    pass

                return orig_stop(self, *args, **kwargs)

            InfoBarTimeshift.stopTimeshift = hooked_stopTimeshift

            InfoBarTimeshift._ipaudio_stop_hooked = True

    except Exception as e:

        print(f"[IPAudioPlus] install_global_stop_hook error: {e}")





def sessionstart(reason, **kwargs):

    if reason == 0:

        install_global_stop_hook()

        if config.plugins.IPAudioPlus.web_interface.value == "ON":

            try:

                from . import web_server

                web_server.register_reload_callback(IPAudioPlusScreen.reload_channels_from_web)

                web_server.start_server(int(config.plugins.IPAudioPlus.web_port.value))

            except Exception as e:

                print(f"[IPAudioPlus] Web server sessionstart error: {e}")

    elif reason == 1:

        try:

            from . import web_server

            web_server.stop_server()

        except Exception:

            pass





def Plugins(**kwargs):

    descriptors = [

        PluginDescriptor(

            where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART],

            fnc=sessionstart,

            needsRestart=False

        )

    ]

    if config.plugins.IPAudioPlus.show_plugin_list.value == "ON":

        descriptors.append(

            PluginDescriptor(

                name="IP AudioPlus",

                description="IP Audio Plus 1.0 player and delay manager",

                where=PluginDescriptor.WHERE_PLUGINMENU,

                icon="plugin.png",

                fnc=main

            )

        )

    if config.plugins.IPAudioPlus.show_extension_list.value == "ON":

        descriptors.append(

            PluginDescriptor(

                name="IP AudioPlus",

                description="IP Audio Plus 1.0 player and delay manager",

                where=PluginDescriptor.WHERE_EXTENSIONSMENU,

                icon="plugin.png",

                fnc=main

            )

        )

    if config.plugins.IPAudioPlus.show_main_menu.value == "ON":

        descriptors.append(

            PluginDescriptor(

                name="IP AudioPlus",

                description="IP Audio Plus 1.0",

                where=PluginDescriptor.WHERE_MENU,

                fnc=menu_main

            )

        )

    return descriptors

