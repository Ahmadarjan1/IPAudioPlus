import os
import signal
import subprocess
import time

print('[*] Testing AudioEngine play & pause...')
cmd = 'gst-launch-1.0 playbin uri="http://server.quran.com.kw:8000/quraan" audio-sink="alsasink" video-sink="fakesink"'
p = subprocess.Popen(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, preexec_fn=os.setsid)
print(f'[+] Started process pid: {p.pid}, pgid: {os.getpgid(p.pid)}')

time.sleep(3)
print('[*] Sending SIGSTOP...')
os.killpg(os.getpgid(p.pid), signal.SIGSTOP)
print('[+] Paused for 4 seconds...')
time.sleep(4)

print('[*] Sending SIGCONT...')
os.killpg(os.getpgid(p.pid), signal.SIGCONT)
print('[+] Resumed! Listening for 4 seconds...')
time.sleep(4)

print('[*] Killing process...')
os.killpg(os.getpgid(p.pid), signal.SIGKILL)
print('[+] Test finished successfully.')
