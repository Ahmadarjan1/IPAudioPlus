import time
from send_key import send_key
from manage_stb import take_osd_screenshot

print("[*] Clearing all open menus...")
send_key(1)
time.sleep(0.5)
send_key(1)
time.sleep(0.5)
send_key(1)
time.sleep(0.5)

print("[*] Opening Plugin Browser...")
send_key(399)
time.sleep(1.5)

print("[*] Opening IP AudioPlus...")
send_key(108) # Down
time.sleep(0.3)
send_key(108) # Down
time.sleep(0.3)
send_key(352) # OK
time.sleep(1.5)

print("[*] Playing Channel 1 (OK)...")
send_key(352)
time.sleep(1.5)

take_osd_screenshot("ip_audioplus_playing.png")

print("[*] Pressing Yellow button (400) - Reset all...")
send_key(400)
time.sleep(1.0)

take_osd_screenshot("ip_audioplus_reset_all.png")
print("[+] Finished successfully.")
