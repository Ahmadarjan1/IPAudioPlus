# -*- coding: utf-8 -*-
# AudioPlus Plugin for Enigma2
# Designed for MyCustomSkin Style
# Dynamic Playlist & Folder Loader, Hardware DVB Mute, Audio Stream Delay & Timed Timeshift Controller

import os
import json
import time
import subprocess
import fcntl
import signal
import glob
import re
import threading
from urllib.request import Request, urlopen
from enigma import (
    eListboxPythonMultiContent,
    gFont,
    eTimer,
    RT_HALIGN_LEFT,
    RT_HALIGN_RIGHT,
    RT_HALIGN_CENTER,
    RT_VALIGN_CENTER,
    loadPNG
)
from Components.ActionMap import ActionMap, loadKeymap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from Components.MultiContent import (
    MultiContentEntryText,
    MultiContentEntryPixmapAlphaBlend
)
from Components.config import (
    config,
    ConfigSubsection,
    ConfigText,
    ConfigSelection
)
from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor

PLUGIN_PATH = os.path.dirname(__file__)
IMG_PATH = os.path.join(PLUGIN_PATH, "images")

# Load plugin keymap
keymap_path = os.path.join(PLUGIN_PATH, "keymap.xml")
if os.path.exists(keymap_path):
    loadKeymap(keymap_path)

# Linux DVB Audio Mute ioctl
AUDIO_SET_MUTE = 0x00006f06

def log_debug(msg):
    try:
        with open("/tmp/audioplus.log", "a", encoding="utf-8") as f:
            f.write(f"[AudioPlus] {msg}\n")
    except Exception:
        pass
    print(f"[AudioPlus] {msg}")

# Configuration Definitions
config.plugins.AudioPlus = ConfigSubsection()
config.plugins.AudioPlus.playlist_path = ConfigText(default="/etc/enigma2/IPAudioPro.json", fixed_size=False)
config.plugins.AudioPlus.audio_player = ConfigSelection(
    default="Auto",
    choices=[
        ("Auto", "Auto"),
        ("FFmpeg", "FFmpeg"),
        ("GStreamer", "GStreamer"),
        ("eXteplayer3", "eXteplayer3"),
        ("ALSA", "ALSA Direct")
    ]
)
config.plugins.AudioPlus.use_user_agent = ConfigSelection(default="No", choices=[("No", "No"), ("Yes", "Yes")])
config.plugins.AudioPlus.startup_buffer = ConfigSelection(
    default="Balanced",
    choices=[
        ("Balanced", "Balanced"),
        ("Safe(higher startup delay)", "Safe(higher startup delay)")
    ]
)
config.plugins.AudioPlus.timeshift_storage = ConfigSelection(
    default="Hard Disk",
    choices=[("Hard Disk", "Hard Disk"), ("RAM", "RAM")]
)
config.plugins.AudioPlus.timeshift_remember = ConfigSelection(default="Yes", choices=[("Yes", "Yes"), ("No", "No")])
config.plugins.AudioPlus.saved_ts_delay = ConfigText(default="5.0", fixed_size=False)
config.plugins.AudioPlus.show_in_mainmenu = ConfigSelection(default="No", choices=[("No", "No"), ("Yes", "Yes")])
config.plugins.AudioPlus.show_picons = ConfigSelection(default="Yes", choices=[("Yes", "Yes"), ("No", "No")])
config.plugins.AudioPlus.show_jsc_epg = ConfigSelection(default="Yes", choices=[("Yes", "Yes"), ("No", "No")])
config.plugins.AudioPlus.show_preview_art = ConfigSelection(default="No", choices=[("No", "No"), ("Yes", "Yes")])
config.plugins.AudioPlus.skin_style = ConfigSelection(
    default="MyCustomSkin",
    choices=[("MyCustomSkin", "MyCustomSkin"), ("Dark Modern", "Dark Modern"), ("Minimal", "Minimal")]
)


def get_detected_playlists():
    """Detect available playlist files and folders on the system."""
    detected = []
    search_dirs = ["/etc/enigma2", "/media/hdd", "/media/usb", "/tmp", "/etc/enigma2/playlist"]
    extensions = ["*.json", "*.m3u", "*.m3u8", "*.txt"]
    
    # Priority default
    if os.path.exists("/etc/enigma2/IPAudioPro.json"):
        detected.append("/etc/enigma2/IPAudioPro.json")
    if os.path.exists("/etc/enigma2/AudioPlus.json"):
        detected.append("/etc/enigma2/AudioPlus.json")

    for s_dir in search_dirs:
        if os.path.exists(s_dir):
            for ext in extensions:
                for fpath in glob.glob(os.path.join(s_dir, ext)):
                    if fpath not in detected and "addons_manager.json" not in fpath and "emilpanel" not in fpath:
                        detected.append(fpath)

    if not detected:
        detected = ["/etc/enigma2/IPAudioPro.json", "/etc/enigma2/AudioPlus.json", "/etc/enigma2"]
    return detected


# ==========================================
# beIN / JSC Live Match EPG Guide Manager
# ==========================================
class JscEpgManager:
    _instance = None
    CACHE_FILE = "/tmp/audioplus_epg.json"

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = JscEpgManager()
        return cls._instance

    def __init__(self):
        self.epg_data = {}
        self.is_fetching = False
        self.load_cache()
        self.start_background_fetch()

    def load_cache(self):
        if os.path.exists(self.CACHE_FILE):
            try:
                with open(self.CACHE_FILE, "r", encoding="utf-8") as f:
                    self.epg_data = json.load(f)
            except Exception:
                self.epg_data = {}

    def save_cache(self):
        try:
            with open(self.CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(self.epg_data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def start_background_fetch(self):
        if self.is_fetching:
            return
        t = threading.Thread(target=self._fetch_worker, daemon=True)
        t.start()

    def _fetch_worker(self):
        self.is_fetching = True
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        headers = {"User-Agent": ua, "Accept": "application/json, text/plain, */*"}
        
        # 1. Fetch live matches from sports API endpoints
        fetched = {}
        try:
            # Multi-endpoint live sports events schedule
            req = Request("https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard", headers=headers)
            with urlopen(req, timeout=4) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                events = data.get("events", [])
                for ev in events:
                    name = ev.get("name", "")
                    status = ev.get("status", {}).get("type", {}).get("detail", "Live")
                    for comp in ev.get("competitions", []):
                        for broad in comp.get("broadcasts", []):
                            for b_name in broad.get("names", []):
                                fetched[b_name.lower()] = {
                                    "title": f"⚽ {name}",
                                    "details": f"Status: {status} | League: Premier League"
                                }
        except Exception as e:
            log_debug(f"ESPN EPG fetch notice: {e}")

        # Standard beIN Sports channel mapping fallback
        standard_events = {
            "bein 1": {"title": "⚽ Live Match: Top European League Match", "details": "HD Live Broadcast | Studio Analysis"},
            "bein 2": {"title": "⚽ Live Match: Premier League / Champions League", "details": "HD Live Broadcast | Commentary 1"},
            "bein 3": {"title": "⚽ Live Match: La Liga / Serie A", "details": "HD Live Broadcast | Commentary 2"},
            "bein 4": {"title": "⚽ Live Match: Ligue 1 / Bundesliga", "details": "HD Live Broadcast"},
            "bein max 1": {"title": "🏆 Tournament Live Event / Continental Cup", "details": "High Definition Audio Feed"},
            "bein max 2": {"title": "🏆 Tournament Live Event / Continental Cup", "details": "High Definition Audio Feed"},
            "orange 1": {"title": "⚽ Live Sports & Commentary Stream", "details": "Orange Premium Audio Feed 1"},
            "orange 2": {"title": "⚽ Live Sports & Commentary Stream", "details": "Orange Premium Audio Feed 2"},
            "quran": {"title": "📖 Holy Quran Recitation & Translation", "details": "24/7 Continuous Spiritual Audio"}
        }

        for k, v in standard_events.items():
            if k not in fetched:
                fetched[k] = v

        if fetched:
            self.epg_data.update(fetched)
            self.save_cache()
        self.is_fetching = False

    def get_event_for_channel(self, channel_name):
        if not channel_name:
            return None
        c_clean = re.sub(r'[^a-zA-Z0-9]', ' ', channel_name.lower())
        
        # Direct lookup
        for k, v in self.epg_data.items():
            if k in c_clean or c_clean in k:
                return v

        # Check keyword matching
        if "bein" in c_clean:
            for num in ["1", "2", "3", "4", "5", "6", "7", "8", "9"]:
                if num in c_clean:
                    key = f"bein {num}"
                    if key in self.epg_data:
                        return self.epg_data[key]
            return {"title": f"⚽ {channel_name} Live Event", "details": "beIN Sports Audio Coverage"}
        elif "orange" in c_clean:
            return {"title": f"⚽ {channel_name} Live Match Feed", "details": "Live Sports Commentary"}
        elif "quran" in c_clean or "tarteel" in c_clean or "karem" in c_clean:
            return {"title": "📖 Holy Quran Recitation", "details": "Live Quran Broadcasting"}
        
        return {"title": f"📻 {channel_name}", "details": "Live Audio Stream Broadcast"}


# ==========================================
# Robust Audio & DVB Hardware Controller
# ==========================================
class AudioEngine:
    _instance = None
    
    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = AudioEngine()
        return cls._instance

    def __init__(self):
        self.process = None
        self.current_url = None
        self.current_name = None
        self.current_delay = 0.0
        self.is_active = False

    def mute_dvb(self, enable=True):
        """Mute/Unmute all DVB audio hardware devices to completely silence satellite audio."""
        for adapter in range(2):
            for dev in range(4):
                path = f"/dev/dvb/adapter{adapter}/audio{dev}"
                if os.path.exists(path):
                    try:
                        fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
                        fcntl.ioctl(fd, AUDIO_SET_MUTE, 1 if enable else 0)
                        os.close(fd)
                    except Exception:
                        pass
        log_debug(f"DVB Hardware Mute set to: {enable}")

    def kill_all_players(self):
        """Force kill all previous player processes to ensure no sound overlap."""
        if self.process:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
            except Exception:
                try:
                    self.process.kill()
                except Exception:
                    pass
            self.process = None
        
        try:
            os.system("killall -9 gst-launch-1.0 ffmpeg aplay 2>/dev/null")
        except Exception:
            pass

    def play(self, url, name="", audio_delay=0.0):
        self.kill_all_players()

        if not url:
            self.current_url = None
            self.current_name = None
            self.current_delay = 0.0
            self.is_active = False
            return False

        self.current_url = url
        self.current_name = name
        self.current_delay = audio_delay
        self.is_active = True

        # Hardware mute satellite channel sound
        self.mute_dvb(True)

        delay_ms = int(round(audio_delay * 1000))
        log_debug(f"AudioEngine play: {name}, Delay: {audio_delay}s ({delay_ms}ms), URL: {url}")

        is_local_file = os.path.exists(url) or url.startswith("file://")
        play_uri = f"file://{os.path.abspath(url)}" if (os.path.exists(url) and not url.startswith("file://")) else url

        # 0. Audio Player Selection
        player_mode = config.plugins.AudioPlus.audio_player.value
        log_debug(f"Selected audio player mode: {player_mode}")

        # 1. User-Agent Configuration
        use_ua = config.plugins.AudioPlus.use_user_agent.value == "Yes"
        ua_str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        
        # 2. Startup Buffer Configuration
        buf_mode = config.plugins.AudioPlus.startup_buffer.value
        if buf_mode == "Safe(higher startup delay)":
            buf_ffmpeg = ["-thread_queue_size", "1024", "-analyzeduration", "5000000", "-probesize", "5000000", "-bufsize", "8192k"]
            gst_buf = "buffer-duration=6000000000 buffer-size=4194304"
        else:
            # Balanced
            buf_ffmpeg = ["-thread_queue_size", "256", "-analyzeduration", "1000000", "-probesize", "1000000"]
            gst_buf = "buffer-duration=1500000000"

        # Construct Player Commands according to chosen player
        if player_mode == "GStreamer":
            cmd = ["gst-launch-1.0", "playbin", f"uri={play_uri}", f"{gst_buf}", "audio-sink=alsasink sync=true"]
        elif player_mode == "eXteplayer3" and os.path.exists("/usr/bin/exteplayer3") and delay_ms == 0:
            cmd = ["exteplayer3", url, "0", "0", "0", "0", "0", "0"]
        elif player_mode == "ALSA":
            cmd = ["ffmpeg", "-i", url.replace("file://", ""), "-vn", "-f", "alsa", "default"]
        elif player_mode == "FFmpeg" or delay_ms > 0:
            cmd = ["ffmpeg"]
            if not is_local_file:
                cmd.extend(["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "2"])
                if use_ua:
                    cmd.extend(["-user_agent", ua_str])
            cmd.extend(buf_ffmpeg)
            if delay_ms > 0:
                cmd.extend(["-i", url.replace("file://", ""), "-af", f"adelay={delay_ms}|{delay_ms}", "-vn", "-f", "alsa", "default"])
            else:
                cmd.extend(["-i", url.replace("file://", ""), "-vn", "-f", "alsa", "default"])
        else:
            # Auto
            if delay_ms > 0:
                cmd = ["ffmpeg"]
                if not is_local_file:
                    cmd.extend(["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "2"])
                    if use_ua:
                        cmd.extend(["-user_agent", ua_str])
                cmd.extend(buf_ffmpeg)
                cmd.extend(["-i", url.replace("file://", ""), "-af", f"adelay={delay_ms}|{delay_ms}", "-vn", "-f", "alsa", "default"])
            else:
                if is_local_file:
                    cmd = ["gst-launch-1.0", "playbin", f"uri={play_uri}", f"{gst_buf}", "audio-sink=alsasink sync=true"]
                else:
                    if use_ua or buf_mode == "Safe(higher startup delay)":
                        cmd = ["ffmpeg", "-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "2"]
                        if use_ua:
                            cmd.extend(["-user_agent", ua_str])
                        cmd.extend(buf_ffmpeg)
                        cmd.extend(["-i", url, "-vn", "-f", "alsa", "default"])
                    else:
                        cmd = ["gst-launch-1.0", "playbin", f"uri={play_uri}", f"{gst_buf}", "audio-sink=alsasink sync=true"]

        try:
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                preexec_fn=os.setsid
            )
            log_debug(f"Started playback process PID {self.process.pid}")
            return True
        except Exception as e:
            log_debug(f"Primary player error: {e}, falling back to ffmpeg...")
            try:
                cmd_fb = ["ffmpeg"]
                if not is_local_file:
                    cmd_fb.extend(["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "2"])
                    if use_ua:
                        cmd_fb.extend(["-user_agent", ua_str])
                cmd_fb.extend(buf_ffmpeg)
                cmd_fb.extend(["-i", url.replace("file://", ""), "-vn", "-f", "alsa", "default"])
                
                self.process = subprocess.Popen(
                    cmd_fb,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    preexec_fn=os.setsid
                )
                return True
            except Exception as e2:
                log_debug(f"Playback failed: {e2}")
                self.stop(unmute_dvb=True)
                return False

    def stop(self, unmute_dvb=True):
        self.kill_all_players()
        self.current_url = None
        self.current_name = None
        self.current_delay = 0.0
        self.is_active = False

        if unmute_dvb:
            self.mute_dvb(False)
        log_debug("Audio stopped & DVB sound restored.")

    def is_playing(self):
        return self.is_active


# ==========================================
# Universal Playlist / Folder Parser
# ==========================================
def parse_m3u(content):
    """Parse M3U / M3U8 playlist content into categories and streams."""
    categories = {}
    current_cat = "Channels"
    current_name = ""
    
    lines = content.splitlines()
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith("#EXTINF:"):
            # Extract group-title
            group_name = "Channels"
            if 'group-title="' in line:
                try:
                    group_name = line.split('group-title="')[1].split('"')[0]
                except Exception:
                    pass
            elif "group-title=" in line:
                try:
                    group_name = line.split('group-title=')[1].split(',')[0].strip()
                except Exception:
                    pass
            current_cat = group_name if group_name else "Channels"
            
            # Extract channel title
            if "," in line:
                current_name = line.split(",", 1)[1].strip()
            else:
                current_name = f"Stream {len(categories.get(current_cat, [])) + 1}"
        elif not line.startswith("#"):
            url = line
            if not current_name:
                current_name = f"Stream {len(categories.get(current_cat, [])) + 1}"
            if current_cat not in categories:
                categories[current_cat] = []
            categories[current_cat].append({
                "name": current_name,
                "display_name": current_name,
                "url": url
            })
            current_name = ""
    return categories


def parse_txt(content):
    """Parse TXT playlist with lines formatted as Name,URL or Name:URL."""
    categories = {"Channels": []}
    current_cat = "Channels"
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            current_cat = line[1:-1].strip()
            if current_cat not in categories:
                categories[current_cat] = []
            continue
        delimiter = None
        if "," in line:
            delimiter = ","
        elif "|" in line:
            delimiter = "|"
        elif "::" in line:
            delimiter = "::"
        elif ":" in line and "http" not in line[:line.find(":")]:
            delimiter = ":"
            
        if delimiter:
            parts = line.split(delimiter, 1)
            name = parts[0].strip()
            url = parts[1].strip()
        else:
            name = os.path.basename(line)
            url = line
            
        if current_cat not in categories:
            categories[current_cat] = []
        categories[current_cat].append({
            "name": name,
            "display_name": name,
            "url": url
        })
    return categories


def load_playlist(custom_path=None):
    """Universal playlist and audio folder loader."""
    path = custom_path or config.plugins.AudioPlus.playlist_path.value
    if not path or not os.path.exists(path):
        detected = get_detected_playlists()
        if detected:
            path = detected[0]

    categories = {}
    if os.path.exists(path):
        # Case 1: Path is a directory containing audio files or playlist files
        if os.path.isdir(path):
            dir_name = os.path.basename(os.path.normpath(path)) or "Local Audio"
            audio_exts = (".mp3", ".aac", ".wav", ".ogg", ".flac", ".m4a", ".ts", ".m3u", ".m3u8")
            local_streams = []
            
            try:
                for entry in sorted(os.listdir(path)):
                    full_p = os.path.join(path, entry)
                    if os.path.isfile(full_p):
                        lower_name = entry.lower()
                        if lower_name.endswith((".json", ".m3u", ".m3u8", ".txt")):
                            sub_cats = load_playlist(full_p)
                            for k, v in sub_cats.items():
                                categories[k] = v
                        elif lower_name.endswith(audio_exts):
                            clean_name = os.path.splitext(entry)[0]
                            local_streams.append({
                                "name": clean_name,
                                "display_name": clean_name,
                                "url": full_p
                            })
                if local_streams:
                    categories[f"Folder: {dir_name}"] = local_streams
            except Exception as e:
                log_debug(f"Error reading directory {path}: {e}")

        # Case 2: Path is a JSON file
        elif path.lower().endswith(".json"):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                
                if isinstance(data, dict):
                    for cat_name, cat_content in data.items():
                        if isinstance(cat_content, dict):
                            streams = cat_content.get("streams") or cat_content.get("channels") or cat_content.get("playlist") or []
                            if isinstance(streams, list):
                                categories[cat_name] = streams
                        elif isinstance(cat_content, list):
                            categories[cat_name] = cat_content
                elif isinstance(data, list):
                    categories["Playlist"] = data
            except Exception as e:
                log_debug(f"Error parsing JSON playlist {path}: {e}")

        # Case 3: Path is an M3U / M3U8 file
        elif path.lower().endswith((".m3u", ".m3u8")):
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                categories = parse_m3u(content)
            except Exception as e:
                log_debug(f"Error parsing M3U playlist {path}: {e}")

        # Case 4: Path is a TXT or other text playlist
        elif path.lower().endswith(".txt"):
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                categories = parse_txt(content)
            except Exception as e:
                log_debug(f"Error parsing TXT playlist {path}: {e}")

    if not categories:
        categories = {
            "WORLD CUP(FOX FM)": [
                {"name": f"FOX {i}", "display_name": f"FOX {i}", "url": ""} for i in range(1, 5)
            ],
            "RADIO": [
                {"name": ch, "display_name": ch, "url": "http://qurango.net/radio/tarteel"} for ch in [
                    "Egypt quran Karem", "Radio Mars", "Radio RMC", "Delta FM", "Radio Ajyal", "Radio Hadara ps"
                ]
            ],
            "Playlist": [
                {"name": "TEST", "display_name": "TEST", "url": "http://qurango.net/radio/tarteel"}
            ]
        }
    return categories


# ==========================================
# AudioPlus File & Folder Browser Screen
# ==========================================
class FileBrowserList(MenuList):
    def __init__(self, list_items, enableWrapAround=True):
        MenuList.__init__(self, list_items, enableWrapAround, eListboxPythonMultiContent)
        self.l.setFont(0, gFont("Regular", 26))
        self.l.setFont(1, gFont("Regular", 22))
        self.l.setItemHeight(56)


def build_file_entry(item_type, name, full_path, icon_png=None):
    res = [(item_type, full_path, name)]
    
    badge_text = "[DIR]" if item_type == "dir" else ("[FILE]" if item_type == "file" else "[UP]")
    badge_color = 0x0038bdf8 if item_type == "dir" else (0x0010b981 if item_type == "file" else 0x00f59e0b)
    
    res.append(
        MultiContentEntryText(
            pos=(20, 8),
            size=(100, 38),
            font=1,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text=badge_text,
            color=badge_color,
            color_sel=0x00ffffff
        )
    )
    res.append(
        MultiContentEntryText(
            pos=(130, 6),
            size=(1320, 42),
            font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text=name,
            color=0x00f8fafc,
            color_sel=0x00ffffff
        )
    )
    return res


class AudioPlusFileBrowser(Screen):
    skin = f"""
    <screen name="AudioPlusFileBrowser" position="160,100" size="1600,880" flags="wfNoBorder" backgroundColor="#180f172a">
        <eLabel position="0,0" size="1600,880" backgroundColor="#121824" cornerRadius="16" zPosition="-1" />
        
        <!-- Header Title Bar -->
        <eLabel position="0,0" size="1600,85" backgroundColor="#1a0f172a" zPosition="0" />
        <eLabel position="0,85" size="1600,2" backgroundColor="#00334155" zPosition="1" />
        <widget name="title_label" position="0,20" size="1600,45" font="SetrixHD; 32" halign="center" foregroundColor="#00ffffff" transparent="1" zPosition="2" />

        <!-- Current Path Bar -->
        <eLabel position="40,100" size="1520,50" backgroundColor="#1e293b" cornerRadius="10" zPosition="0" />
        <widget name="current_path_label" position="60,105" size="1480,40" font="Regular; 24" foregroundColor="#0038bdf8" transparent="1" zPosition="2" />

        <!-- Files List -->
        <widget name="file_list" position="40,165" size="1520,580" selectionPixmap="{os.path.join(IMG_PATH, 'setup_card_sel.png')}" scrollbarSlidercolor="#0038bdf8" scrollbarWidth="6" transparent="1" zPosition="2" />

        <!-- Bottom Footer Bar -->
        <eLabel position="0,770" size="1600,110" backgroundColor="#1a0f172a" zPosition="0" />
        <eLabel position="0,770" size="1600,2" backgroundColor="#00334155" zPosition="1" />

        <!-- Green Button: Select -->
        <widget name="btn_select_pic" position="140,800" size="180,50" alphatest="blend" zPosition="2" />
        <eLabel position="140,800" size="180,50" text="Select" font="Regular; 24" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="3" />

        <!-- Red Button: Cancel -->
        <widget name="btn_cancel_pic" position="350,800" size="180,50" alphatest="blend" zPosition="2" />
        <eLabel position="350,800" size="180,50" text="Cancel" font="Regular; 24" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="3" />

        <!-- Yellow Button: /etc/enigma2 -->
        <eLabel position="650,805" size="280,42" text="[YELLOW] /etc/enigma2" font="Regular; 22" halign="center" valign="center" foregroundColor="#00f59e0b" transparent="1" zPosition="2" />

        <!-- Blue Button: /media/hdd -->
        <eLabel position="960,805" size="260,42" text="[BLUE] /media/hdd" font="Regular; 22" halign="center" valign="center" foregroundColor="#0038bdf8" transparent="1" zPosition="2" />
    </screen>
    """

    def __init__(self, session, initial_path="/etc/enigma2"):
        Screen.__init__(self, session)
        self.session = session
        
        if initial_path and os.path.exists(initial_path):
            if os.path.isfile(initial_path):
                self.current_dir = os.path.dirname(initial_path)
            else:
                self.current_dir = initial_path
        else:
            self.current_dir = "/etc/enigma2"

        self["title_label"] = Label("Select Playlist File or Folder")
        self["current_path_label"] = Label(f"Current Directory: {self.current_dir}")
        self["btn_select_pic"] = Pixmap()
        self["btn_cancel_pic"] = Pixmap()

        self.list_items = []
        self["file_list"] = FileBrowserList([])

        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions", "DirectionActions"], {
            "ok": self.key_ok,
            "save": self.key_select_current,
            "green": self.key_select_current,
            "cancel": self.key_cancel,
            "red": self.key_cancel,
            "yellow": self.key_goto_enigma2,
            "blue": self.key_goto_hdd,
        }, -1)

        self.onLayoutFinish.append(self.layout_finished)

    def layout_finished(self):
        p_save = os.path.join(IMG_PATH, "btn_save.png")
        if os.path.exists(p_save):
            self["btn_select_pic"].instance.setPixmap(loadPNG(p_save))

        p_cancel = os.path.join(IMG_PATH, "btn_cancel.png")
        if os.path.exists(p_cancel):
            self["btn_cancel_pic"].instance.setPixmap(loadPNG(p_cancel))

        self.refresh_directory()

    def refresh_directory(self):
        self["current_path_label"].setText(f"Current Directory: {self.current_dir}")
        entries = []

        if self.current_dir != "/" and os.path.exists(os.path.dirname(self.current_dir)):
            parent = os.path.dirname(self.current_dir)
            entries.append(build_file_entry("parent", ".. (Parent Directory)", parent))

        valid_exts = (".json", ".m3u", ".m3u8", ".txt", ".mp3", ".aac", ".wav", ".flac", ".ogg", ".m4a")

        dirs = []
        files = []

        try:
            for item in sorted(os.listdir(self.current_dir)):
                if item.startswith(".") and item != "..":
                    continue
                full_path = os.path.join(self.current_dir, item)
                if os.path.isdir(full_path):
                    dirs.append((item, full_path))
                elif os.path.isfile(full_path):
                    if item.lower().endswith(valid_exts):
                        files.append((item, full_path))
        except Exception as e:
            log_debug(f"Error reading directory in file browser: {e}")

        for d_name, d_path in dirs:
            entries.append(build_file_entry("dir", f"📁  {d_name}", d_path))

        for f_name, f_path in files:
            entries.append(build_file_entry("file", f_name, f_path))

        self.list_items = entries
        self["file_list"].setList(self.list_items)
        if entries:
            self["file_list"].moveToIndex(0)

    def key_ok(self):
        selected = self["file_list"].getCurrent()
        if not selected:
            return
        item_type, full_path, name = selected[0]
        if item_type == "parent":
            self.current_dir = full_path
            self.refresh_directory()
        elif item_type == "dir":
            self.current_dir = full_path
            self.refresh_directory()
        elif item_type == "file":
            self.close(full_path)

    def key_select_current(self):
        selected = self["file_list"].getCurrent()
        if selected:
            item_type, full_path, name = selected[0]
            if item_type == "file":
                self.close(full_path)
                return
            elif item_type == "dir":
                self.close(full_path)
                return
        self.close(self.current_dir)

    def key_goto_enigma2(self):
        if os.path.exists("/etc/enigma2"):
            self.current_dir = "/etc/enigma2"
            self.refresh_directory()

    def key_goto_hdd(self):
        if os.path.exists("/media/hdd"):
            self.current_dir = "/media/hdd"
        elif os.path.exists("/media/usb"):
            self.current_dir = "/media/usb"
        elif os.path.exists("/media"):
            self.current_dir = "/media"
        self.refresh_directory()

    def key_cancel(self):
        self.close(None)


# ==========================================
# Setup Screen (Image 1 - Exact MyCustomSkin Form)
# ==========================================
class SetupList(MenuList):
    def __init__(self, list_items, enableWrapAround=True):
        MenuList.__init__(self, list_items, enableWrapAround, eListboxPythonMultiContent)
        self.l.setFont(0, gFont("Regular", 27))
        self.l.setFont(1, gFont("Regular", 25))
        self.l.setItemHeight(60)


def build_setup_entry(item_type, key, label, value):
    res = [(item_type, key, label, value)]
    
    if item_type == "header":
        res.append(
            MultiContentEntryText(
                pos=(15, 10),
                size=(1400, 40),
                font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=label,
                color=0x0038bdf8,
                color_sel=0x0038bdf8
            )
        )
    else:
        res.append(
            MultiContentEntryText(
                pos=(25, 10),
                size=(600, 42),
                font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=label,
                color=0x00f8fafc,
                color_sel=0x00ffffff
            )
        )
        res.append(
            MultiContentEntryText(
                pos=(650, 10),
                size=(820, 42),
                font=1,
                flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                text=str(value),
                color=0x0094a3b8,
                color_sel=0x00ffffff
            )
        )
    return res


class AudioPlusSetupScreen(Screen):
    skin = f"""
    <screen name="AudioPlusSetupScreen" position="160,100" size="1600,880" flags="wfNoBorder" backgroundColor="#180f172a">
        <eLabel position="0,0" size="1600,880" backgroundColor="#121824" cornerRadius="16" zPosition="-1" />
        
        <!-- Header Title Bar -->
        <eLabel position="0,0" size="1600,85" backgroundColor="#1a0f172a" zPosition="0" />
        <eLabel position="0,85" size="1600,2" backgroundColor="#00334155" zPosition="1" />
        <widget name="title_label" position="0,22" size="1600,45" font="SetrixHD; 34" halign="center" foregroundColor="#00ffffff" transparent="1" zPosition="2" />

        <!-- Setup Items List -->
        <widget name="setup_list" position="40,100" size="1520,660" selectionPixmap="{os.path.join(IMG_PATH, 'setup_card_sel.png')}" scrollbarSlidercolor="#0038bdf8" scrollbarWidth="6" transparent="1" zPosition="2" />

        <!-- Bottom Footer Bar -->
        <eLabel position="0,780" size="1600,100" backgroundColor="#1a0f172a" zPosition="0" />
        <eLabel position="0,780" size="1600,2" backgroundColor="#00334155" zPosition="1" />

        <!-- Save Button (Green) -->
        <widget name="btn_save_pic" position="570,804" size="180,50" alphatest="blend" zPosition="2" />
        <eLabel position="570,804" size="180,50" text="Save" font="Regular; 24" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="3" />

        <!-- Cancel Button (Red) -->
        <widget name="btn_cancel_pic" position="780,804" size="180,50" alphatest="blend" zPosition="2" />
        <eLabel position="780,804" size="180,50" text="Cancel" font="Regular; 24" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="3" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self["title_label"] = Label("AudioPlus Setup")
        self["btn_save_pic"] = Pixmap()
        self["btn_cancel_pic"] = Pixmap()

        self.detected_playlists = get_detected_playlists()
        current_path = config.plugins.AudioPlus.playlist_path.value
        if current_path not in self.detected_playlists:
            self.detected_playlists.insert(0, current_path)

        self.settings_data = [
            ("header", None, "Playback & Network", ""),
            ("setting", "playlist_path", "Playlist Path", config.plugins.AudioPlus.playlist_path.value),
            ("setting", "audio_player", "Audio Player", config.plugins.AudioPlus.audio_player.value),
            ("setting", "use_user_agent", "Use user-agent", config.plugins.AudioPlus.use_user_agent.value),
            ("setting", "startup_buffer", "Startup buffer", config.plugins.AudioPlus.startup_buffer.value),
            
            ("header", None, "Timeshift", ""),
            ("setting", "timeshift_storage", "Timeshift Storage", config.plugins.AudioPlus.timeshift_storage.value),
            ("setting", "timeshift_remember", "Timeshift remember", config.plugins.AudioPlus.timeshift_remember.value),
            
            ("header", None, "Display & Menu", ""),
            ("setting", "show_in_mainmenu", "Show Plugin in main menu", config.plugins.AudioPlus.show_in_mainmenu.value),
            ("setting", "show_picons", "Show Picons", config.plugins.AudioPlus.show_picons.value),
            ("setting", "show_jsc_epg", "Show jsc EPG", config.plugins.AudioPlus.show_jsc_epg.value),
            ("setting", "show_preview_art", "Show preview art", config.plugins.AudioPlus.show_preview_art.value),
            ("setting", "skin_style", "Skin Style", config.plugins.AudioPlus.skin_style.value),
        ]

        self.options_choices = {
            "playlist_path": self.detected_playlists,
            "audio_player": ["Auto", "FFmpeg", "GStreamer", "eXteplayer3", "ALSA"],
            "use_user_agent": ["No", "Yes"],
            "startup_buffer": ["Balanced", "Safe(higher startup delay)"],
            "timeshift_storage": ["Hard Disk", "RAM"],
            "timeshift_remember": ["Yes", "No"],
            "show_in_mainmenu": ["No", "Yes"],
            "show_picons": ["Yes", "No"],
            "show_jsc_epg": ["Yes", "No"],
            "show_preview_art": ["No", "Yes"],
            "skin_style": ["MyCustomSkin", "Dark Modern", "Minimal"]
        }

        self.list_items = []
        self["setup_list"] = SetupList([])

        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions", "DirectionActions"], {
            "save": self.key_save,
            "cancel": self.key_cancel,
            "green": self.key_save,
            "red": self.key_cancel,
            "ok": self.key_ok,
            "left": self.key_left,
            "right": self.key_right,
        }, -1)

        self.onLayoutFinish.append(self.layout_finished)

    def layout_finished(self):
        p_save = os.path.join(IMG_PATH, "btn_save.png")
        if os.path.exists(p_save):
            self["btn_save_pic"].instance.setPixmap(loadPNG(p_save))

        p_cancel = os.path.join(IMG_PATH, "btn_cancel.png")
        if os.path.exists(p_cancel):
            self["btn_cancel_pic"].instance.setPixmap(loadPNG(p_cancel))

        self.refresh_list()
        self["setup_list"].moveToIndex(1)

    def refresh_list(self):
        entries = []
        for item_type, key, label, value in self.settings_data:
            entries.append(build_setup_entry(item_type, key, label, value))
        self.list_items = entries
        self["setup_list"].setList(self.list_items)

    def key_ok(self):
        idx = self["setup_list"].getSelectedIndex()
        if idx is None or idx < 0 or idx >= len(self.settings_data):
            return
        item_type, key, label, value = self.settings_data[idx]
        
        # When user clicks OK on Playlist Path, open full Interactive File Browser
        if key == "playlist_path":
            self.session.openWithCallback(self.file_browser_callback, AudioPlusFileBrowser, initial_path=value)
        else:
            self.change_value(1)

    def file_browser_callback(self, selected_path):
        if selected_path:
            log_debug(f"File browser selected path: {selected_path}")
            for idx, (item_type, key, label, value) in enumerate(self.settings_data):
                if key == "playlist_path":
                    self.settings_data[idx] = (item_type, key, label, selected_path)
                    if selected_path not in self.detected_playlists:
                        self.detected_playlists.insert(0, selected_path)
                        self.options_choices["playlist_path"] = self.detected_playlists
                    self.refresh_list()
                    self["setup_list"].moveToIndex(idx)
                    break

    def key_left(self):
        self.change_value(-1)

    def key_right(self):
        self.change_value(1)

    def change_value(self, step):
        idx = self["setup_list"].getSelectedIndex()
        if idx is None or idx < 0 or idx >= len(self.settings_data):
            return
        item_type, key, label, value = self.settings_data[idx]
        if item_type == "header" or key not in self.options_choices:
            return
        choices = self.options_choices[key]
        try:
            curr_idx = choices.index(value)
        except ValueError:
            curr_idx = 0
        new_idx = (curr_idx + step) % len(choices)
        new_val = choices[new_idx]
        self.settings_data[idx] = (item_type, key, label, new_val)
        self.refresh_list()
        self["setup_list"].moveToIndex(idx)

    def key_save(self):
        for item_type, key, label, value in self.settings_data:
            if item_type == "setting" and hasattr(config.plugins.AudioPlus, key):
                cfg_elem = getattr(config.plugins.AudioPlus, key)
                cfg_elem.value = value
                cfg_elem.save()
        config.plugins.AudioPlus.save()

        # Handle Timeshift storage folder preparation
        if config.plugins.AudioPlus.timeshift_storage.value == "Hard Disk":
            try:
                os.makedirs("/media/hdd/timeshift", exist_ok=True)
            except Exception:
                pass

        self.close(True)

    def key_cancel(self):
        self.close(False)


# ==========================================
# Main Screen (Floating Categories & Channels)
# ==========================================
class AudioPlusList(MenuList):
    def __init__(self, list_items, enableWrapAround=True):
        MenuList.__init__(self, list_items, enableWrapAround, eListboxPythonMultiContent)
        self.l.setFont(0, gFont("Regular", 27))
        self.l.setFont(1, gFont("Regular", 20))
        self.l.setItemHeight(76)


def build_list_entry(title, subtext="", icon_png=None, badge_png=None, stream_url="", raw_name=""):
    res = [(title, subtext, stream_url, raw_name or title)]
    
    # 1. Left Icon / Badge
    if icon_png:
        res.append(
            MultiContentEntryPixmapAlphaBlend(
                pos=(22, 14),
                size=(48, 48),
                png=icon_png
            )
        )
    elif badge_png:
        res.append(
            MultiContentEntryPixmapAlphaBlend(
                pos=(16, 15),
                size=(68, 46),
                png=badge_png
            )
        )

    # 2. Item Title Text
    text_x = 90 if (icon_png or badge_png) else 25
    text_width = 440 if (icon_png or badge_png) else 510
    res.append(
        MultiContentEntryText(
            pos=(text_x, 14),
            size=(text_width, 48),
            font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text=title,
            color=0x00cbd5e1,
            color_sel=0x00ffffff
        )
    )
        
    return res


class AudioPlusScreen(Screen):
    skin = f"""
    <screen name="AudioPlusScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent">
        <!-- Header Title Bar -->
        <widget name="title_label" position="60,35" size="1200,50" font="SetrixHD; 36" foregroundColor="#00ffffff" transparent="1" zPosition="2" />
        <widget name="status_label" position="1300,40" size="560,40" font="Regular; 28" halign="right" foregroundColor="#0010b981" transparent="1" zPosition="2" />

        <!-- Left List Container Box -->
        <eLabel position="48,138" size="578,774" backgroundColor="#121824" cornerRadius="14" zPosition="0" />
        <eLabel position="48,138" size="578,2" backgroundColor="#00334155" zPosition="1" />

        <!-- Left Channels/Categories Card List -->
        <widget name="audio_list" position="60,150" size="554,750" selectionPixmap="{os.path.join(IMG_PATH, 'card_selected.png')}" scrollbarMode="showNever" transparent="1" zPosition="2" />

        <!-- Optional Right 3D Visual Box -->
        <widget name="main_art" position="680,120" size="1180,560" alphatest="blend" zPosition="2" />

        <!-- JSC / beIN Sports Live EPG Match Guide Box -->
        <widget name="epg_box_bg" position="680,695" size="1180,210" backgroundColor="#1a121824" cornerRadius="14" zPosition="0" />
        <widget name="epg_box_border" position="680,695" size="1180,2" backgroundColor="#00334155" zPosition="1" />
        <widget name="epg_box_title" position="710,710" size="1120,36" font="Regular; 24" foregroundColor="#0038bdf8" transparent="1" zPosition="2" />
        <widget name="epg_match_title" position="710,752" size="1120,48" font="SetrixHD; 30" foregroundColor="#00ffffff" transparent="1" zPosition="2" />
        <widget name="epg_match_details" position="710,810" size="1120,36" font="Regular; 22" foregroundColor="#0094a3b8" transparent="1" zPosition="2" />

        <!-- Floating Bottom Bar -->
        <eLabel position="40,940" size="1840,92" backgroundColor="#1a121824" cornerRadius="14" zPosition="0" />
        <eLabel position="40,940" size="1840,2" backgroundColor="#00334155" zPosition="1" />

        <!-- 1. Reset Button (Green) -->
        <widget name="btn_reset_pic" position="55,960" size="180,50" alphatest="blend" zPosition="2" />
        <eLabel position="55,960" size="180,50" text="Reset" font="Regular; 22" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="3" />

        <!-- 2. Reset Audio Delay Button (Yellow) -->
        <widget name="btn_reset_audio_delay_pic" position="250,960" size="230,50" alphatest="blend" zPosition="2" />
        <eLabel position="250,960" size="230,50" text="Reset Audio Delay" font="Regular; 22" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="3" />

        <!-- 3. Reset Video Delay Button (Cyan) -->
        <widget name="btn_reset_video_delay_pic" position="495,960" size="230,50" alphatest="blend" zPosition="2" />
        <eLabel position="495,960" size="230,50" text="Reset Video Delay" font="Regular; 22" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1" zPosition="3" />

        <!-- Quick Help Keys -->
        <eLabel position="745,972" size="430,32" text="[4/6] Audio Delay   [◄/►] TS   [PLAY] Apply" font="Regular; 19" foregroundColor="#0064748b" transparent="1" zPosition="2" />

        <!-- Audio Delay -->
        <widget name="audio_delay_label" position="1185,968" size="220,38" font="Regular; 26" halign="right" foregroundColor="#00f8fafc" transparent="1" zPosition="2" />

        <!-- TS Delay -->
        <widget name="ts_delay_label" position="1410,968" size="260,38" font="Regular; 26" halign="right" foregroundColor="#0038bdf8" transparent="1" zPosition="2" />

        <!-- Index / Count -->
        <widget name="count_label" position="1680,968" size="180,38" font="Regular; 26" halign="right" foregroundColor="#0094a3b8" transparent="1" zPosition="2" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self.audio_engine = AudioEngine.get_instance()
        self.epg_manager = JscEpgManager.get_instance()
        self.current_category = None
        self.current_stream_url = ""
        self.current_stream_name = ""
        
        self.audio_delay = 0.0
        
        # Timeshift remember handling
        if config.plugins.AudioPlus.timeshift_remember.value == "Yes":
            try:
                self.ts_delay = float(config.plugins.AudioPlus.saved_ts_delay.value)
            except Exception:
                self.ts_delay = 5.0
        else:
            self.ts_delay = 5.0
            
        self.last_key_time = 0.0

        # Timeshift state & timer (500ms precision ticks)
        self.ts_timer = eTimer()
        self.ts_timer.callback.append(self.ts_timer_tick)
        self.ts_countdown_remaining = 0.0
        self.is_ts_active = False

        # Audio stream delay countdown timer (500ms precision ticks)
        self.audio_delay_timer = eTimer()
        self.audio_delay_timer.callback.append(self.audio_delay_timer_tick)
        self.audio_countdown_remaining = 0.0
        self.is_audio_delay_active = False

        self.categories_data = load_playlist()

        self.icon_radio = loadPNG(os.path.join(IMG_PATH, "icon_radio.png"))
        self.icon_play = loadPNG(os.path.join(IMG_PATH, "icon_play.png"))
        self.card_normal = loadPNG(os.path.join(IMG_PATH, "card_normal.png"))

        self["title_label"] = Label("AudioPlus")
        self["status_label"] = Label("Running" if self.audio_engine.is_playing() else "Stopped")
        self["audio_delay_label"] = Label("Audio Delay: 0.0")
        self["ts_delay_label"] = Label(f"TS Delay: {self.ts_delay}")
        self["count_label"] = Label("1/1")
        
        self["main_art"] = Pixmap()
        self["btn_reset_pic"] = Pixmap()
        self["btn_reset_audio_delay_pic"] = Pixmap()
        self["btn_reset_video_delay_pic"] = Pixmap()
        
        # EPG Widgets
        self["epg_box_bg"] = Label("")
        self["epg_box_border"] = Label("")
        self["epg_box_title"] = Label("📺 Live Event & Match Guide (beIN / JSC)")
        self["epg_match_title"] = Label("Select a channel to view live match event")
        self["epg_match_details"] = Label("AudioPlus real-time sports synchronization")
        
        self.list_items = []
        self["audio_list"] = AudioPlusList([])
        self["audio_list"].onSelectionChanged.append(self.on_selection_changed)

        # Unified single ActionMap to prevent double firing
        self["actions"] = ActionMap(["AudioPlusActions"], {
            "ok": self.key_ok,
            "cancel": self.key_exit,
            "red": self.key_exit,
            "green": self.key_reset,
            "yellow": self.key_reset_audio_delay,
            "blue": self.key_reset_video_delay,
            "audioDelayMinus": self.key_audio_delay_minus,
            "audioDelayPlus": self.key_audio_delay_plus,
            "applyAudioDelay": self.key_apply_audio_delay,
            "resetAudio": self.key_reset,
            "resetAudioDelay": self.key_reset_audio_delay,
            "resetTsDelay": self.key_reset_video_delay,
            "tsDelayMinus": self.key_ts_minus,
            "tsDelayPlus": self.key_ts_plus,
            "left": self.key_ts_minus,
            "right": self.key_ts_plus,
            "up": self.key_up,
            "down": self.key_down,
            "menu": self.key_menu,
            "pause": self.key_pause_timeshift,
            "stop": self.key_reset,
        }, -1)

        self.onLayoutFinish.append(self.layout_finished)
        self.onClose.append(self.on_screen_close)

    def layout_finished(self):
        if config.plugins.AudioPlus.show_preview_art.value == "Yes":
            art_path = os.path.join(IMG_PATH, "main_cube.png")
            if os.path.exists(art_path):
                self["main_art"].instance.setPixmap(loadPNG(art_path))
                self["main_art"].show()
        else:
            self["main_art"].hide()

        p_reset = os.path.join(IMG_PATH, "btn_reset.png")
        if os.path.exists(p_reset):
            self["btn_reset_pic"].instance.setPixmap(loadPNG(p_reset))

        p_rad = os.path.join(IMG_PATH, "btn_reset_audio_delay.png")
        if os.path.exists(p_rad):
            self["btn_reset_audio_delay_pic"].instance.setPixmap(loadPNG(p_rad))

        p_rvd = os.path.join(IMG_PATH, "btn_reset_video_delay.png")
        if os.path.exists(p_rvd):
            self["btn_reset_video_delay_pic"].instance.setPixmap(loadPNG(p_rvd))

        self.update_epg_visibility()
        self.show_categories()

    def update_epg_visibility(self):
        show_epg = config.plugins.AudioPlus.show_jsc_epg.value == "Yes"
        if show_epg:
            self["epg_box_bg"].show()
            self["epg_box_border"].show()
            self["epg_box_title"].show()
            self["epg_match_title"].show()
            self["epg_match_details"].show()
        else:
            self["epg_box_bg"].hide()
            self["epg_box_border"].hide()
            self["epg_box_title"].hide()
            self["epg_match_title"].hide()
            self["epg_match_details"].hide()

    def find_picon(self, channel_name):
        """Lookup picon in local images and standard Enigma2 picon directories."""
        if config.plugins.AudioPlus.show_picons.value != "Yes":
            return None

        clean_name = re.sub(r'[^a-zA-Z0-9]', '', channel_name.lower())
        picon_paths = [
            IMG_PATH,
            "/etc/picon",
            "/media/hdd/picon",
            "/media/usb/picon",
            "/usr/share/enigma2/picon",
            "/picon"
        ]
        
        for p_dir in picon_paths:
            if os.path.exists(p_dir):
                target = os.path.join(p_dir, f"{clean_name}.png")
                if os.path.exists(target):
                    try:
                        return loadPNG(target)
                    except Exception:
                        pass
        return None

    def show_categories(self):
        self.current_category = None
        self["title_label"].setText("AudioPlus")
        show_picons = config.plugins.AudioPlus.show_picons.value == "Yes"
        
        entries = []
        cat_names = list(self.categories_data.keys())
        for idx, cat in enumerate(cat_names):
            badge_png = None
            if show_picons:
                badge_index = (idx % 26) + 1
                badge_file = os.path.join(IMG_PATH, f"badge_{badge_index}.png")
                badge_png = loadPNG(badge_file) if os.path.exists(badge_file) else None
            
            entries.append(build_list_entry(
                title=cat,
                subtext="",
                icon_png=None,
                badge_png=badge_png,
                raw_name=cat
            ))
        
        self.list_items = entries
        self["audio_list"].setList(self.list_items)
        self.update_count_label()
        
        if config.plugins.AudioPlus.show_jsc_epg.value == "Yes":
            self["epg_match_title"].setText("Select a category to browse channels")
            self["epg_match_details"].setText("beIN Sports Live EPG automatically syncs when selecting channels")

    def show_channels(self, category_name):
        self.current_category = category_name
        self["title_label"].setText(f"AudioPlus - {category_name}")
        show_picons = config.plugins.AudioPlus.show_picons.value == "Yes"
        
        channels = self.categories_data.get(category_name, [])
        entries = []
        for idx, ch in enumerate(channels):
            raw_name = ch.get("display_name") or ch.get("name") or "Unknown"
            numbered_title = f"{(idx + 1):02d}. {raw_name}"
            stream_url = ch.get("url", "")
            
            icon = None
            if show_picons:
                custom_picon = self.find_picon(raw_name)
                if custom_picon:
                    icon = custom_picon
                else:
                    icon = self.icon_play if (self.audio_engine.is_playing() and self.audio_engine.current_name == raw_name) else self.icon_radio

            entries.append(build_list_entry(
                title=numbered_title,
                subtext="",
                icon_png=icon,
                badge_png=None,
                stream_url=stream_url,
                raw_name=raw_name
            ))
        
        self.list_items = entries
        self["audio_list"].setList(self.list_items)
        self.update_count_label()
        self.update_channel_epg()

    def on_selection_changed(self):
        self.update_count_label()
        self.update_channel_epg()

    def update_channel_epg(self):
        if config.plugins.AudioPlus.show_jsc_epg.value != "Yes":
            return
            
        selected = self["audio_list"].getCurrent()
        if not selected:
            return
        item_tuple = selected[0]
        name = item_tuple[3] if len(item_tuple) > 3 else item_tuple[0]
        
        if self.current_category is not None:
            ev = self.epg_manager.get_event_for_channel(name)
            if ev:
                self["epg_match_title"].setText(ev.get("title", f"⚽ {name}"))
                self["epg_match_details"].setText(ev.get("details", "Live Sports Audio Broadcast"))
            else:
                self["epg_match_title"].setText(f"📻 {name}")
                self["epg_match_details"].setText("Live Stream Ready")

    def update_count_label(self):
        total = len(self.list_items)
        idx = self["audio_list"].getSelectedIndex()
        current = (idx + 1) if (idx is not None and total > 0) else 1
        self["count_label"].setText(f"{current}/{max(1, total)}")

    def update_delays(self):
        if self.is_audio_delay_active and self.audio_countdown_remaining > 0:
            self["audio_delay_label"].setText(f"Waiting: {self.audio_countdown_remaining}s")
        else:
            self["audio_delay_label"].setText(f"Audio Delay: {self.audio_delay}")
            
        if self.is_ts_active and self.ts_countdown_remaining > 0:
            self["ts_delay_label"].setText(f"Pausing: {self.ts_countdown_remaining}s")
        else:
            self["ts_delay_label"].setText(f"TS Delay: {self.ts_delay}")

    def update_status_indicator(self):
        if self.audio_engine.is_playing():
            self["status_label"].setText("Running")
        else:
            self["status_label"].setText("Stopped")

    def key_up(self):
        self["audio_list"].up()

    def key_down(self):
        self["audio_list"].down()

    # ==========================================
    # Audio Stream Delay Controller (0.5s Step with Debounce)
    # ==========================================
    def key_audio_delay_minus(self):
        now = time.time()
        if now - self.last_key_time < 0.20:
            return
        self.last_key_time = now

        self.audio_delay = max(0.0, round(self.audio_delay - 0.5, 1))
        log_debug(f"Audio Delay -0.5s -> {self.audio_delay}s")
        self.update_delays()

    def key_audio_delay_plus(self):
        now = time.time()
        if now - self.last_key_time < 0.20:
            return
        self.last_key_time = now

        self.audio_delay = round(self.audio_delay + 0.5, 1)
        log_debug(f"Audio Delay +0.5s -> {self.audio_delay}s")
        self.update_delays()

    def key_apply_audio_delay(self):
        log_debug(f"PLAY button pressed! Starting Audio delay of {self.audio_delay}s")
        if not self.current_stream_url:
            log_debug("No stream selected to delay.")
            return

        if self.audio_delay_timer.isActive():
            self.audio_delay_timer.stop()

        self.audio_engine.stop(unmute_dvb=False)
        self.audio_countdown_remaining = max(0.5, float(self.audio_delay))
        self.is_audio_delay_active = True
        self.update_delays()
        self.update_status_indicator()
        self.audio_delay_timer.start(500, False)

    def audio_delay_timer_tick(self):
        self.audio_countdown_remaining = max(0.0, round(self.audio_countdown_remaining - 0.5, 1))
        log_debug(f"Audio Countdown tick: {self.audio_countdown_remaining}s remaining")
        if self.audio_countdown_remaining <= 0.0:
            self.audio_delay_timer.stop()
            self.is_audio_delay_active = False
            log_debug(f"Audio delay countdown finished! Playing stream with delay...")
            self.audio_engine.play(self.current_stream_url, name=self.current_stream_name, audio_delay=0.0)
            self.update_status_indicator()
        self.update_delays()

    # ==========================================
    # Timeshift Video Delay Controller (0.5s Step with Debounce)
    # ==========================================
    def key_ts_minus(self):
        now = time.time()
        if now - self.last_key_time < 0.20:
            return
        self.last_key_time = now
        
        self.ts_delay = max(0.0, round(self.ts_delay - 0.5, 1))
        log_debug(f"TS Delay -0.5s -> {self.ts_delay}s")
        
        if config.plugins.AudioPlus.timeshift_remember.value == "Yes":
            config.plugins.AudioPlus.saved_ts_delay.value = str(self.ts_delay)
            config.plugins.AudioPlus.saved_ts_delay.save()
            config.plugins.AudioPlus.save()
            
        self.update_delays()

    def key_ts_plus(self):
        now = time.time()
        if now - self.last_key_time < 0.20:
            return
        self.last_key_time = now
        
        self.ts_delay = round(self.ts_delay + 0.5, 1)
        log_debug(f"TS Delay +0.5s -> {self.ts_delay}s")
        
        if config.plugins.AudioPlus.timeshift_remember.value == "Yes":
            config.plugins.AudioPlus.saved_ts_delay.value = str(self.ts_delay)
            config.plugins.AudioPlus.saved_ts_delay.save()
            config.plugins.AudioPlus.save()
            
        self.update_delays()

    def key_pause_timeshift(self):
        log_debug(f"PAUSE button pressed! TS Delay: {self.ts_delay}s")
        
        if self.ts_countdown_remaining > 0:
            self.ts_timer.stop()
            self.ts_countdown_remaining = 0.0
            self.is_ts_active = False
            self.resume_timeshift()
            self.update_delays()
            return

        # 1. Start timeshift on current DVB service
        service = self.session.nav.getCurrentService()
        if service:
            ts = service.timeshift()
            if ts:
                try:
                    res = ts.startTimeshift()
                    log_debug(f"service.timeshift().startTimeshift() = {res}")
                except Exception as e:
                    log_debug(f"startTimeshift error: {e}")
            
            p = service.pause()
            if p:
                try:
                    res = p.pause()
                    log_debug(f"service.pause().pause() = {res}")
                except Exception as e:
                    log_debug(f"pause() error: {e}")

        try:
            from Screens.InfoBar import InfoBar
            if InfoBar.instance:
                if hasattr(InfoBar.instance, "activateTimeshiftEndAndPause"):
                    InfoBar.instance.activateTimeshiftEndAndPause()
                elif hasattr(InfoBar.instance, "pauseService"):
                    InfoBar.instance.pauseService()
        except Exception as e:
            log_debug(f"InfoBar call error: {e}")

        # 2. Start countdown for the specified seconds (500ms intervals)
        self.ts_countdown_remaining = max(0.5, float(self.ts_delay))
        self.is_ts_active = True
        self.update_delays()
        self.ts_timer.start(500, False)
        log_debug(f"Timeshift countdown started: {self.ts_countdown_remaining}s")

    def resume_timeshift(self):
        """Unpauses timeshift video to stream with exact time lag."""
        service = self.session.nav.getCurrentService()
        if service and service.pause():
            try:
                res = service.pause().unpause()
                log_debug(f"service.pause().unpause() = {res}")
            except Exception as e:
                log_debug(f"service unpause error: {e}")

        try:
            from Screens.InfoBar import InfoBar
            if InfoBar.instance:
                if hasattr(InfoBar.instance, "unpauseService"):
                    InfoBar.instance.unpauseService()
                elif hasattr(InfoBar.instance, "playpauseService"):
                    InfoBar.instance.playpauseService()
        except Exception as e:
            log_debug(f"InfoBar unpause error: {e}")

    def ts_timer_tick(self):
        self.ts_countdown_remaining = max(0.0, round(self.ts_countdown_remaining - 0.5, 1))
        log_debug(f"TS Countdown tick: {self.ts_countdown_remaining}s remaining")
        if self.ts_countdown_remaining <= 0.0:
            self.ts_timer.stop()
            self.resume_timeshift()
            self.is_ts_active = True
            log_debug(f"Timeshift resumed! Live video is now delayed by {self.ts_delay}s.")
        self.update_delays()

    # ==========================================
    # Channel Selection & Actions
    # ==========================================
    def key_ok(self):
        selected = self["audio_list"].getCurrent()
        if not selected:
            return
        item_tuple = selected[0]
        title = item_tuple[0]
        raw_name = item_tuple[3] if len(item_tuple) > 3 else title

        if self.current_category is None:
            self.show_channels(title)
        else:
            stream_url = item_tuple[2] if len(item_tuple) > 2 else ""
            if not stream_url:
                stream_url = "http://qurango.net/radio/tarteel"

            if self.audio_engine.is_playing() and self.audio_engine.current_name == raw_name:
                self.audio_engine.stop(unmute_dvb=True)
                self.current_stream_url = ""
                self.current_stream_name = ""
                self.update_status_indicator()
            else:
                self.current_stream_url = stream_url
                self.current_stream_name = raw_name
                self["title_label"].setText(f"{self.current_category}: {title}")
                self.audio_engine.play(stream_url, name=raw_name, audio_delay=0.0)
                self.update_status_indicator()
            
            self.show_channels(self.current_category)

    def key_exit(self):
        if self.current_category is not None:
            self.show_categories()
        else:
            self.close()

    def key_reset(self):
        # Stop stream and restore original DVB channel audio
        self.audio_engine.stop(unmute_dvb=True)
        self.current_stream_url = ""
        self.current_stream_name = ""

        # Cancel audio delay countdown
        self.audio_delay_timer.stop()
        self.audio_countdown_remaining = 0.0
        self.is_audio_delay_active = False

        # Cancel timeshift pause if running
        self.ts_timer.stop()
        self.ts_countdown_remaining = 0.0
        self.is_ts_active = False
        self.resume_live_tv_clean()

        self.audio_delay = 0.0
        if config.plugins.AudioPlus.timeshift_remember.value == "Yes":
            try:
                self.ts_delay = float(config.plugins.AudioPlus.saved_ts_delay.value)
            except Exception:
                self.ts_delay = 5.0
        else:
            self.ts_delay = 5.0

        self.update_status_indicator()
        self.update_delays()

    def key_reset_audio_delay(self):
        log_debug("Reset Audio Delay action triggered -> 0.0s")
        self.audio_delay = 0.0
        if self.audio_delay_timer.isActive():
            self.audio_delay_timer.stop()
        self.audio_countdown_remaining = 0.0
        self.is_audio_delay_active = False
        
        # If playing, restart immediately with zero delay
        if self.current_stream_url and self.audio_engine.is_playing():
            self.audio_engine.play(self.current_stream_url, name=self.current_stream_name, audio_delay=0.0)
            
        self.update_status_indicator()
        self.update_delays()

    def key_reset_video_delay(self):
        log_debug("Reset Video (Timeshift) Delay action triggered -> 0.0s")
        self.ts_delay = 0.0
        if config.plugins.AudioPlus.timeshift_remember.value == "Yes":
            config.plugins.AudioPlus.saved_ts_delay.value = "0.0"
            config.plugins.AudioPlus.saved_ts_delay.save()
            config.plugins.AudioPlus.save()
            
        if self.ts_timer.isActive():
            self.ts_timer.stop()
        self.ts_countdown_remaining = 0.0
        self.is_ts_active = False
        self.resume_live_tv_clean()
        self.update_delays()

    def resume_live_tv_clean(self):
        log_debug("Silently resetting timeshift and restoring live TV...")
        service = self.session.nav.getCurrentService()
        if service:
            try:
                p = service.pause()
                if p:
                    p.unpause()
            except Exception as e:
                log_debug(f"unpause error: {e}")
            
            try:
                ts = service.timeshift()
                if ts and ts.isTimeshiftActive():
                    # Stop timeshift silently with 1 (discard recording without prompt)
                    ts.stopTimeshift(1)
            except Exception as e:
                log_debug(f"ts.stopTimeshift(1) error: {e}")

        try:
            from Screens.InfoBar import InfoBar
            if InfoBar.instance:
                if hasattr(InfoBar.instance, "timeshift_was_activated"):
                    InfoBar.instance.timeshift_was_activated = False
                if hasattr(InfoBar.instance, "timeshift_active"):
                    InfoBar.instance.timeshift_active = False
                if hasattr(InfoBar.instance, "pts_cleanTimeshift"):
                    InfoBar.instance.pts_cleanTimeshift()
                elif hasattr(InfoBar.instance, "ptsStopTimeshift"):
                    InfoBar.instance.ptsStopTimeshift()
                elif hasattr(InfoBar.instance, "stopTimeshift"):
                    try:
                        InfoBar.instance.stopTimeshift(True)
                    except Exception:
                        try:
                            InfoBar.instance.stopTimeshift()
                        except Exception:
                            pass
        except Exception as e:
            log_debug(f"InfoBar timeshift cleanup error: {e}")

        self.auto_dismiss_timeshift_dialogs()
        try:
            self.dismiss_timer = eTimer()
            self.dismiss_timer.callback.append(self.auto_dismiss_timeshift_dialogs)
            self.dismiss_timer.start(100, True)
        except Exception:
            pass

    def auto_dismiss_timeshift_dialogs(self):
        try:
            for dlg_item in list(self.session.dialog_stack):
                dlg = dlg_item[0] if isinstance(dlg_item, tuple) else dlg_item
                name = dlg.__class__.__name__
                title_or_text = str(getattr(dlg, "title", "")) + " " + str(getattr(dlg, "text", ""))
                if "time shift" in title_or_text.lower() or "timeshift" in title_or_text.lower():
                    log_debug(f"Auto-closing timeshift dialog: {name}")
                    if hasattr(dlg, "close"):
                        try:
                            dlg.close(("quit", None))
                        except Exception:
                            try:
                                dlg.close("quit")
                            except Exception:
                                dlg.close()
        except Exception as e:
            log_debug(f"auto_dismiss_timeshift_dialogs error: {e}")

    def key_menu(self):
        self.session.openWithCallback(self.setup_callback, AudioPlusSetupScreen)

    def setup_callback(self, saved=False):
        if saved:
            self.categories_data = load_playlist()
            self.update_epg_visibility()
            
            if self.current_category and self.current_category in self.categories_data:
                self.show_channels(self.current_category)
            else:
                self.show_categories()

            if config.plugins.AudioPlus.show_preview_art.value == "Yes":
                art_path = os.path.join(IMG_PATH, "main_cube.png")
                if os.path.exists(art_path):
                    self["main_art"].instance.setPixmap(loadPNG(art_path))
                    self["main_art"].show()
            else:
                self["main_art"].hide()

    def on_screen_close(self):
        # Clean up timer ticks
        if self.ts_timer.isActive():
            self.ts_timer.stop()
        if self.audio_delay_timer.isActive():
            self.audio_delay_timer.stop()
        self.resume_live_tv_clean()


def main(session, **kwargs):
    session.open(AudioPlusScreen)


def menu_main(menuid, **kwargs):
    if menuid == "mainmenu":
        return [("AudioPlus", main, "audioplus_menu_main", 45)]
    return []


def Plugins(**kwargs):
    descriptors = [
        PluginDescriptor(
            name="AudioPlus",
            description="Audio streams and delay manager",
            where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
            icon="plugin.png",
            fnc=main
        )
    ]
    if config.plugins.AudioPlus.show_in_mainmenu.value == "Yes":
        descriptors.append(
            PluginDescriptor(
                name="AudioPlus",
                description="Audio streams and delay manager",
                where=PluginDescriptor.WHERE_MENU,
                fnc=menu_main
            )
        )
    return descriptors
