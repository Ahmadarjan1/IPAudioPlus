# -*- coding: utf-8 -*-
# Universal Multi-Image & Multi-Python Enigma2 Native Loader
# Auto-detects receiver CPU and Python version at runtime (OpenATV, OpenPLi, Egami, OpenBH, etc.)
import os
import sys
import platform
import traceback

# Universal Enigma2 Cross-Image Compatibility Shim
try:
    import Components.ActionMap
    if not hasattr(Components.ActionMap, 'loadKeymap'):
        try:
            from keymapparser import readKeymodule as _rkm
            Components.ActionMap.loadKeymap = _rkm
        except Exception:
            Components.ActionMap.loadKeymap = lambda *args, **kwargs: None
except Exception:
    pass

try:
    import Components.MultiContent
    if not hasattr(Components.MultiContent, 'MultiContentEntryRectangle'):
        try:
            from Components.MultiContent import MultiContentEntryText
            def _dummy_rect(pos=(0, 0), size=(0, 0), backgroundColor=None, backgroundColorSelected=None, borderWidth=0, borderColor=None, borderColorSelected=None, cornerRadius=0, cornerEdges=15, **kwargs):
                try:
                    return MultiContentEntryText(pos=pos, size=size, font=0, flags=0, text="", backcolor=backgroundColor, backcolor_sel=backgroundColorSelected, border_width=borderWidth or 0, border_color=borderColor)
                except Exception:
                    try:
                        return MultiContentEntryText(pos=pos, size=size, font=0, flags=0, text="", backcolor=backgroundColor, backcolor_sel=backgroundColorSelected)
                    except Exception:
                        return (1, int(pos[0]), int(pos[1]), int(size[0]), int(size[1]), 0, 0, "", backgroundColor, backgroundColorSelected)
            Components.MultiContent.MultiContentEntryRectangle = _dummy_rect
        except Exception:
            pass
except Exception:
    pass

_curr_dir = os.path.dirname(os.path.abspath(__file__))
if _curr_dir and _curr_dir not in sys.path:
    sys.path.insert(0, _curr_dir)

# Universal Cross-Image Font Compatibility (Auto-register 'Bold' & 'Regular' for OpenPLi)
try:
    from enigma import addFont
    for _font_path in [
        "/usr/share/fonts/nmsbd.ttf",
        "/usr/share/enigma2/skin_default/nmsbd.ttf",
        "/usr/share/fonts/truetype/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/DejaVuSans.ttf",
        "/usr/share/fonts/ae_AlMohanad.ttf",
        "/usr/share/enigma2/fonts/nmsbd.ttf",
        "/usr/share/fonts/valis_enigma.ttf"
    ]:
        if os.path.isfile(_font_path):
            try:
                addFont(_font_path, "Bold", 100, 1)
                addFont(_font_path, "Regular", 100, 1)
                break
            except Exception:
                pass
    _f_dir = os.path.join(_curr_dir, "fonts")
    if os.path.isdir(_f_dir):
        for _fn in os.listdir(_f_dir):
            if _fn.lower().endswith((".ttf", ".otf")):
                _fp = os.path.join(_f_dir, _fn)
                _stem = os.path.splitext(_fn)[0]
                try:
                    addFont(_fp, _stem, 100, 1)
                    if "bold" in _stem.lower():
                        addFont(_fp, "Bold", 100, 1)
                    if "regular" in _stem.lower():
                        addFont(_fp, "Regular", 100, 1)
                except Exception:
                    pass
except Exception:
    pass

def _detect_arch():
    machine = platform.machine().lower()
    is_64 = sys.maxsize > 2**32
    if "aarch64" in machine or (("arm" in machine) and is_64):
        return "aarch64"
    elif "arm" in machine:
        return "arm"
    elif "mips" in machine:
        return "mips"
    elif "x86_64" in machine or "amd64" in machine:
        return "x86_64"
    return "arm"

_arch = _detect_arch()
_py_major = sys.version_info[0]
_py_minor = sys.version_info[1]
_curr_dir = os.path.dirname(os.path.abspath(__file__))

# Candidate search paths in priority order
_candidates = []
# 1. Exact arch + exact py version: arch/arm/py3.12/core_plugin.so
_candidates.append(os.path.join(_curr_dir, "arch", _arch, "py%d.%d" % (_py_major, _py_minor), "web_server.so"))

# 2. ABI fallbacks for close Python 3 releases
if _py_major == 3:
    if _py_minor == 13:
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.13", "web_server.so"))
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.12", "web_server.so"))
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.11", "web_server.so"))
    elif _py_minor == 12:
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.12", "web_server.so"))
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.11", "web_server.so"))
    elif _py_minor == 14:
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.14", "web_server.so"))
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.13", "web_server.so"))
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.11", "web_server.so"))
    elif _py_minor == 10:
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.10", "web_server.so"))
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.9", "web_server.so"))
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.11", "web_server.so"))
    elif _py_minor == 8:
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.8", "web_server.so"))
        _candidates.append(os.path.join(_curr_dir, "arch", _arch, "py3.9", "web_server.so"))

# 3. Direct arch folder: arch/arm/core_plugin.so
_candidates.append(os.path.join(_curr_dir, "arch", _arch, "web_server.so"))
# 4. Root dir fallback
_candidates.append(os.path.join(_curr_dir, "web_server.so"))

_so_path = None
for _c in _candidates:
    if os.path.isfile(_c):
        _so_path = _c
        break

if not _so_path:
    _err_msg = "[Enigma2 Universal Loader] No compatible binary found for Arch: %s, Python: %d.%d in paths:\n" % (_arch, _py_major, _py_minor)
    _err_msg += "\n".join(_candidates)
    sys.stderr.write(_err_msg + "\n")
    try:
        with open("/tmp/enigma2_web_server_error.log", "w", encoding="utf-8") as _f_log:
            _f_log.write(_err_msg)
    except Exception:
        pass
    raise ImportError(_err_msg)

# Auto-link plugin assets into active arch directory so any legacy __file__ relative paths ALWAYS resolve!
try:
    _arch_dir = os.path.dirname(_so_path)
    if os.path.isdir(_curr_dir) and os.path.isdir(_arch_dir) and _curr_dir != _arch_dir:
        for _item in os.listdir(_curr_dir):
            if _item in ("arch", "__pycache__", ".git"):
                continue
            _src = os.path.join(_curr_dir, _item)
            _dst = os.path.join(_arch_dir, _item)
            if not os.path.exists(_dst):
                try:
                    os.symlink(_src, _dst)
                except Exception:
                    try:
                        if os.path.isdir(_src):
                            import shutil
                            shutil.copytree(_src, _dst)
                        else:
                            import shutil
                            shutil.copy2(_src, _dst)
                    except Exception:
                        pass
except Exception:
    pass

_target_file = os.path.join(_curr_dir, "web_server.py" if "web_server" != "core_plugin" else "plugin.py")
_mod = None
if _py_major >= 3:
    import importlib.util
    _pkg = __name__.rpartition('.')[0]
    _mod_name = "web_server" if not _pkg else f"{_pkg}.web_server"
    _spec = importlib.util.spec_from_file_location(_mod_name, _so_path)
    if _spec and _spec.loader:
        _temp_mod = importlib.util.module_from_spec(_spec)
        sys.modules[_spec.name] = _temp_mod
        try:
            _temp_mod.__file__ = _target_file
            _temp_mod.__dict__['__file__'] = _target_file
        except Exception:
            pass
        try:
            _spec.loader.exec_module(_temp_mod)
            _mod = _temp_mod
        except Exception as _e_exec:
            sys.modules.pop(_spec.name, None)
            try:
                with open("/tmp/enigma2_web_server_error.log", "w", encoding="utf-8") as _f_log:
                    _f_log.write(f"Error loading web_server from {_so_path}:\n{_e_exec}\n{traceback.format_exc()}")
            except Exception:
                pass
            raise
else:
    import imp
    _mod = imp.load_dynamic("web_server", _so_path)

if _mod is not None:
    # Retarget __file__ so relative asset lookups (skins, icons, translations) resolve to plugin root
    try:
        _mod.__file__ = _target_file
        _mod.__dict__['__file__'] = _target_file
    except Exception:
        pass
    _cur_mod = sys.modules.get(__name__)
    if _cur_mod is not None:
        _cur_mod.__file__ = _target_file
    for _k in dir(_mod):
        if not _k.startswith('__'):
            _v = getattr(_mod, _k)
            globals()[_k] = _v
            if _cur_mod is not None:
                setattr(_cur_mod, _k, _v)
    if hasattr(_mod, 'Plugins'):
        _p_fn = getattr(_mod, 'Plugins')
        globals()['Plugins'] = _p_fn
        if _cur_mod is not None:
            setattr(_cur_mod, 'Plugins', _p_fn)
