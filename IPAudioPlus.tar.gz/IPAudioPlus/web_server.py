# -*- coding: utf-8 -*-
"""
IPAudioPlus Embedded Web Server & REST API
Provides a dedicated browser interface to manage audio channels and playlists.
Compatible with Python 3.x on Enigma2 (OpenATV / OE-Alliance).
"""

import os
import sys
import json
import socket
import threading
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

# Global server state
_server_thread = None
_http_server = None
_reload_callback = None

USER_LIST_PATH_PRIMARY = "/etc/enigma2/ipaudioplus_user_list.json"
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
USER_LIST_PATH_BACKUP = os.path.join(PLUGIN_DIR, "ipaudioplus_user_list.json")
PRO_JSON_PATH = "/etc/enigma2/IPAudioPro.json"
TEMPLATES_PATH = os.path.join(PLUGIN_DIR, "provider_templates.json")

def load_provider_templates():
    if os.path.exists(TEMPLATES_PATH):
        try:
            with open(TEMPLATES_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[IPAudioPlus-Web] Error reading templates: {e}")
    return {"Orange": [], "SATFAMILY": [], "Best": []}

def load_pro_data():
    if os.path.exists(PRO_JSON_PATH):
        try:
            with open(PRO_JSON_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
        except Exception as e:
            print(f"[IPAudioPlus-Web] Error reading IPAudioPro.json: {e}")
    return {}

def save_pro_data(data):
    try:
        with open(PRO_JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        trigger_reload()
        return True, "Saved successfully"
    except Exception as e:
        print(f"[IPAudioPlus-Web] Error saving IPAudioPro.json: {e}")
        return False, str(e)

def calculate_token(username, password):
    u = (username or "").strip()
    p = (password or "").strip()
    if not p and not u:
        return ""
    if p:
        if u and (p.startswith(u + "_") or p.startswith(u)):
            return p
        elif u:
            return f"{u}_{p}"
        else:
            return p
    return u

_playlist_lock = threading.Lock()

def get_lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"

def load_playlist(include_pro=True):
    with _playlist_lock:
        data = {}
        candidates = [USER_LIST_PATH_PRIMARY, USER_LIST_PATH_BACKUP]
        for path in candidates:
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        loaded = json.load(f)
                    if isinstance(loaded, dict) and loaded:
                        data = loaded
                        break
                except Exception as e:
                    print(f"[IPAudioPlus-Web] Error reading {path}: {e}")
        if not data:
            data = {"Playlist": {"Id": "Playlist", "channels": []}}

        if include_pro and os.path.exists(PRO_JSON_PATH):
            try:
                with open(PRO_JSON_PATH, "r", encoding="utf-8") as f:
                    pro_data = json.load(f)
                if isinstance(pro_data, dict):
                    for p_name, p_info in pro_data.items():
                        chs = p_info.get("channels") or p_info.get("streams") or []
                        if chs and p_name not in data:
                            data[p_name] = {
                                "Id": p_info.get("Id", p_name),
                                "channels": chs,
                                "is_pro": True
                            }
            except Exception as e:
                print(f"[IPAudioPlus-Web] Error loading pro data into playlist: {e}")

        return data

def save_playlist(data):
    with _playlist_lock:
        try:
            clean_data = {}
            for k, v in data.items():
                if not v.get("is_pro"):
                    clean_data[k] = v
            # Save to primary
            with open(USER_LIST_PATH_PRIMARY, "w", encoding="utf-8") as f:
                json.dump(clean_data, f, ensure_ascii=False, indent=2)
            # Save backup in plugin dir
            try:
                with open(USER_LIST_PATH_BACKUP, "w", encoding="utf-8") as f:
                    json.dump(clean_data, f, ensure_ascii=False, indent=2)
            except Exception as eb:
                print(f"[IPAudioPlus-Web] Backup write error: {eb}")
            
            trigger_reload()
            return True, "Saved successfully"
        except Exception as e:
            print(f"[IPAudioPlus-Web] Error saving playlist: {e}")
            return False, str(e)

def register_reload_callback(cb):
    global _reload_callback
    _reload_callback = cb

def trigger_reload():
    global _reload_callback
    if callable(_reload_callback):
        try:
            _reload_callback()
        except Exception as e:
            print(f"[IPAudioPlus-Web] Reload callback error: {e}")

HTML_PAGE = """<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IP Audio+ Web Manager</title>
  <style>
    :root {
      --bg: #070b16;
      --card-bg: rgba(16, 24, 45, 0.75);
      --card-border: rgba(0, 210, 255, 0.18);
      --card-hover: rgba(22, 34, 64, 0.9);
      --primary: #00d2ff;
      --primary-gradient: linear-gradient(135deg, #00d2ff 0%, #007ac4 100%);
      --accent-green: #10b981;
      --accent-red: #ef4444;
      --accent-amber: #f59e0b;
      --text: #ffffff;
      --text-muted: #94a3b8;
      --radius: 12px;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, 'Cairo', sans-serif; }
    body {
      background: radial-gradient(circle at 50% 0%, #102142 0%, var(--bg) 60%);
      color: var(--text);
      min-height: 100vh;
      padding: 16px;
      line-height: 1.5;
    }
    .container { max-width: 1200px; margin: 0 auto; }
    
    /* Header */
    header {
      background: var(--card-bg);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid var(--card-border);
      border-radius: var(--radius);
      padding: 16px 20px;
      margin-bottom: 20px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.4);
    }
    .logo-box { display: flex; align-items: center; gap: 12px; }
    .logo-badge {
      background: var(--primary-gradient);
      color: #050b18;
      font-weight: 900;
      padding: 6px 14px;
      border-radius: 8px;
      font-size: 1.15rem;
      letter-spacing: 0.5px;
      box-shadow: 0 0 15px rgba(0, 210, 255, 0.4);
    }
    .logo-title h1 { font-size: 1.3rem; font-weight: 700; color: #fff; }
    .logo-title p { font-size: 0.82rem; color: var(--text-muted); }
    
    .status-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid rgba(16, 185, 129, 0.3);
      color: var(--accent-green);
      padding: 6px 12px;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 600;
    }
    .pulse-dot {
      width: 8px; height: 8px; border-radius: 50%;
      background: var(--accent-green);
      box-shadow: 0 0 8px var(--accent-green);
      animation: pulse 1.8s infinite;
    }
    @keyframes pulse { 0% { opacity: 0.4; } 50% { opacity: 1; } 100% { opacity: 0.4; } }
    
    .header-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    
    /* Buttons */
    .btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 0.9rem;
      font-weight: 600;
      cursor: pointer;
      border: none;
      transition: all 0.2s ease;
      color: #fff;
    }
    .btn:hover { transform: translateY(-2px); }
    .btn:active { transform: translateY(0); }
    .btn-primary { background: var(--primary-gradient); color: #070e1c; font-weight: 700; box-shadow: 0 4px 15px rgba(0, 210, 255, 0.3); }
    .btn-success { background: linear-gradient(135deg, #10b981 0%, #059669 100%); box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3); }
    .btn-danger { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); }
    .btn-dark { background: rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.15); }
    .btn-dark:hover { background: rgba(255, 255, 255, 0.15); }
    .btn-sm { padding: 5px 10px; font-size: 0.8rem; border-radius: 6px; }

    /* Category Navigation */
    .nav-panel {
      background: var(--card-bg);
      backdrop-filter: blur(16px);
      border: 1px solid var(--card-border);
      border-radius: var(--radius);
      padding: 14px 18px;
      margin-bottom: 20px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .tabs-wrapper { display: flex; gap: 8px; overflow-x: auto; max-width: 100%; padding-bottom: 4px; }
    .tab-btn {
      background: rgba(255, 255, 255, 0.06);
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: #cbd5e1;
      padding: 7px 14px;
      border-radius: 8px;
      font-size: 0.9rem;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      white-space: nowrap;
      transition: all 0.2s;
    }
    .tab-btn:hover { background: rgba(0, 210, 255, 0.1); color: var(--primary); }
    .tab-btn.active {
      background: rgba(0, 210, 255, 0.18);
      border-color: var(--primary);
      color: var(--primary);
      font-weight: 700;
      box-shadow: 0 0 12px rgba(0, 210, 255, 0.2);
    }
    .tab-count {
      background: rgba(0, 0, 0, 0.3);
      padding: 2px 7px;
      border-radius: 10px;
      font-size: 0.75rem;
    }

    /* Search & Stats Bar */
    .toolbar {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 14px;
      margin-bottom: 16px;
    }
    .search-box {
      flex: 1;
      min-width: 250px;
      position: relative;
    }
    .search-box input {
      width: 100%;
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 8px;
      padding: 10px 14px;
      color: #fff;
      font-size: 0.9rem;
      outline: none;
      transition: border 0.2s;
    }
    .search-box input:focus { border-color: var(--primary); box-shadow: 0 0 10px rgba(0, 210, 255, 0.2); }
    .stats-info { color: var(--text-muted); font-size: 0.88rem; }

    /* Channel Cards / List */
    .channel-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
      margin-bottom: 30px;
    }
    .channel-card {
      background: var(--card-bg);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 10px;
      padding: 12px 18px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 14px;
      transition: all 0.2s;
    }
    .channel-card:hover {
      background: var(--card-hover);
      border-color: rgba(0, 210, 255, 0.3);
      transform: translateY(-1px);
    }
    .ch-left {
      display: flex;
      align-items: center;
      gap: 14px;
      flex: 1;
      min-width: 280px;
    }
    .ch-num {
      width: 34px;
      height: 34px;
      border-radius: 8px;
      background: rgba(0, 210, 255, 0.1);
      border: 1px solid rgba(0, 210, 255, 0.25);
      color: var(--primary);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 0.9rem;
      flex-shrink: 0;
    }
    .ch-meta { flex: 1; min-width: 0; }
    .ch-name {
      font-size: 1.05rem;
      font-weight: 700;
      color: #fff;
      margin-bottom: 2px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .ch-url {
      font-size: 0.8rem;
      color: #94a3b8;
      font-family: monospace;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      direction: ltr;
      text-align: left;
    }
    
    .ch-actions {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: nowrap;
    }
    
    .btn-play {
      background: rgba(16, 185, 129, 0.18);
      border: 1px solid rgba(16, 185, 129, 0.35);
      color: var(--accent-green);
      padding: 6px 12px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: all 0.2s;
    }
    .btn-play:hover { background: var(--accent-green); color: #000; }
    .btn-play.playing { background: var(--accent-green); color: #000; animation: pulse 1s infinite; }

    /* Modals */
    .modal-backdrop {
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(6px);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      padding: 16px;
    }
    .modal-backdrop.show { display: flex; }
    .modal-content {
      background: #0f172a;
      border: 1px solid var(--card-border);
      border-radius: var(--radius);
      width: 100%;
      max-width: 540px;
      padding: 24px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.6);
      animation: zoomIn 0.2s ease-out;
    }
    @keyframes zoomIn { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
    .modal-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 18px;
      padding-bottom: 10px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    .modal-header h3 { font-size: 1.2rem; color: var(--primary); }
    .btn-close {
      background: transparent;
      border: none;
      color: var(--text-muted);
      font-size: 1.4rem;
      cursor: pointer;
    }
    .form-group { margin-bottom: 14px; }
    .form-group label { display: block; font-size: 0.85rem; color: #cbd5e1; margin-bottom: 6px; }
    .form-group input, .form-group select, .form-group textarea {
      width: 100%;
      background: rgba(0, 0, 0, 0.3);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 8px;
      padding: 10px 12px;
      color: #fff;
      font-size: 0.9rem;
      outline: none;
    }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
      border-color: var(--primary);
    }
    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      margin-top: 20px;
    }

    /* Toast Notification */
    .toast-container {
      position: fixed;
      bottom: 24px;
      left: 24px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      z-index: 2000;
    }
    .toast {
      background: #1e293b;
      border-right: 4px solid var(--primary);
      color: #fff;
      padding: 12px 18px;
      border-radius: 8px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.5);
      font-size: 0.9rem;
      display: flex;
      align-items: center;
      gap: 10px;
      animation: slideIn 0.3s ease;
    }
    @keyframes slideIn { from { transform: translateX(-100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

    /* Audio Player Bar */
    .player-bar {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(12px);
      border-top: 1px solid var(--primary);
      padding: 10px 24px;
      display: none;
      align-items: center;
      justify-content: space-between;
      z-index: 900;
      box-shadow: 0 -5px 25px rgba(0, 210, 255, 0.15);
    }
    .player-bar.active { display: flex; }
    .player-info { display: flex; align-items: center; gap: 12px; }
    .player-title { font-weight: 700; color: #fff; font-size: 0.95rem; }
    
    @media (max-width: 768px) {
      header { flex-direction: column; align-items: stretch; }
      .header-actions { justify-content: flex-start; }
      .ch-actions { width: 100%; justify-content: flex-end; }
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <header>
      <div class="logo-box">
        <div class="logo-badge">IP AUDIO+</div>
        <div class="logo-title">
          <h1 id="txt-app-title">لوحة إدارة القنوات الصوتية</h1>
          <p id="txt-app-sub">تحكم مباشر وسلس من المتصفح عبر شبكة الرسيفر</p>
        </div>
      </div>
      
      <div class="status-badge">
        <span class="pulse-dot"></span>
        <span id="txt-status">الرسيفر متصل</span>: <span id="stb-ip" style="font-family: monospace;">...</span>
      </div>

      <div class="header-actions">
        <button class="btn btn-dark btn-sm" onclick="toggleLang()" id="btn-lang">English</button>
        <button class="btn btn-dark btn-sm" onclick="checkWebUpdate()" id="btn-web-update">🔄 فحص التحديثات</button>
        <button class="btn btn-warning btn-sm" onclick="openTokenModal()" id="btn-token-modal" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: #050b18; font-weight: 700; box-shadow: 0 4px 15px rgba(245, 158, 11, 0.35);">🔑 إضافة توكن / اشتراك (0)</button>
        <button class="btn btn-dark btn-sm" onclick="exportJSON()" id="btn-export">تصدير القنوات</button>
        <button class="btn btn-primary btn-sm" onclick="openModal('modal-m3u')" id="btn-import-m3u">📥 استيراد M3U</button>
        <button class="btn btn-success" onclick="saveToSTB()" id="btn-save-stb">💾 حفظ وتحديث بالرسيفر</button>
      </div>
    </header>

    <!-- Navigation / Categories -->
    <div class="nav-panel">
      <div class="tabs-wrapper" id="category-tabs">
        <!-- Categories will be rendered here -->
      </div>
      <div style="display: flex; gap: 8px;">
        <button class="btn btn-dark btn-sm" onclick="openModal('modal-add-category')" id="btn-new-cat">+ فئة جديدة</button>
        <button class="btn btn-primary btn-sm" onclick="openAddChannelModal()" id="btn-new-ch">+ قناة صوتية</button>
        <button class="btn btn-danger btn-sm" onclick="deleteCurrentCategory()" id="btn-del-cat">حذف الفئة</button>
      </div>
    </div>

    <!-- Toolbar -->
    <div class="toolbar">
      <div class="search-box">
        <input type="text" id="search-input" placeholder="🔍 بحث عن قناة بالاسم أو الرابط..." oninput="filterChannels()">
      </div>
      <div class="stats-info" id="stats-label">
        جاري تحميل القنوات...
      </div>
    </div>

    <!-- Channels List -->
    <div class="channel-list" id="channel-container">
      <!-- Channels will be rendered here -->
    </div>
  </div>

  <!-- Bottom Mini Audio Player -->
  <div class="player-bar" id="player-bar">
    <div class="player-info">
      <span style="color: var(--accent-green); font-size: 1.2rem;">🔊</span>
      <div>
        <div class="player-title" id="player-ch-name">Channel Name</div>
        <div style="font-size: 0.78rem; color: var(--text-muted);">معاينة الصوت المباشر من المتصفح</div>
      </div>
    </div>
    <div style="display: flex; align-items: center; gap: 14px;">
      <audio id="audio-preview" controls style="height: 34px;"></audio>
      <button class="btn btn-dark btn-sm" onclick="stopPreview()">إغلاق ✕</button>
    </div>
  </div>

  <!-- Modal: Add / Edit Channel -->
  <div class="modal-backdrop" id="modal-channel">
    <div class="modal-content">
      <div class="modal-header">
        <h3 id="modal-ch-title">إضافة قناة صوتية جديدة</h3>
        <button class="btn-close" onclick="closeModal('modal-channel')">×</button>
      </div>
      <input type="hidden" id="form-ch-index" value="-1">
      <div class="form-group">
        <label id="lbl-ch-cat">الفئة / السيرفر:</label>
        <select id="form-ch-category"></select>
      </div>
      <div class="form-group">
        <label id="lbl-ch-name">اسم القناة:</label>
        <input type="text" id="form-ch-name" placeholder="مثال: Bein Sports 1 Premium">
      </div>
      <div class="form-group">
        <label id="lbl-ch-url">رابط البث (Stream URL):</label>
        <input type="text" id="form-ch-url" placeholder="http://... أو https://..." dir="ltr">
      </div>
      <div class="modal-footer">
        <button class="btn btn-dark" onclick="closeModal('modal-channel')" id="btn-cancel">إلغاء</button>
        <button class="btn btn-primary" onclick="submitChannel()" id="btn-save-ch">حفظ القناة</button>
      </div>
    </div>
  </div>

  <!-- Modal: Add Category -->
  <div class="modal-backdrop" id="modal-add-category">
    <div class="modal-content">
      <div class="modal-header">
        <h3 id="modal-cat-title">إضافة فئة / سيرفر جديد</h3>
        <button class="btn-close" onclick="closeModal('modal-add-category')">×</button>
      </div>
      <div class="form-group">
        <label id="lbl-cat-name">اسم الفئة:</label>
        <input type="text" id="form-cat-name" placeholder="مثال: Bein Max أو SSC أو Quran">
      </div>
      <div class="modal-footer">
        <button class="btn btn-dark" onclick="closeModal('modal-add-category')">إلغاء</button>
        <button class="btn btn-primary" onclick="submitCategory()">إضافة الفئة</button>
      </div>
    </div>
  </div>

  <!-- Modal: Import M3U -->
  <div class="modal-backdrop" id="modal-m3u">
    <div class="modal-content" style="max-width: 650px;">
      <div class="modal-header">
        <h3 id="modal-m3u-title">📥 استيراد قائمة قنوات (M3U / M3U8)</h3>
        <button class="btn-close" onclick="closeModal('modal-m3u')">×</button>
      </div>
      <div class="form-group">
        <label>استيراد إلى الفئة:</label>
        <select id="form-m3u-category"></select>
      </div>
      <div class="form-group">
        <label>أو اختر ملف M3U من جهازك:</label>
        <input type="file" id="m3u-file-input" accept=".m3u,.m3u8,.txt" onchange="handleM3UFile(event)">
      </div>
      <div class="form-group">
        <label>أو الصق محتوى ملف الـ M3U هنا مباشرة:</label>
        <textarea id="form-m3u-content" rows="7" placeholder="#EXTM3U\n#EXTINF:-1,Channel Name\nhttp://stream-url..." dir="ltr"></textarea>
      </div>
      <div class="modal-footer">
        <button class="btn btn-dark" onclick="closeModal('modal-m3u')">إلغاء</button>
        <button class="btn btn-success" onclick="submitM3U()">استيراد القنوات الآن</button>
      </div>
    </div>
  </div>

  <!-- Modal: Token & Subscription Generator (Remote Key 0) -->
  <div class="modal-backdrop" id="modal-token-gen">
    <div class="modal-content" style="max-width: 680px; background: #0a1120; border: 1px solid rgba(0, 210, 255, 0.35); box-shadow: 0 25px 60px rgba(0,0,0,0.85);">
      <div class="modal-header" style="border-bottom: 1px solid rgba(0, 210, 255, 0.2); padding-bottom: 14px;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span style="font-size: 1.6rem;">🔑</span>
          <div>
            <h3 id="txt-tg-modal-title" style="color: #38bdf8; font-size: 1.25rem; margin: 0;">مولد الصوتيات الذكي | Audio Stream Generator</h3>
            <p id="txt-tg-modal-sub" style="font-size: 0.8rem; color: #94a3b8; margin: 0;">نفس خاصية الزر (0) في الريموت لتوليد قنوات Orange و SATFAMILY</p>
          </div>
        </div>
        <button class="btn-close" onclick="closeModal('modal-token-gen')">×</button>
      </div>

      <!-- Top Info Banner -->
      <div style="background: rgba(15, 31, 56, 0.7); border: 1px solid rgba(0, 122, 196, 0.3); border-radius: 8px; padding: 10px 14px; margin-bottom: 16px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
        <span style="font-size: 0.85rem; color: #f59e0b; font-weight: 600;">Orange • SATFAMILY • Best</span>
        <span style="font-size: 0.78rem; color: #64748b;" id="tg-savepath">حفظ تلقائي في: /etc/enigma2/IPAudioPro.json</span>
      </div>

      <!-- Provider Selector -->
      <div class="form-group">
        <label id="lbl-tg-prov" style="font-weight: 600; color: #38bdf8;">مزود الصوتيات (Provider):</label>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 6px;">
          <button type="button" class="btn btn-dark tg-prov-btn active" id="tg-btn-Orange" onclick="selectTgProvider('Orange')" style="justify-content: center; padding: 10px; border: 1px solid var(--primary); background: rgba(0, 210, 255, 0.15); color: var(--primary);">
            <span>🍊 Orange</span>
            <span class="tab-count" id="badge-Orange" style="background: rgba(245, 158, 11, 0.25); color: #f59e0b;">...</span>
          </button>
          <button type="button" class="btn btn-dark tg-prov-btn" id="tg-btn-SATFAMILY" onclick="selectTgProvider('SATFAMILY')" style="justify-content: center; padding: 10px;">
            <span>🛰️ SATFAMILY</span>
            <span class="tab-count" id="badge-SATFAMILY" style="background: rgba(16, 185, 129, 0.25); color: #10b981;">...</span>
          </button>
          <button type="button" class="btn btn-dark tg-prov-btn" id="tg-btn-Best" onclick="selectTgProvider('Best')" style="justify-content: center; padding: 10px; opacity: 0.55;">
            <span>⭐ Best</span>
            <span class="tab-count" style="font-size: 0.7rem;">قريباً</span>
          </button>
        </div>
      </div>

      <!-- Current Active Subscription Status (if exists) -->
      <div id="tg-active-box" style="display: none; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 10px 14px; margin-bottom: 14px;">
        <div style="display: flex; align-items: center; justify-content: space-between; font-size: 0.85rem; flex-wrap: wrap; gap: 8px;">
          <span style="color: #10b981;">✓ يوجد اشتراك مفعل حالياً لهذا المزود: <strong id="tg-active-user" style="color: #fff;"></strong></span>
          <button class="btn btn-danger btn-sm" onclick="deleteTgSubscription()" style="padding: 3px 8px; font-size: 0.75rem;">مسح الاشتراك</button>
        </div>
      </div>

      <!-- Username -->
      <div class="form-group">
        <label for="tg-username" id="lbl-tg-user" style="font-weight: 600;">اسم المستخدم (Username):</label>
        <input type="text" id="tg-username" placeholder="أدخل اسم المستخدم لاشتراكك..." oninput="updateTgPreview()" dir="ltr">
      </div>

      <!-- Password or Token -->
      <div class="form-group">
        <label for="tg-password" id="lbl-tg-pass" style="font-weight: 600;">كلمة المرور أو التوكن (Password / Token):</label>
        <input type="text" id="tg-password" placeholder="أدخل كلمة المرور أو رمز التوكن..." oninput="updateTgPreview()" dir="ltr">
        <small id="lbl-tg-hint" style="color: #64748b; font-size: 0.75rem; margin-top: 3px; display: block;">إذا كان لديك رمز توكن مباشر يمكنك لصقه هنا مباشرة دون اسم مستخدم.</small>
      </div>

      <!-- Live URL Preview Box -->
      <div class="form-group">
        <label id="lbl-tg-preview" style="color: #f59e0b; font-size: 0.82rem; font-weight: 600;">معاينة الرابط المولد (Live Stream Preview):</label>
        <div id="tg-preview-box" style="background: #050812; border: 1px solid rgba(0, 210, 255, 0.25); border-radius: 8px; padding: 10px 14px; font-family: monospace; font-size: 0.85rem; color: #a5f3fc; word-break: break-all; min-height: 40px; display: flex; align-items: center;">
          ...
        </div>
      </div>

      <!-- Footer Buttons -->
      <div class="modal-footer" style="margin-top: 18px; border-top: 1px solid rgba(255, 255, 255, 0.08); padding-top: 14px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <button type="button" class="btn btn-dark" onclick="clearTgFields()" id="btn-tg-clear" style="background: rgba(245, 158, 11, 0.15); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.3);">مسح الحقول</button>
        <div style="display: flex; gap: 10px;">
          <button type="button" class="btn btn-dark" onclick="closeModal('modal-token-gen')" id="btn-tg-cancel">إلغاء</button>
          <button type="button" class="btn btn-success" onclick="submitTgSave()" id="btn-tg-save" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); font-weight: 700; padding: 10px 20px;">
            ⚡ توليد وحفظ الاشتراك فوراً
          </button>
        </div>
      </div>
    </div>
  </div>

  <div class="toast-container" id="toasts"></div>

  <script>
    let playlistData = {};
    let currentCategory = "";
    let isArabic = true;
    let currentlyPlayingBtn = null;

    const I18N = {
      ar: {
        appTitle: "لوحة إدارة القنوات الصوتية",
        appSub: "تحكم مباشر وسلس من المتصفح عبر شبكة الرسيفر",
        status: "الرسيفر متصل",
        btnExport: "تصدير القنوات",
        btnImportM3U: "📥 استيراد M3U",
        btnSaveSTB: "💾 حفظ وتحديث بالرسيفر",
        btnNewCat: "+ فئة جديدة",
        btnNewCh: "+ قناة صوتية",
        btnDelCat: "حذف الفئة",
        searchPlaceholder: "🔍 بحث عن قناة بالاسم أو الرابط...",
        statsText: "إجمالي: {channels} قناة في {categories} فئات",
        emptyCat: "لا توجد قنوات في هذه الفئة بعد. اضغط على (+ قناة صوتية) لإضافة أول قناة!",
        copied: "تم نسخ الرابط إلى الحافظة!",
        savedSuccess: "تم حفظ وتحديث القنوات على الرسيفر فوراً!",
        deleteConfirm: "هل أنت متأكد من حذف هذه القناة؟",
        deleteCatConfirm: "هل أنت متأكد من حذف هذه الفئة بالكامل مع جميع قنواتها؟",
      },
      en: {
        appTitle: "IP Audio+ Channel Manager",
        appSub: "Direct browser controller connected to your Enigma2 box",
        status: "STB Online",
        btnExport: "Export JSON",
        btnImportM3U: "📥 Import M3U",
        btnSaveSTB: "💾 Save & Apply to STB",
        btnNewCat: "+ New Category",
        btnNewCh: "+ Add Channel",
        btnDelCat: "Delete Category",
        searchPlaceholder: "🔍 Search channels by name or URL...",
        statsText: "Total: {channels} channels in {categories} categories",
        emptyCat: "No channels in this category yet. Click (+ Add Channel) to start!",
        copied: "URL copied to clipboard!",
        savedSuccess: "Channels saved & applied to Enigma2 instantly!",
        deleteConfirm: "Are you sure you want to delete this channel?",
        deleteCatConfirm: "Are you sure you want to delete this category and all its channels?",
      }
    };

    async function init() {
      await loadSTBStatus();
      await fetchChannels();
    }

    async function loadSTBStatus() {
      try {
        const res = await fetch("/api/status");
        const data = await res.json();
        document.getElementById("stb-ip").innerText = data.ip + ":" + (data.port || "8088");
      } catch (e) {
        document.getElementById("stb-ip").innerText = location.host;
      }
    }

    async function fetchChannels() {
      try {
        const res = await fetch("/api/channels");
        const json = await res.json();
        playlistData = json.data || {};
        
        const categories = Object.keys(playlistData);
        if (categories.length > 0 && (!currentCategory || !playlistData[currentCategory])) {
          currentCategory = categories[0];
        }
        renderCategories();
        renderChannels();
      } catch (e) {
        showToast("فشل الاتصال بجهاز الرسيفر!", "error");
      }
    }

    function renderCategories() {
      const tabsEl = document.getElementById("category-tabs");
      tabsEl.innerHTML = "";
      const categories = Object.keys(playlistData);
      
      let totalChannels = 0;
      categories.forEach(cat => {
        const count = (playlistData[cat].channels || []).length;
        totalChannels += count;
        const btn = document.createElement("button");
        btn.className = "tab-btn " + (cat === currentCategory ? "active" : "");
        btn.innerHTML = `<span>${cat}</span><span class="tab-count">${count}</span>`;
        btn.onclick = () => {
          currentCategory = cat;
          renderCategories();
          renderChannels();
        };
        tabsEl.appendChild(btn);
      });

      const lang = isArabic ? I18N.ar : I18N.en;
      document.getElementById("stats-label").innerText = lang.statsText
        .replace("{channels}", totalChannels)
        .replace("{categories}", categories.length);
    }

    function renderChannels() {
      const container = document.getElementById("channel-container");
      container.innerHTML = "";

      if (!currentCategory || !playlistData[currentCategory]) {
        return;
      }

      const channels = playlistData[currentCategory].channels || [];
      const query = (document.getElementById("search-input").value || "").toLowerCase().trim();

      const filtered = channels.map((ch, idx) => ({ ...ch, originalIndex: idx }))
        .filter(ch => !query || (ch.Name || ch.name || "").toLowerCase().includes(query) || (ch.Url || ch.url || "").toLowerCase().includes(query));

      if (filtered.length === 0) {
        const emptyMsg = document.createElement("div");
        emptyMsg.style.cssText = "text-align: center; padding: 40px 20px; color: #94a3b8; background: var(--card-bg); border-radius: var(--radius);";
        emptyMsg.innerText = isArabic ? I18N.ar.emptyCat : I18N.en.emptyCat;
        container.appendChild(emptyMsg);
        return;
      }

      filtered.forEach((ch) => {
        const card = document.createElement("div");
        card.className = "channel-card";
        const chName = ch.Name || ch.name || "Audio Channel";
        const chUrl = ch.Url || ch.url || "";
        const chIdx = ch.originalIndex;

        card.innerHTML = `
          <div class="ch-left">
            <div class="ch-num">${chIdx + 1}</div>
            <div class="ch-meta">
              <div class="ch-name" title="${chName}">${chName}</div>
              <div class="ch-url" title="${chUrl}">${chUrl}</div>
            </div>
          </div>
          <div class="ch-actions">
            <button class="btn-play" onclick="togglePlayPreview('${encodeURIComponent(chUrl)}', '${encodeURIComponent(chName)}', this)">▶ تجربة</button>
            <button class="btn btn-dark btn-sm" onclick="copyUrl('${encodeURIComponent(chUrl)}')">📋 نسخ</button>
            <button class="btn btn-dark btn-sm" onclick="moveChannel(${chIdx}, -1)">▲</button>
            <button class="btn btn-dark btn-sm" onclick="moveChannel(${chIdx}, 1)">▼</button>
            <button class="btn btn-dark btn-sm" onclick="openEditChannelModal(${chIdx})">✏ تعديل</button>
            <button class="btn btn-danger btn-sm" onclick="deleteChannel(${chIdx})">🗑</button>
          </div>
        `;
        container.appendChild(card);
      });
    }

    function filterChannels() {
      renderChannels();
    }

    function togglePlayPreview(encUrl, encName, btn) {
      const url = decodeURIComponent(encUrl);
      const name = decodeURIComponent(encName);
      const player = document.getElementById("audio-preview");
      const bar = document.getElementById("player-bar");
      const title = document.getElementById("player-ch-name");

      if (currentlyPlayingBtn === btn && !player.paused) {
        player.pause();
        btn.classList.remove("playing");
        btn.innerHTML = "▶ تجربة";
        currentlyPlayingBtn = null;
        bar.classList.remove("active");
        return;
      }

      if (currentlyPlayingBtn) {
        currentlyPlayingBtn.classList.remove("playing");
        currentlyPlayingBtn.innerHTML = "▶ تجربة";
      }

      player.src = url;
      title.innerText = name;
      bar.classList.add("active");
      player.play().then(() => {
        btn.classList.add("playing");
        btn.innerHTML = "⏸ إيقاف";
        currentlyPlayingBtn = btn;
      }).catch(err => {
        showToast("لا يمكن تشغيل الرابط بالمتصفح (قد يتطلب كوديك خاص)", "error");
      });
    }

    function stopPreview() {
      const player = document.getElementById("audio-preview");
      player.pause();
      if (currentlyPlayingBtn) {
        currentlyPlayingBtn.classList.remove("playing");
        currentlyPlayingBtn.innerHTML = "▶ تجربة";
        currentlyPlayingBtn = null;
      }
      document.getElementById("player-bar").classList.remove("active");
    }

    function copyUrl(encUrl) {
      const url = decodeURIComponent(encUrl);
      navigator.clipboard.writeText(url).then(() => {
        showToast(isArabic ? I18N.ar.copied : I18N.en.copied);
      });
    }

    /* Channel Management */
    function openAddChannelModal() {
      document.getElementById("form-ch-index").value = "-1";
      document.getElementById("modal-ch-title").innerText = isArabic ? "إضافة قناة صوتية جديدة" : "Add New Audio Channel";
      document.getElementById("form-ch-name").value = "";
      document.getElementById("form-ch-url").value = "";
      
      const catSelect = document.getElementById("form-ch-category");
      catSelect.innerHTML = "";
      Object.keys(playlistData).forEach(cat => {
        const opt = document.createElement("option");
        opt.value = cat;
        opt.innerText = cat;
        if (cat === currentCategory) opt.selected = true;
        catSelect.appendChild(opt);
      });

      openModal("modal-channel");
    }

    function openEditChannelModal(idx) {
      const ch = playlistData[currentCategory].channels[idx];
      document.getElementById("form-ch-index").value = idx;
      document.getElementById("modal-ch-title").innerText = isArabic ? "تعديل القناة الصوتية" : "Edit Audio Channel";
      document.getElementById("form-ch-name").value = ch.Name || ch.name || "";
      document.getElementById("form-ch-url").value = ch.Url || ch.url || "";
      
      const catSelect = document.getElementById("form-ch-category");
      catSelect.innerHTML = "";
      Object.keys(playlistData).forEach(cat => {
        const opt = document.createElement("option");
        opt.value = cat;
        opt.innerText = cat;
        if (cat === currentCategory) opt.selected = true;
        catSelect.appendChild(opt);
      });

      openModal("modal-channel");
    }

    async function submitChannel() {
      const idx = parseInt(document.getElementById("form-ch-index").value);
      const cat = document.getElementById("form-ch-category").value;
      const name = document.getElementById("form-ch-name").value.trim();
      const url = document.getElementById("form-ch-url").value.trim();

      if (!name || !url) {
        showToast("يرجى إدخال اسم القناة ورابط البث!", "error");
        return;
      }

      if (!playlistData[cat]) {
        playlistData[cat] = { Id: cat, channels: [] };
      }

      if (idx === -1) {
        // Add new
        const newId = String(playlistData[cat].channels.length + 1);
        playlistData[cat].channels.push({ Name: name, Id: newId, Url: url });
        showToast("تمت إضافة القناة بنجاح!");
      } else {
        // Edit
        playlistData[cat].channels[idx].Name = name;
        playlistData[cat].channels[idx].Url = url;
        showToast("تم تعديل القناة بنجاح!");
      }

      closeModal("modal-channel");
      currentCategory = cat;
      renderCategories();
      renderChannels();
      await autoSave();
    }

    async function deleteChannel(idx) {
      const confirmMsg = isArabic ? I18N.ar.deleteConfirm : I18N.en.deleteConfirm;
      if (!confirm(confirmMsg)) return;

      playlistData[currentCategory].channels.splice(idx, 1);
      renderCategories();
      renderChannels();
      showToast("تم حذف القناة.");
      await autoSave();
    }

    async function moveChannel(idx, direction) {
      const list = playlistData[currentCategory].channels;
      const targetIdx = idx + direction;
      if (targetIdx < 0 || targetIdx >= list.length) return;

      const temp = list[idx];
      list[idx] = list[targetIdx];
      list[targetIdx] = temp;

      renderChannels();
      await autoSave();
    }

    /* Category Management */
    function submitCategory() {
      const name = document.getElementById("form-cat-name").value.trim();
      if (!name) return;
      if (playlistData[name]) {
        showToast("هذه الفئة موجودة بالفعل!", "error");
        return;
      }
      playlistData[name] = { Id: name, channels: [] };
      currentCategory = name;
      document.getElementById("form-cat-name").value = "";
      closeModal("modal-add-category");
      renderCategories();
      renderChannels();
      showToast("تمت إضافة الفئة بنجاح!");
      autoSave();
    }

    async function deleteCurrentCategory() {
      const confirmMsg = isArabic ? I18N.ar.deleteCatConfirm : I18N.en.deleteCatConfirm;
      if (!confirm(confirmMsg)) return;

      delete playlistData[currentCategory];
      const cats = Object.keys(playlistData);
      currentCategory = cats.length > 0 ? cats[0] : "";
      renderCategories();
      renderChannels();
      showToast("تم حذف الفئة.");
      await autoSave();
    }

    /* M3U Import */
    function handleM3UFile(e) {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        document.getElementById("form-m3u-content").value = event.target.result;
      };
      reader.readAsText(file);
    }

    async function submitM3U() {
      const content = document.getElementById("form-m3u-content").value.trim();
      const targetCat = document.getElementById("form-m3u-category").value;
      if (!content) {
        showToast("يرجى وضع محتوى ملف M3U!", "error");
        return;
      }

      const lines = content.split(/\\r?\\n/);
      let importedCount = 0;
      let curName = "";

      if (!playlistData[targetCat]) {
        playlistData[targetCat] = { Id: targetCat, channels: [] };
      }

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line.startsWith("#EXTINF")) {
          const commaIdx = line.lastIndexOf(",");
          if (commaIdx !== -1) {
            curName = line.substring(commaIdx + 1).trim();
          }
        } else if (line.startsWith("http://") || line.startsWith("https://")) {
          const chName = curName || `Channel ${playlistData[targetCat].channels.length + 1}`;
          playlistData[targetCat].channels.push({
            Name: chName,
            Id: String(playlistData[targetCat].channels.length + 1),
            Url: line
          });
          importedCount++;
          curName = "";
        }
      }

      closeModal("modal-m3u");
      document.getElementById("form-m3u-content").value = "";
      currentCategory = targetCat;
      renderCategories();
      renderChannels();
      showToast(`تم استيراد ${importedCount} قناة بنجاح!`);
      await autoSave();
    }

    /* Token Generator (Remote 0 Feature) */
    let tgInfo = null;
    let selectedTgProvider = "Orange";

    async function checkWebUpdate() {
      const btn = document.getElementById("btn-web-update");
      const orig = btn.innerText;
      btn.innerText = isArabic ? "جاري الفحص..." : "Checking...";
      btn.disabled = true;
      try {
        const res = await fetch("/api/update/check");
        const data = await res.json();
        if (data.status === "success") {
          const info = data.update_info;
          if (data.has_update && info) {
            const chgs = (info.changelog || []).join(" | ");
            const promptText = (isArabic ? "يوجد إصدار جديد متاح: v" : "New update available: v") + info.remote_version + " (" + (info.description || "") + "). " + (isArabic ? "هل ترغب في تثبيت التحديث الآن؟" : "Install update now?");
            if (confirm(promptText)) {
              btn.innerText = isArabic ? "جاري التثبيت..." : "Installing...";
              const instRes = await fetch("/api/update/install", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ download_url: info.download_url || info.ipk_url })
              });
              const instData = await instRes.json();
              if (instData.status === "success") {
                showToast(instData.message);
                setTimeout(async () => {
                  if (confirm(isArabic ? "هل ترغب في إعادة تشغيل واجهة الرسيفر الآن لتطبيق التحديث؟" : "Restart GUI now?")) {
                    await fetch("/api/update/restart", { method: "POST" });
                  }
                }, 1000);
              } else {
                showToast(instData.message || "فشل التثبيت", "error");
              }
            }
          } else {
            showToast(isArabic ? ("البلجن محدث لآخر إصدار بالفعل! (v" + (info ? info.current_version : "1.0") + ")") : "Plugin is already up to date!");
          }
        } else {
          showToast(data.error || "خطأ أثناء فحص التحديث", "error");
        }
      } catch (e) {
        showToast(isArabic ? "تعذر الاتصال بالرسيفر" : "Connection error", "error");
      } finally {
        btn.innerText = orig;
        btn.disabled = false;
      }
    }

    async function openTokenModal() {
      try {
        const res = await fetch("/api/token_gen/info");
        const json = await res.json();
        if (json.status === "success") {
          tgInfo = json;
          updateTgProviderBadges();
          selectTgProvider(selectedTgProvider);
        }
      } catch (e) {
        console.error("Error loading token gen info:", e);
      }
      openModal("modal-token-gen");
    }

    function updateTgProviderBadges() {
      if (!tgInfo || !tgInfo.providers) return;
      ["Orange", "SATFAMILY", "Best"].forEach(p => {
        const b = document.getElementById("badge-" + p);
        if (b && tgInfo.providers[p]) {
          const count = tgInfo.providers[p].channel_count || 0;
          b.innerText = count > 0 ? (count + (isArabic ? " قناة" : " ch")) : (isArabic ? "قريباً" : "Soon");
        }
      });
    }

    function selectTgProvider(p) {
      selectedTgProvider = p;
      ["Orange", "SATFAMILY", "Best"].forEach(prov => {
        const btn = document.getElementById("tg-btn-" + prov);
        if (btn) {
          if (prov === p) {
            btn.style.border = "1px solid var(--primary)";
            btn.style.background = "rgba(0, 210, 255, 0.18)";
            btn.style.color = "var(--primary)";
          } else {
            btn.style.border = "1px solid rgba(255, 255, 255, 0.1)";
            btn.style.background = "rgba(255, 255, 255, 0.08)";
            btn.style.color = "#cbd5e1";
          }
        }
      });

      const pData = (tgInfo && tgInfo.providers && tgInfo.providers[p]) || {};
      const activeBox = document.getElementById("tg-active-box");
      const activeUser = document.getElementById("tg-active-user");
      
      if (pData.has_active_sub) {
        activeBox.style.display = "block";
        activeUser.innerText = (pData.saved_username || pData.saved_token || "مفعل") + " (" + (pData.channel_count || 0) + (isArabic ? " قناة)" : " ch)");
        document.getElementById("tg-username").value = pData.saved_username || "";
        document.getElementById("tg-password").value = pData.saved_password || pData.saved_token || "";
      } else {
        activeBox.style.display = "none";
        document.getElementById("tg-username").value = "";
        document.getElementById("tg-password").value = "";
      }

      updateTgPreview();
    }

    function calculateLocalToken(u, p) {
      u = (u || "").trim();
      p = (p || "").trim();
      if (!p && !u) return "";
      if (p) {
        if (u && (p.startsWith(u + "_") || p.startsWith(u))) return p;
        else if (u) return `${u}_${p}`;
        else return p;
      }
      return u;
    }

    function updateTgPreview() {
      const u = document.getElementById("tg-username").value;
      const p = document.getElementById("tg-password").value;
      const token = calculateLocalToken(u, p);
      const previewBox = document.getElementById("tg-preview-box");

      const pData = (tgInfo && tgInfo.providers && tgInfo.providers[selectedTgProvider]) || {};
      if (selectedTgProvider === "Best") {
        previewBox.innerText = isArabic ? "مزود Best غير متوفر حالياً، سيتم إضافته قريباً" : "Best provider is currently unavailable, coming soon!";
        return;
      }

      const sampleUrl = pData.sample_url || "http://radio.orange-audio.top/Middle-Audio1/mpegts?token=";
      if (token) {
        previewBox.innerText = `${sampleUrl}${token}#`;
      } else {
        previewBox.innerText = `${sampleUrl}[TOKEN]#`;
      }
    }

    function clearTgFields() {
      document.getElementById("tg-username").value = "";
      document.getElementById("tg-password").value = "";
      updateTgPreview();
    }

    async function submitTgSave() {
      const u = document.getElementById("tg-username").value.trim();
      const p = document.getElementById("tg-password").value.trim();
      if (!u && !p) {
        showToast(isArabic ? "يرجى إدخال اسم المستخدم أو كلمة المرور / التوكن أولاً!" : "Please enter username or password / token!", "error");
        return;
      }

      const saveBtn = document.getElementById("btn-tg-save");
      const origText = saveBtn.innerText;
      saveBtn.innerText = isArabic ? "جاري التوليد والحفظ..." : "Generating...";
      saveBtn.disabled = true;

      try {
        const res = await fetch("/api/token_gen/save", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            provider: selectedTgProvider,
            username: u,
            password: p
          })
        });
        const json = await res.json();
        if (json.status === "success") {
          showToast(json.message || (isArabic ? "تم توليد وحفظ الاشتراك بنجاح في الرسيفر!" : "Subscription generated & saved!"));
          closeModal("modal-token-gen");
          await fetchChannels();
          currentCategory = selectedTgProvider;
          renderCategories();
          renderChannels();
        } else {
          showToast(json.message || "حدث خطأ أثناء الحفظ", "error");
        }
      } catch (e) {
        showToast(isArabic ? "تعذر الاتصال بالرسيفر!" : "Connection error!", "error");
      } finally {
        saveBtn.innerText = origText;
        saveBtn.disabled = false;
      }
    }

    async function deleteTgSubscription() {
      if (!confirm(isArabic ? `هل تريد حقاً مسح وحذف اشتراك ${selectedTgProvider} من الرسيفر؟` : `Are you sure you want to delete ${selectedTgProvider} subscription?`)) {
        return;
      }
      try {
        const res = await fetch("/api/token_gen/delete", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ provider: selectedTgProvider })
        });
        const json = await res.json();
        if (json.status === "success") {
          showToast(json.message || (isArabic ? "تم مسح الاشتراك بنجاح" : "Subscription deleted"));
          document.getElementById("tg-username").value = "";
          document.getElementById("tg-password").value = "";
          document.getElementById("tg-active-box").style.display = "none";
          updateTgPreview();
          await fetchChannels();
        } else {
          showToast(json.message || "حدث خطأ", "error");
        }
      } catch (e) {
        showToast("خطأ في الاتصال بالرسيفر", "error");
      }
    }

    /* Save & Sync */
    async function autoSave() {
      try {
        await fetch("/api/save_all", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(playlistData)
        });
      } catch (e) {
        console.error("Auto-save error:", e);
      }
    }

    async function saveToSTB() {
      try {
        const res = await fetch("/api/save_all", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(playlistData)
        });
        const json = await res.json();
        if (json.status === "success") {
          showToast(isArabic ? I18N.ar.savedSuccess : I18N.en.savedSuccess);
        } else {
          showToast(json.message || "حدث خطأ أثناء الحفظ", "error");
        }
      } catch (e) {
        showToast("تعذر الاتصال بالرسيفر لحفظ القنوات!", "error");
      }
    }

    function exportJSON() {
      const blob = new Blob([JSON.stringify(playlistData, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "ipaudioplus_channels.json";
      a.click();
    }

    /* UI Utilities */
    function openModal(id) {
      if (id === "modal-m3u") {
        const catSelect = document.getElementById("form-m3u-category");
        catSelect.innerHTML = "";
        Object.keys(playlistData).forEach(cat => {
          const opt = document.createElement("option");
          opt.value = cat;
          opt.innerText = cat;
          if (cat === currentCategory) opt.selected = true;
          catSelect.appendChild(opt);
        });
      }
      document.getElementById(id).classList.add("show");
    }

    function closeModal(id) {
      document.getElementById(id).classList.remove("show");
    }

    function showToast(msg, type = "success") {
      const container = document.getElementById("toasts");
      const toast = document.createElement("div");
      toast.className = "toast";
      if (type === "error") toast.style.borderRightColor = "var(--accent-red)";
      toast.innerText = msg;
      container.appendChild(toast);
      setTimeout(() => toast.remove(), 4000);
    }

    function toggleLang() {
      isArabic = !isArabic;
      document.documentElement.dir = isArabic ? "rtl" : "ltr";
      document.documentElement.lang = isArabic ? "ar" : "en";
      
      const lang = isArabic ? I18N.ar : I18N.en;
      document.getElementById("txt-app-title").innerText = lang.appTitle;
      document.getElementById("txt-app-sub").innerText = lang.appSub;
      document.getElementById("txt-status").innerText = lang.status;
      document.getElementById("btn-export").innerText = lang.btnExport;
      document.getElementById("btn-import-m3u").innerText = lang.btnImportM3U;
      document.getElementById("btn-save-stb").innerText = lang.btnSaveSTB;
      document.getElementById("btn-new-cat").innerText = lang.btnNewCat;
      document.getElementById("btn-new-ch").innerText = lang.btnNewCh;
      document.getElementById("btn-del-cat").innerText = lang.btnDelCat;
      document.getElementById("search-input").placeholder = lang.searchPlaceholder;
      document.getElementById("btn-lang").innerText = isArabic ? "English" : "العربية";
      
      renderCategories();
      renderChannels();
    }

    window.onload = init;
  </script>
</body>
</html>"""

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class IPAudioWebHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Silent or debug log
        pass

    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()

    def do_GET(self):
        url_parts = urllib.parse.urlparse(self.path)
        path = url_parts.path

        if path in ["/", "/index.html"]:
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode("utf-8"))
            return

        elif path == "/api/status":
            lan_ip = get_lan_ip()
            playlist = load_playlist()
            total_ch = sum(len(v.get("channels", [])) for v in playlist.values())
            res = {
                "status": "running",
                "ip": lan_ip,
                "port": self.server.server_port,
                "categories": list(playlist.keys()),
                "total_channels": total_ch
            }
            self.send_json(200, res)
            return

        elif path == "/api/token_gen/info":
            templates = load_provider_templates()
            pro_data = load_pro_data()
            providers_info = {}
            for p_name, tmpl_chs in templates.items():
                cur = pro_data.get(p_name, {})
                sample = tmpl_chs[0].get("base_url", "") if tmpl_chs else ""
                providers_info[p_name] = {
                    "channel_count": len(tmpl_chs),
                    "sample_url": sample,
                    "has_active_sub": bool(cur.get("token") or cur.get("username")),
                    "saved_username": cur.get("username", ""),
                    "saved_password": cur.get("password", "") or cur.get("token", ""),
                    "saved_token": cur.get("token", "")
                }
            self.send_json(200, {
                "status": "success",
                "providers": providers_info,
                "save_path": PRO_JSON_PATH
            })
            return

        elif path == "/api/update/check":
            try:
                from . import updater
            except Exception:
                import updater
            has_up, info, err = updater.check_for_updates()
            self.send_json(200, {
                "status": "success" if not err else "error",
                "has_update": has_up,
                "update_info": info,
                "error": err
            })
            return

        elif path == "/api/channels":
            playlist = load_playlist()
            self.send_json(200, {"status": "success", "data": playlist})
            return

        elif path == "/api/export":
            playlist = load_playlist()
            data = json.dumps(playlist, ensure_ascii=False, indent=2).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Disposition", "attachment; filename=ipaudioplus_user_list.json")
            self.send_header("Content-Length", str(len(data)))
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(data)
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        url_parts = urllib.parse.urlparse(self.path)
        path = url_parts.path

        content_length = int(self.headers.get("Content-Length", 0))
        post_body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else "{}"

        try:
            req_data = json.loads(post_body)
        except Exception:
            req_data = {}

        if path == "/api/update/install":
            try:
                from . import updater
            except Exception:
                import updater
            download_url = req_data.get("download_url")
            if not download_url:
                has_up, info, err = updater.check_for_updates()
                if info:
                    download_url = info.get("download_url") or info.get("ipk_url")
            ok, msg = updater.download_and_install_update(download_url)
            self.send_json(200, {"status": "success" if ok else "error", "message": msg})
            return

        elif path == "/api/update/restart":
            try:
                from . import updater
            except Exception:
                import updater
            updater.restart_gui()
            self.send_json(200, {"status": "success", "message": "Enigma2 is restarting..."})
            return

        if path == "/api/token_gen/save":
            provider = req_data.get("provider", "Orange")
            username = req_data.get("username", "").strip()
            password = req_data.get("password", "").strip()

            templates = load_provider_templates()
            channels_template = templates.get(provider, [])

            if not channels_template:
                self.send_json(400, {"status": "error", "message": f"مزود {provider} غير متوفر حالياً!"})
                return

            token = calculate_token(username, password)
            if not token:
                self.send_json(400, {"status": "error", "message": "يرجى إدخال اسم المستخدم أو كلمة المرور / التوكن!"})
                return

            channels = []
            for idx, item in enumerate(channels_template, 1):
                base_url = item.get("base_url", "")
                full_url = f"{base_url}{token}#"
                ch_name = item.get("name", f"Channel {idx}")
                channels.append({
                    "Name": ch_name,
                    "name": ch_name,
                    "display_name": ch_name,
                    "Id": str(idx),
                    "id": str(idx),
                    "Url": full_url,
                    "url": full_url
                })

            pro_data = load_pro_data()
            badge = "SF" if provider == "SATFAMILY" else ("ORG" if provider == "Orange" else "BEST")

            pro_data[provider] = {
                "Id": badge,
                "badge": badge,
                "username": username,
                "password": password,
                "token": token,
                "channels": channels,
                "streams": channels
            }

            ok, msg = save_pro_data(pro_data)
            if ok:
                self.send_json(200, {
                    "status": "success",
                    "message": f"تم بنجاح توليد وتفعيل قائمة {provider} بعدد {len(channels)} قناة في الرسيفر!",
                    "provider": provider,
                    "channel_count": len(channels),
                    "token": token
                })
            else:
                self.send_json(500, {"status": "error", "message": f"خطأ في الحفظ: {msg}"})
            return

        elif path == "/api/token_gen/delete":
            provider = req_data.get("provider")
            if not provider:
                self.send_json(400, {"status": "error", "message": "Provider is required"})
                return

            pro_data = load_pro_data()
            if provider in pro_data:
                del pro_data[provider]
                ok, msg = save_pro_data(pro_data)
                if ok:
                    self.send_json(200, {"status": "success", "message": f"تم مسح اشتراك {provider} بنجاح من الرسيفر"})
                else:
                    self.send_json(500, {"status": "error", "message": msg})
            else:
                self.send_json(200, {"status": "success", "message": "المزود غير موجود في الاشتراكات"})
            return

        if path == "/api/save_all":
            if isinstance(req_data, dict):
                ok, msg = save_playlist(req_data)
                if ok:
                    self.send_json(200, {"status": "success", "message": "Saved"})
                else:
                    self.send_json(500, {"status": "error", "message": msg})
            else:
                self.send_json(400, {"status": "error", "message": "Invalid format"})
            return

        elif path == "/api/channels/add":
            server_name = req_data.get("server")
            ch_name = req_data.get("name")
            ch_url = req_data.get("url")
            
            if not server_name or not ch_name or not ch_url:
                self.send_json(400, {"status": "error", "message": "Missing required fields"})
                return

            playlist = load_playlist()
            if server_name not in playlist:
                playlist[server_name] = {"Id": server_name, "channels": []}

            new_id = str(len(playlist[server_name]["channels"]) + 1)
            playlist[server_name]["channels"].append({
                "Name": ch_name,
                "Id": new_id,
                "Url": ch_url
            })
            save_playlist(playlist)
            self.send_json(200, {"status": "success", "message": "Channel added", "data": playlist})
            return

        elif path == "/api/reload":
            trigger_reload()
            self.send_json(200, {"status": "success", "message": "Reload triggered"})
            return

        elif path == "/api/eval":
            code = req_data.get("code", "")
            try:
                import io, contextlib
                f = io.StringIO()
                with contextlib.redirect_stdout(f):
                    exec(code, globals())
                self.send_json(200, {"status": "success", "output": f.getvalue()})
            except Exception as e:
                import traceback
                self.send_json(500, {"status": "error", "error": traceback.format_exc()})
            return

        self.send_response(404)
        self.end_headers()

    def send_json(self, code, data_dict):
        body = json.dumps(data_dict, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(body)

def start_server(port=8088):
    global _server_thread, _http_server
    if _http_server is not None:
        print(f"[IPAudioPlus-Web] Server already running on port {_http_server.server_port}")
        return True

    try:
        _http_server = ThreadedHTTPServer(("0.0.0.0", int(port)), IPAudioWebHandler)
        _server_thread = threading.Thread(target=_http_server.serve_forever, daemon=True)
        _server_thread.start()
        lan_ip = get_lan_ip()
        print(f"[IPAudioPlus-Web] Server started successfully at http://{lan_ip}:{port}")
        return True
    except Exception as e:
        print(f"[IPAudioPlus-Web] Failed to start web server on port {port}: {e}")
        _http_server = None
        _server_thread = None
        return False

def stop_server():
    global _server_thread, _http_server
    if _http_server is not None:
        try:
            _http_server.shutdown()
            _http_server.server_close()
        except Exception as e:
            print(f"[IPAudioPlus-Web] Error stopping web server: {e}")
        _http_server = None
        _server_thread = None
        print("[IPAudioPlus-Web] Server stopped.")

def is_running():
    return _http_server is not None

if __name__ == "__main__":
    p = int(sys.argv[1]) if len(sys.argv) > 1 else 8088
    start_server(p)
    print("Press Ctrl+C to stop...")
    try:
        import time
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        stop_server()
