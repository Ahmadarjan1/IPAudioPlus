import time
import sys
from send_key import send_key
from manage_stb import take_osd_screenshot

print("[*] Clearing to main screen...")
send_key(1)
time.sleep(0.5)
send_key(1)
time.sleep(0.5)

print("[*] Opening Plugin Browser (Green)...")
send_key(399)
time.sleep(1.5)

print("[*] Navigating to IP AudioPlus...")
# 1 Down, 4 Right, OK
send_key(108)
time.sleep(0.3)
for _ in range(4):
    send_key(106)
    time.sleep(0.3)

print("[*] Launching IP AudioPlus (OK)...")
send_key(352)
time.sleep(1.5)

print("[*] Pressing UP to open Server Popup...")
send_key(103)
time.sleep(1.0)

print("[*] Capturing screenshot...")
take_osd_screenshot("server_popup_screen.png")
print("[+] Done.")
