import os
import sys
import paramiko
import urllib.request

HOST = "192.168.100.132"
USER = "root"
PASS = "root"

def get_client():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASS, timeout=5)
    return client

def run_cmd(cmd):
    client = get_client()
    stdin, stdout, stderr = client.exec_command(cmd)
    out = stdout.read().decode('utf-8', errors='ignore')
    err = stderr.read().decode('utf-8', errors='ignore')
    client.close()
    return out, err

def upload_file(local_path, remote_path):
    client = get_client()
    sftp = client.open_sftp()
    sftp.put(local_path, remote_path)
    sftp.close()
    client.close()

def download_file(remote_path, local_path):
    client = get_client()
    sftp = client.open_sftp()
    sftp.get(remote_path, local_path)
    sftp.close()
    client.close()

if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = " ".join(sys.argv[1:])
        out, err = run_cmd(cmd)
        if out:
            print(out)
        if err:
            print("ERR:", err, file=sys.stderr)
