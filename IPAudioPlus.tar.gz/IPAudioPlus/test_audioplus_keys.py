import time
from send_key import send_key
from manage_stb import take_osd_screenshot

time.sleep(5)

print("[*] Clearing to main screen...")
send_key(1)
time.sleep(0.5)
send_key(1)
time.sleep(0.5)

print("[*] Opening Plugin Browser (Green)...")
send_key(399)
time.sleep(1.5)

print("[*] Opening AudioPlus (Right -> OK)...")
send_key(106)
time.sleep(0.3)
send_key(352)
time.sleep(1.5)

print("[*] Pressing Key '6' (code 7) 3 times to increase Audio Delay...")
send_key(7) # Key '6'
time.sleep(0.4)
send_key(7)
time.sleep(0.4)
send_key(7)
time.sleep(0.4)

print("[*] Capturing screenshot of AudioPlus with increased Audio Delay...")
take_osd_screenshot("audioplus_delay_tested.png")
print("[+] Done.")
