import time
import subprocess
import os

url = "http://server.quran.com.kw:8000/quraan"

print("[*] Testing optimized GStreamer and FFmpeg playback pipelines...")

# Pipeline 1: Optimized playbin (flags=0x02 audio only, buffer-duration=50000000ns, alsasink sync=false)
cmd1 = f'gst-launch-1.0 playbin uri="{url}" flags=0x02 buffer-duration=50000000 audio-sink="alsasink sync=false" video-sink="fakesink"'
t0 = time.time()
p = subprocess.Popen(cmd1, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=os.setsid)
time.sleep(2)
os.system("killall -9 gst-launch-1.0 2>/dev/null")
print(f"[+] GStreamer flags=0x02 executed in {time.time() - t0:.2f}s")

# Pipeline 2: Low-delay FFmpeg
cmd2 = f'ffmpeg -fflags nobuffer+fastseek -flags low_delay -probesize 32768 -analyzeduration 50000 -i "{url}" -vn -f alsa default'
t0 = time.time()
p = subprocess.Popen(cmd2, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, preexec_fn=os.setsid)
time.sleep(2)
os.system("killall -9 ffmpeg 2>/dev/null")
print(f"[+] FFmpeg low_delay executed in {time.time() - t0:.2f}s")
